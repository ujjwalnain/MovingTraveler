# Moving Traveler — store listing draft

Draft for **1.3.0 / code 4**. Finalize publisher details, public policies/source and routing access before publication. Capture actual signed-release screens after live service and device testing. See [Routing setup](ROUTING-SETUP.md) and [Play release preparation](PLAY-RELEASE.md).

## App name

Moving Traveler

## Short description

Simulate Android locations along a route at your chosen pace.

## Full description

Plan a simulated journey and control how it moves. Moving Traveler uses Android's developer mock-location feature for location testing and demonstrations.

Choose a start and destination on a native map, search for a place or enter latitude and longitude. Select Walk, Cycle or Drive, review the route, choose your pace and start the journey.

- Walking, cycling and driving routes use Geoapify where the underlying map data supports them.
- Walk, Cycle and Drive select a routing profile and a starting pace of 5, 15 or 50 km/h. Adjust custom pace from 0.5 to 200 km/h, including during playback.
- Pause holds the current point; Resume continues from there.
- Back and forth reverses along the selected route at each endpoint.
- Stay at start holds one simulated location.
- A one-way journey holds its destination after arrival until Stop.
- A foreground service supports playback while you switch apps, with notification controls when allowed.
- Explicit Direct line and fixed-location modes work with coordinate-only planning.

The map uses MapLibre and OpenFreeMap. Map viewing requires internet and online consent, but no map key. Search and road routes use Geoapify; the personal-testing version accepts your Geoapify key in Settings → Routing access. **[PUBLISHER: REPLACE THIS SENTENCE WITH THE EXACT ROUTING ACCESS MODEL OF THE PUBLIC RELEASE.]**

Your chosen pace determines simulated movement and duration independently of provider estimates. Coverage varies by place and travel mode. Direct lines can cross buildings or water. This simulator does not reproduce live traffic or physical footsteps and is not a navigation or road-safety guide.

Setup requires Android 6.0+ and choosing Moving Traveler in Developer options → Select mock location app. Optional approximate-location permission enables Google Play Services mock publication; declining it preserves Android framework simulation. Google Play Services is not required to display the map. The app does not retrieve your actual location. Simulated fixes remain marked as mock; receiving apps can accept, ignore or reject them.

Online planning is optional. OpenFreeMap receives map requests; Geoapify receives searches, selected route points and the routing key. Providers also process network metadata under their policies. Manual drafts and preferences stay locally; loaded place results and route geometry remain in memory. Map-library caches are separate. There are no Moving Traveler accounts, ads or added analytics.

The independently developed application is open source under GPL-3.0-or-later with an additional permission for optional Google Play Services linking. It takes inspiration from FakeTraveler and preserves its attribution. Use it for your own tests and demonstrations, and tell anyone viewing a shared location that it is simulated.

## Publisher fields

| Field | To complete |
| --- | --- |
| Category | Tools; confirm the final purpose. |
| Developer | [PUBLISHER DISPLAY NAME] |
| Support | [EMAIL / WEBSITE] |
| Privacy | [PUBLIC HTTPS URL] → `PUBLIC_PRIVACY_URL` |
| Application terms | [PUBLIC HTTPS URL] → `PUBLIC_TERMS_URL` |
| Corresponding source | [PUBLIC HTTPS RELEASE SOURCE URL] → `PUBLIC_SOURCE_URL` |
| Routing access | [USER-ENTERED KEY OR PUBLISHER SERVICE; REQUIRED ACCOUNT/PLAN DISCLOSURE] |
| Ads | No for this implementation; reassess changes. |
| Content rating | Complete the questionnaire for the final binary. |

## Screenshots and claims

Capture the loaded map/route, selected pace, running progress, Pause, Back and forth and Stay at start. Keep OpenStreetMap/OpenMapTiles and Geoapify attribution legible. Include portrait, landscape and large-text cases in the test record. Widget-test captures with a blank map are review aids, not storefront evidence of live map rendering.

Do not claim undetectable locations, universal app compatibility, verified WhatsApp support, zero lag or Play approval. Do not fabricate third-party screens or imply affiliation with WhatsApp/Meta. Make the routing account requirement and tested limits clear in the actual listing. [Play listing guidance](https://support.google.com/googleplay/android-developer/answer/13393723?hl=en)
