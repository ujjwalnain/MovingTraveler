// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import static org.junit.Assert.*;
import android.app.Application;
import android.content.SharedPreferences;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.util.ReflectionHelpers;

/** Validation and failure-path fixtures only; Android Keystore/device encryption is not emulated. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = Application.class)
public final class RoutingCredentialsTest {
    @Before @After public void clearFixtureState() {
        preferences().edit().clear().commit();
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedEnvelope", null);
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedPlain", "");
    }

    @Test public void keyValidationRejectsMalformedAndUnsafeValues() {
        assertTrue(RoutingCredentials.valid("test_fixture_key_not_real_123456"));
        assertTrue(RoutingCredentials.valid(repeat('a', 16)));
        assertTrue(RoutingCredentials.valid(repeat('a', 128)));
        for (String value : new String[]{null, "", repeat('a', 15), repeat('a', 129),
                "test fixture with spaces", "test_fixture_key\ntrailing", "test_fixture_key&another=value",
                "test_fixture_key/../path", "test_fixture_key:secret", "test_fixture_key_東京"}) {
            assertFalse(RoutingCredentials.valid(value));
        }
    }

    @Test @Config(sdk = 23)
    public void absentPersonalKeyUsesOnlyValidPublisherConfigurationOnApi23() {
        String actual = RoutingCredentials.get(application());
        String expected = RoutingCredentials.valid(BuildConfig.GEOAPIFY_API_KEY) ? BuildConfig.GEOAPIFY_API_KEY : "";
        assertTrue("Absent personal configuration must return only the validated build setting", actual.equals(expected));
        assertFalse(preferences().contains("sealed"));
    }

    @Test public void malformedCiphertextFailsClosedInsteadOfFallingBackToAnotherKey() {
        for (String envelope : new String[]{"not-an-envelope", ":", "a:b:c", "AA==:AA==",
                "AAAAAAAAAAAAAAAA:invalid!base64", repeat('x', 2050) + ":AA=="}) {
            preferences().edit().putString("sealed", envelope).commit();
            assertTrue("Malformed ciphertext must not return access credentials", RoutingCredentials.get(application()).isEmpty());
            assertEquals(envelope, preferences().getString("sealed", ""));
        }
    }

    @Test public void changedCiphertextCannotReusePreviouslyCachedPlaintext() {
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedEnvelope", "old:envelope");
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedPlain", "test_fixture_key_not_real_123456");
        preferences().edit().putString("sealed", "different-corrupt-envelope").commit();
        assertTrue(RoutingCredentials.get(application()).isEmpty());
    }

    @Test public void invalidSaveDoesNotCreatePlaintextOrOverwriteExistingAccess() throws Exception {
        preferences().edit().putString("sealed", "existing:encrypted-value").commit();
        try {
            RoutingCredentials.save(application(), "invalid key with spaces");
            fail("Invalid key should be rejected before accessing Android Keystore");
        } catch (IllegalArgumentException expected) {
            assertEquals("existing:encrypted-value", preferences().getString("sealed", ""));
            assertEquals(1, preferences().getAll().size());
        }
    }

    @Test public void clearRemovesPersonalEnvelopeAndCachedAccess() {
        preferences().edit().putString("sealed", "old:envelope").commit();
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedEnvelope", "old:envelope");
        ReflectionHelpers.setStaticField(RoutingCredentials.class, "cachedPlain", "test_fixture_key_not_real_123456");
        RoutingCredentials.clear(application());
        assertFalse(preferences().contains("sealed"));
        assertNull(ReflectionHelpers.getStaticField(RoutingCredentials.class, "cachedEnvelope"));
        assertEquals("", ReflectionHelpers.getStaticField(RoutingCredentials.class, "cachedPlain"));
    }

    private static Application application() { return RuntimeEnvironment.getApplication(); }
    private static SharedPreferences preferences() { return application().getSharedPreferences("routingAccess", 0); }
    private static String repeat(char value, int count) {
        StringBuilder text = new StringBuilder(count);
        for (int i = 0; i < count; i++) text.append(value);
        return text.toString();
    }
}
