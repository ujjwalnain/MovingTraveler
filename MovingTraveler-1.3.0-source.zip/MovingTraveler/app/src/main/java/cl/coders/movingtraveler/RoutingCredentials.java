// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Personal routing access is encrypted with a non-exportable Android Keystore key. */
final class RoutingCredentials {
    private static final String ALIAS = "moving_traveler_routing_v1";
    private static String cachedEnvelope, cachedPlain = "";
    private RoutingCredentials() { }

    static boolean valid(String value) {
        return value != null && value.matches("[A-Za-z0-9_-]{16,128}");
    }

    static synchronized String get(Context context) {
        String envelope = context.getSharedPreferences("routingAccess", 0).getString("sealed", "");
        if (envelope.isEmpty()) return valid(BuildConfig.GEOAPIFY_API_KEY) ? BuildConfig.GEOAPIFY_API_KEY : "";
        if (envelope.equals(cachedEnvelope)) return cachedPlain;
        try {
            String[] parts = envelope.split(":", -1);
            if (parts.length != 2 || envelope.length() > 2048) return "";
            KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
            SecretKey key = (SecretKey) store.getKey(ALIAS, null);
            if (key == null) return "";
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            if (iv.length != 12) return "";
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
            String plain = new String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
            if (!valid(plain)) return "";
            cachedEnvelope = envelope; cachedPlain = plain;
            return plain;
        } catch (Exception unavailable) {
            // Invalidated keys fail closed. Never fall back to plaintext storage or log access keys.
            return "";
        }
    }

    static synchronized void save(Context context, String value) throws Exception {
        if (!valid(value)) throw new IllegalArgumentException("Enter the API key from your Geoapify project.");
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        SecretKey key = (SecretKey) store.getKey(ALIAS, null);
        if (key == null) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true).build());
            key = generator.generateKey();
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String envelope = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":"
                + Base64.encodeToString(encrypted, Base64.NO_WRAP);
        if (!context.getSharedPreferences("routingAccess", 0).edit().putString("sealed", envelope).commit())
            throw new IllegalStateException("Routing access could not be saved.");
        cachedEnvelope = envelope; cachedPlain = value;
    }

    static synchronized void clear(Context context) {
        context.getSharedPreferences("routingAccess", 0).edit().remove("sealed").apply();
        cachedEnvelope = null; cachedPlain = "";
    }
}
