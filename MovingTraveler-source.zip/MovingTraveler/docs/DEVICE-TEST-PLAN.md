# Moving Traveler — device test plan

**Status: planned, not performed by this document.** Record actual results against the exact tested artifact. A browser preview demonstrates UI only; unit tests exercise route mathematics; neither establishes Android mock-provider or WhatsApp compatibility.

## Test record

For each run record: artifact SHA-256, application ID/version code, signing certificate fingerprint, device/OEM, Android/API, WebView version, Google Play Services version or absence, online providers, battery mode, time/date, steps, expected result, actual result, pass/fail, and evidence path. Preserve failures and retest after fixes. Do not enter a pass without observing the result.

## Platform matrix

| Android API | Focus |
| --- | --- |
| 23 | Minimum-version installation, first launch, all Java/platform API paths, notifications and Stop cleanup. |
| 29 | Foreground service continuation, background app switching, platform providers. |
| 31 | Framework fused provider, developer mock selection, launch restrictions. |
| 33 | Notification allow/deny/dismiss; Task Manager Stop; permission revocation. |
| 34 | `specialUse` start and declaration behavior with optional coarse permission both granted and denied, without any actual-location retrieval. |
| 35 | Edge-to-edge layout, system bars, cutouts, keyboard and background behavior. |
| 36 | Target-version behavior and complete regression on a current device. |

Run the core cases on every listed API. Include a Google Play Services device, a device/emulator without it, a low-memory/small-screen device, and at least two real OEM families. At least one real OEM device must complete the 60-minute screen-off test below with its ordinary default power settings. Record exceptions rather than claiming all-OEM reliability.

## Functional and system cases

| Case | Steps and acceptance criteria |
| --- | --- |
| Fresh start | Clear app storage, launch. No tile/search/route request before online choice. Choose coordinate-only; enter points and run Direct line. No app online-planning requests. At first Start, explain the optional approximate-location request; declining must still start framework simulation. No fine/background-location request or actual-location retrieval. Repeat with online consent and coarse permission granted. |
| Setup | Start with no mock app selected, then another app selected. Show actionable setup; no simulation. Select Moving Traveler and retry. Reopening settings must not silently start playback. |
| Point selection | Set both endpoints by tap, search and coordinates. Test negative coordinates, decimal validation, poles/date line, equal endpoints and invalid input. UI remains usable; invalid moving routes do not start. Static mode accepts one point. |
| Direct route | Use equatorial points `(0, 0)` to `(0, 0.01)` at 36 km/h. Expect about 1,112 m total and 10 m/s progression. Check received fixes in a separate test receiver, including increasing timestamps, bearing, speed and mock flag. Compare distance against monotonic elapsed time, allowing observed callback latency. |
| Road route | Fetch a short road route; line follows returned driving geometry. Check both endpoints and arrival. Walk/Cycle presets change pace without implying a different transport-routing profile. |
| Pace | Check 0.5, 5, 15, 50 and 200 km/h; typed and slider controls agree. Change pace while moving and paused. Position advances using old pace up to the change, then new pace; no restart or unexplained jump. |
| Pause/resume | Pause for at least two minutes. Coordinates remain fixed, reported speed becomes zero and timestamps continue. Resume does not jump ahead for paused time. Repeat from app and notification. |
| Destination hold | Finish a short one-way trip. Show Arrived and keep publishing the destination with zero speed until Stop. No automatic restoration or silent route restart. |
| Return trip | Enable Return trip, run at least three legs. Reverse along the same geometry at each endpoint; bearing changes appropriately, and position does not teleport back to the start. |
| Static mode | Enable Hold one location. Destination/pace controls are hidden as intended; publish the selected point until Stop. Leaving/reopening the app preserves live-session display. |
| Provider coverage | Receive GPS, network and available framework fused updates. With optional coarse permission granted and Play Services available, separately subscribe through Google FLP. Verify simulated position, speed and mock marker on each. With coarse denied, Play Services missing or FLP failure, Android providers keep working and capability status identifies the skipped/unavailable Google path. |
| App switching | Start, switch to a receiver, return, rotate/recreate the activity and reopen from Recents. Playback is continuous; UI does not start a second service or edit the active route accidentally. Stop remains reachable. |
| Screen off | On real OEM hardware run Return trip for 60 minutes with the screen off, default power settings and a receiver recording timestamps. Record gaps, distance/time error, battery change, thermal state, ANRs and service kills. Test stationary hold too. Wake-lock release must be observable after Stop. |
| Notification denied | API 33+: deny, dismiss and later revoke notification permission. Playback still starts from the visible app; in-app Stop works. Check system Task Manager visibility. Re-enable permission and verify notification Pause/Resume/Stop. |
| Mock permission revoked | During playback select a different mock app or clear the selection. No crash, stuck wake lock or false “running successfully” state; show the need to select this app again. Repeat after permission is restored. |
| Optional coarse permission | Grant, deny, deny permanently and revoke approximate-location permission in Settings. Google mock methods must not run without permission. Denial must not block framework playback; status distinguishes Google compatibility from Android providers. If Android kills the process on revocation, confirm no silent restart, then explicitly Start and verify framework fallback. Grant later and verify the Google path on a subsequent explicit Start. |
| Device Location toggle | Toggle system Location off/on before and during a run; capture OEM/provider behavior. Explain observed receiver failure without claiming successful delivery when none occurs. |
| Stop and cleanup | Stop in app and notification while running, paused, static and arrived. Test rapid Start/Stop/Start. Remove owned test providers, disable FLP mock mode and release wake lock; a receiver can recover real fixes when available. Record temporary receiver caches separately. |
| Process lifecycle | Swipe task away, kill the process, use system Stop/Force stop, and reboot. Distinguish behaviors: normal task dismissal may keep the ongoing service; process death/reboot must not silently resume an old route. Check provider recovery and no lingering wake lock. |

## Network, privacy and interface cases

- Test offline start, airplane mode after route loading, missing Geocoder, empty search results, invalid DNS, TLS failure, timeout, HTTP 429/500, malformed/oversized OSRM response and no road connection. No UI freeze, crash, duplicate request flood or mislabeled road route; direct-line planning remains available. Existing loaded playback should not depend on a live routing connection.
- Turn Online maps off during a pending search/route and during playback. Prevent new planning requests, ignore stale results that no longer apply, and continue the loaded local simulation. A completed external request cannot be recalled. Inspect network capture with and without Play Services and distinguish independent system-service traffic.
- Verify final provider URLs, request headers, tile caching, HTTPS, attribution and links. Check privacy text against recorded traffic. Clear app storage and confirm the saved draft and online consent are removed. Audit the merged manifest: coarse is the documented optional permission; fine/background location must remain absent. Check code/SDK behavior for real-location retrieval and unexpected advertising or analytics additions rather than inferring data collection from permission names alone.
- Test TalkBack, keyboard navigation, large font/display scaling, landscape, small screens, dark device setting, system bars/cutouts and open keyboard. Primary controls remain visible; text and attribution do not overlap; modal focus and Back behavior work.
- Profile the signed release build during map panning, route calculation, speed dragging and a 20,000-point route. Record frame timings, response delays, memory, CPU, battery, ANRs and crash evidence. Agree measurable release thresholds before calling a test passed. Do not claim “no lag” from a desktop preview or a single device.

## Third-party app and WhatsApp verification

First use a test receiver that deliberately accepts mock locations. Then test an app that rejects them: rejection is a supported compatibility limitation, not a reason to conceal the mock flag. Record app/version/provider and observed result individually.

WhatsApp is **not verified by this document**. For a consented test using your own accounts/devices, tell the recipient the location is simulated. Start a Moving Traveler route, then manually use WhatsApp **Attach → Location → Share live location**. Watch from the receiving device; record update cadence, motion, pause, destination hold and Stop recovery. A “Send current location” message is static and cannot establish moving-location compatibility. Stop the test share manually afterwards. Repeat with app switching, screen off and current WhatsApp permission settings. [WhatsApp live-location instructions](https://faq.whatsapp.com/480865177351335/?cms_platform=android)

A successful result applies only to that tested combination. Publish no universal compatibility claim, and do not automate messaging, access private chats or bypass mock detection during testing.
