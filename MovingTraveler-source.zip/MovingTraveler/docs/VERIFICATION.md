# Verification — 14 September 2026

## Completed

- Debug APK and optimized unsigned release AAB built with JDK 21, Gradle 8.13, Android Gradle Plugin 8.13.2 and SDK/target API 36; minSdk 23.
- `testDebugUnitTest`: 13 JUnit tests passed. One wraps 84 standalone route-engine assertions; the other 12 cover service lifecycle and error handling with Robolectric on API 28 and API 35.
- Route checks include distance/speed accuracy, bearings, multi-segment interpolation, vertex overshoot, arrival hold, pause/resume, pace changes, return/loop traversal, duplicate points, dateline/poles/antipodes, invalid values and timing-step consistency.
- Service checks include start/stop, timestamps and location payload fields, foreground notifications, wake-lock lifetime, speed changes, pause/resume without catch-up, stationary/arrival holding, malformed routes, partial-provider failure and permission-revocation errors.
- Robolectric uses an explicitly documented recording LocationManager shadow for Android test-provider methods it does not implement. These tests exercise application behavior at that boundary; they do **not** verify Android's actual mock-location delivery or Google Play Services.
- Debug and release lint passed with zero errors. Remaining notices only identify newer dependency/tool versions; versions remain pinned to the tested set.
- The debug APK's signatures verified. Bundletool 1.18.1 validated the release AAB; it is unsigned and contains no native libraries. Final packaged UI assets match the source byte for byte.
- JavaScript syntax plus 10 bridge/privacy/edge scenarios (42 assertions) passed. Scenarios include native commands, offline consent, stale routing replies, road geometry validation, coordinate extremes, speed-event throttling, static holding and optional compatibility controls.
- Chrome UI inspection with online map tiles at 360×740 and 390×844. Start/Pause/Stop, route line and map attribution remain visible; no horizontal overflow. The preview clearly labels itself as a browser preview and does not modify system location.
- A sample HTTPS OSRM request returned `Ok`, a 2,351 m road route and 108 geometry points. This is a connectivity/payload check, not a provider availability guarantee.

## Not verified here

- No physical Android phone was connected. Android emulator versions 37.1.11 and checksum-verified 35.6.11 could not boot inside the restricted host environment: hardware queries were denied and the emulator exited during initialization. No app UI or location-injection claim is based on a successful emulator run.
- Actual GPS/network/framework-fused injection, Google Play Services mock delivery, permission dialogs, notifications on a real phone, screen-off behavior, OEM battery management and power consumption still need device testing.
- WhatsApp live-location compatibility has not been tested. Other apps may reject mock coordinates, cache locations, reduce update frequency or require their own location permissions.
- No universal frame-rate/lag, battery-life, uninterrupted-background or store-approval claim has been established.
- No signed publisher release, Play Console upload, public deployment, account action or message to another person has been performed.

Follow `DEVICE-TEST-PLAN.md` on the final signed release build, then replace the remaining unknowns with measured results. `PLAY-RELEASE.md` identifies the publication configuration still required.
