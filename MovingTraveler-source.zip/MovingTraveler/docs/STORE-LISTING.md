# Moving Traveler — store listing draft

Publisher/contact details and final release screenshots remain to be supplied. This copy describes implemented behavior; publish it only after the corresponding release tests pass.

## App name

Moving Traveler

## Short description

Simulate Android locations along a route at your chosen pace.

## Full description

Plan a simulated journey and control how it moves. Moving Traveler uses Android's developer mock-location feature for location testing and demonstrations.

Choose your starting point and destination on the map, search for a place, or enter latitude and longitude. Select a pace, start the journey, and follow its progress.

• Road routes follow driving roads; direct routes travel between the selected points.  
• Walk, Cycle and Drive presets set the speed to 5, 15 and 50 km/h. Choose a custom pace from 0.5 to 200 km/h and change it during playback.  
• Pause holds your current simulated position. Resume continues the journey.  
• Return trip travels back and forth along the selected route until stopped.  
• Hold one location preserves a static-location mode.  
• At the end of a one-way journey, the destination stays held until you tap Stop.  
• A foreground service continues playback when you switch apps, with notification controls when allowed.  
• Coordinate-only mode supports direct routes and fixed positions without online planning requests.

Road routing uses driving geometry, including when a Walk or Cycle speed preset is selected. It does not provide pedestrian or bicycle directions. Direct routes can cross buildings or water. Movement follows the selected pace; it does not reproduce traffic, physical footsteps or every detail of real travel.

Setup requires Android 6.0 or later and selecting Moving Traveler under Developer options → Select mock location app. Optional approximate-location permission enables Google Play Services compatibility; declining it keeps Android framework simulation available. The app does not retrieve your real location. Simulated locations stay marked as mock, and other apps may accept, ignore or reject them. Compatibility with any particular third-party app is not guaranteed.

Online maps are optional. When enabled, OpenStreetMap receives map requests, your device's geocoding service receives submitted searches, and the configured routing provider receives route coordinates. Providers receive request metadata and may keep logs. Review the privacy policy for details.

Moving Traveler has no accounts, advertising or analytics features. Its application code is open source under GPL-3.0-or-later with an additional Google Play Services linking permission. The project takes inspiration from FakeTraveler's mock-location mechanism and preserves its attribution. Use it for your own tests and demonstrations, and make it clear to anyone viewing a shared location that it is simulated.

## Release metadata to finalize

| Field | Draft value / action |
| --- | --- |
| Category | Tools; confirm the final app's actual core purpose. |
| Developer | [PUBLISHER DISPLAY NAME] |
| Support | [SUPPORT EMAIL / WEBSITE] |
| Privacy policy | [PUBLIC PUBLISHER PRIVACY POLICY URL] |
| Corresponding source | [SOURCE URL FOR THIS RELEASE] |
| Ads | No, for this implementation; re-evaluate if monetization changes. |
| Content rating | Answer the Play questionnaire for the final binary; do not predeclare a rating. |

## Screenshot capture plan

Capture actual release-build screens: start/destination map; chosen pace and route; active progress; pause with held position; Return trip option; static-location mode. Use a clearly identified demonstration route and retain OSM attribution. Keep branding and text legible on small screens. Do not fabricate WhatsApp screenshots or use its branding to imply affiliation.

Avoid “undetectable,” “works everywhere,” “zero lag,” “guaranteed WhatsApp support,” or Play approval badges. The publisher must accurately describe behavior and limitations. [Google Play listing guidance](https://support.google.com/googleplay/android-developer/answer/13393723?hl=en)
