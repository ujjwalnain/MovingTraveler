# Moving Traveler privacy policy — publisher draft

**Not ready to publish.** Replace every bracketed publisher/provider field, verify the final binary and service contracts, and remove this draft notice before publication. This text describes the current implementation; it is not a submitted Data Safety declaration.

Effective date: **[EFFECTIVE DATE]**  
Publisher: **[PUBLISHER LEGAL/DISPLAY NAME]**  
Privacy contact: **[PRIVACY CONTACT EMAIL OR CONTACT FORM]**  
Public policy URL: **[PUBLIC PRIVACY POLICY URL]**

Moving Traveler lets you hold a simulated location or play a route at a chosen pace using Android's developer mock-location feature. It does not retrieve your actual device location. It requests optional approximate-location permission for its Google Play Services mock-publication compatibility path; you can decline and still use Android framework simulation. It does not access WhatsApp messages, contacts or accounts, and does not send messages or start location sharing in another app.

## Information on your device

The app saves your route draft—selected start/destination, their labels, pace, route and playback choices—and online-map preference in local app storage. It also remembers onboarding choices for permission prompts. These settings let you return to your previous choices. The app does not provide accounts, advertising or an analytics dashboard, and contains no advertising or analytics SDK added for those purposes.

The active simulation runs locally. During ordinary operation, Stop ends playback and releases its foreground service and wake lock. Pausing and arriving at a destination keep the current simulated position active until you tap Stop. A killed process does not automatically resume an old journey.

Android backup is disabled in the application manifest. Local drafts, preferences and WebView cache remain until replaced or erased using Android **Settings → Apps → Moving Traveler → Storage → Clear storage**, or by uninstalling. Stop ends the simulation but does not delete the saved draft.

## Optional online planning

You choose whether to enable Online maps. Before that choice, the app does not initiate its map-tile, place-search or road-route requests. Coordinate-only mode supports static positions and direct routes without those requests. You can turn Online maps off in Options; this prevents new requests from these features but does not undo data already sent or delete providers' logs.

| Feature | Recipient and information sent | Purpose |
| --- | --- | --- |
| Map display | OpenStreetMap tile service: requested map tile/area, IP address, application/browser headers and ordinary request metadata | Display the area you are viewing. |
| Submitted place search | The geocoding provider configured by your Android device: submitted place name and request information | Find coordinates and place labels. Provider availability and practices vary by device. |
| Road route | **[PRODUCTION ROUTING OPERATOR, ENDPOINT AND PRIVACY URL]**: selected coordinates, IP address and request metadata | Calculate driving-road geometry between your selected points. |

Map areas, search terms and route coordinates may reveal places of interest, even when the route is fictional. The app sends routing and tile requests over HTTPS. Android controls its Geocoder service transport. A provider may retain server logs according to its own policy; we do not promise that online requests are anonymous or deleted immediately.

OpenStreetMap's [privacy policy](https://osmfoundation.org/wiki/Privacy_Policy) describes network access records and service processing. **Publisher action:** the development build defaults to the public OSRM demo endpoint, whose [operator states that route requests are logged](https://routing.openstreetmap.de/about.html). Replace this paragraph with the production operator's verified retention, deletion and contact details: **[ROUTING RETENTION PERIOD, PURPOSES, DELETION PROCESS AND ANY PUBLISHER SERVER LOGGING]**. Identify the device geocoder's provider where known rather than promising a single worldwide operator.

## Android and Google Play Services

The app supplies simulated coordinates, speed, bearing, accuracy and timestamps to Android test providers. When Google Play Services is available and you grant optional approximate-location permission, it also uses the Fused Location Provider's mock APIs. The bundled library requires that permission for this path; the app does not use it to request your actual location. If you decline, Google FLP publication is skipped and framework providers remain available. These values remain marked as mock; receiving apps choose whether to use them. Stop requests removal of this app's test providers and disables its Play Services mock mode where active. Other apps may retain their last received location in a cache.

Disabling Online maps does not disable Android/Google Play Services mock publication or control those system services' independent network activity. Google Play Services operates under [Google's privacy policy](https://policies.google.com/privacy). **Publisher action:** verify the data disclosures for the shipped location SDK and transitive dependencies before finalizing this policy and Data Safety. Google's [core SDK disclosure page](https://developers.google.com/android/guides/play-data-disclosure) covers specified core libraries, not every location-related service or the app's overall practices.

## Permissions and controls

- Developer options' **Select mock location app** authorizes simulation.
- Optional approximate-location (`ACCESS_COARSE_LOCATION`) permission enables the Google Play Services compatibility path. The app explains it at first Start; denial leaves Android framework mocking available. The app does not retrieve your actual location and does not request fine or background-location permission. You can revoke the optional permission in Android Settings.
- Internet/network permissions support the optional online planning features.
- Notification permission is optional on Android 13 and later. It exposes ongoing playback controls; you can still stop inside the app if notifications are denied.
- A partial wake lock keeps the CPU available while a session is active, including stationary holds, without keeping the screen on. It is released when the app performs normal session cleanup.

You can stop a session, change the selected mock app in Developer options, disable online planning, clear local storage or uninstall. If you share a location from a separate app, that app's recipients and retention are governed by that app; inform recipients when a location is simulated.

## Contact and changes

For privacy questions or requests, contact **[PRIVACY CONTACT EMAIL OR CONTACT FORM]**. Requests relating to a provider's independent records may need to be directed to that provider. **[PUBLISHER: STATE APPLICABLE REQUEST HANDLING PROCESS AND ANY ADDITIONAL RETENTION OBLIGATIONS.]**

We will revise this policy when the app's data practices change and update its effective date. Any additional collection, accounts, advertising or analytics introduced later requires an updated disclosure and, where applicable, consent before that behavior begins.
