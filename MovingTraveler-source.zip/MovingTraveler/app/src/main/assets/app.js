/* Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md. */
/* SPDX-License-Identifier: GPL-3.0-or-later */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const native = typeof window.Android !== 'undefined' && typeof window.Android.command === 'function';
  const STORAGE = 'moving-traveler-v1';
  const pending = new Map();
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(STORAGE) || '{}') || {}; } catch (_) { /* A fresh draft is safe. */ }
  const validPoint = p => Array.isArray(p) && p.length >= 2 && Number.isFinite(p[0]) && Number.isFinite(p[1]) && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180;
  const draft = {
    start: validPoint(saved.start) ? saved.start : null,
    end: validPoint(saved.end) ? saved.end : null,
    startName: typeof saved.startName === 'string' ? saved.startName.slice(0, 160) : '',
    endName: typeof saved.endName === 'string' ? saved.endName.slice(0, 160) : '',
    speedKmh: Math.max(0.5, Math.min(200, Number(saved.speedKmh) || 5)),
    routing: saved.routing === 'direct' ? 'direct' : 'road',
    static: saved.static === true,
    repeat: saved.repeat === true,
    online: typeof saved.online === 'boolean' ? saved.online : null
  };
  let selection = draft.start ? 'end' : 'start';
  let routePoints = [], totalMeters = 0, routeVersion = 0, routeLoading = false;
  let status = { status: 'idle', mockReady: false, notifications: false };
  let startPending = false, awaitingConsent = false, lastFocus = null, sheetKind = '', requestSequence = 0;
  let speedSendTimer = null, lastSpeedSentAt = -Infinity, pendingSpeed = null;
  let paintRequested = false, previewTimer = null, previewDistance = 0, previewDirection = 1, lastPreviewTime = 0;
  let markers = { start: null, end: null, live: null }, polyline = null, tileLayer = null;

  const map = L.map('map', { zoomControl: false, attributionControl: true, minZoom: 2, maxZoom: 19, worldCopyJump: true }).setView([23, 0], 2);
  map.attributionControl.setPrefix(false);
  L.control.zoom({ position: 'topright' }).addTo(map);
  const active = () => ['running', 'paused', 'arrived'].includes(status.status);
  const locked = () => active() || startPending;
  const command = payload => {
    if (native) {
      try { window.Android.command(JSON.stringify(payload)); } catch (_) { showMessage('The Android connection is unavailable. Close and reopen the app.'); }
    }
  };
  function persist() { try { localStorage.setItem(STORAGE, JSON.stringify(draft)); } catch (_) { /* Storage is optional. */ } }
  function coordinates(p) { return p ? `${p[0].toFixed(5)}, ${p[1].toFixed(5)}` : ''; }
  function distance(a, b) {
    const rad = Math.PI / 180, dLat = (b[0] - a[0]) * rad, dLon = (b[1] - a[1]) * rad;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLon / 2) ** 2;
    return 6371000 * 2 * Math.asin(Math.sqrt(Math.min(1, h)));
  }
  function routeLength(points) { let sum = 0; for (let i = 1; i < points.length; i++) sum += distance(points[i - 1], points[i]); return sum; }
  function formatDistance(m) { return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(m < 10000 ? 1 : 0)} km`; }
  function duration(m) { const mins = m / (draft.speedKmh * 1000 / 60); return mins < 1 ? '<1 min' : mins < 60 ? `${Math.ceil(mins)} min` : `${Math.floor(mins / 60)}h ${Math.ceil(mins % 60)}m`; }
  function showMessage(text, info = false) { $('message').textContent = text; $('message').classList.toggle('info', info); $('message').hidden = !text; }
  function queuePaint() { if (!paintRequested) { paintRequested = true; requestAnimationFrame(() => { paintRequested = false; render(); }); } }
  function pinIcon(kind) { return L.divIcon({ className: 'map-marker', html: `<div class="pin ${kind}"></div>`, iconSize: [25,25], iconAnchor: [8,25] }); }
  function updateMarker(kind, point) {
    if (kind === 'end' && draft.static) point = null;
    if (!point) { if (markers[kind]) { markers[kind].remove(); markers[kind] = null; } return; }
    if (!markers[kind]) {
      markers[kind] = L.marker(point, { icon: pinIcon(kind), draggable: !locked(), title: kind === 'start' ? 'Starting point' : 'Destination', keyboard: true }).addTo(map);
      markers[kind].on('dragend', event => { const p = event.target.getLatLng(); setPoint(kind, [p.lat, p.lng], ''); });
    } else markers[kind].setLatLng(point);
    if (locked()) markers[kind].dragging.disable(); else markers[kind].dragging.enable();
  }
  function updateMapRoute(fit = false) {
    updateMarker('start', draft.start); updateMarker('end', draft.end);
    if (polyline) { polyline.remove(); polyline = null; }
    if (routePoints.length > 1 && !draft.static) polyline = L.polyline(routePoints, { color: '#386f51', weight: 5, opacity: .85, lineJoin: 'round', dashArray: draft.routing === 'direct' ? '7 8' : null }).addTo(map);
    if (fit) fitRoute();
  }
  function fitRoute() {
    const pts = routePoints.length ? routePoints : [draft.start, draft.static ? null : draft.end].filter(Boolean);
    if (pts.length > 1) map.fitBounds(L.latLngBounds(pts), { paddingTopLeft: [40,90], paddingBottomRight: [40,55], maxZoom: 16, animate: false });
    else if (pts.length) map.setView(pts[0], 14, { animate: false });
  }
  function setPoint(which, point, name) {
    if (locked() || !validPoint(point)) return;
    draft[which] = [point[0], ((point[1] + 180) % 360 + 360) % 360 - 180];
    draft[`${which}Name`] = name || '';
    if (which === 'start' && !draft.end && !draft.static) selection = 'end';
    persist(); hideResults(); buildRoute(false); render();
  }
  function setOnline(online) {
    draft.online = online; persist(); command({ action: 'consent', online });
    if (tileLayer) { tileLayer.remove(); tileLayer = null; }
    if (online) {
      tileLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>', updateWhenIdle: true, keepBuffer: 2, crossOrigin: false }).addTo(map);
    }
    $('search-form').hidden = !online; $('offline-note').hidden = online || Boolean(draft.start);
    if (!online) hideResults();
  }
  function network(type, payload, resolve, reject) {
    if (!draft.online) { reject('Online maps are off. Enable them in Options to use search and road routes.'); return; }
    if (!native) { reject('Online search and road routing run inside the Android app. In this preview, choose Direct line.'); return; }
    const id = `${type}-${Date.now()}-${++requestSequence}`;
    const timeout = setTimeout(() => { const item = pending.get(id); if (item) { pending.delete(id); item.reject('The request timed out. Check your connection and try again.'); } }, 20000);
    pending.set(id, { type, resolve, reject, timeout });
    try { window.Android.request(JSON.stringify({ type, id, ...payload })); }
    catch (_) { clearTimeout(timeout); pending.delete(id); reject('The network request could not start. Please try again.'); }
  }
  function buildRoute(fit = true) {
    const version = ++routeVersion;
    routeLoading = false; routePoints = []; totalMeters = 0; showMessage('');
    if (draft.static) { if (draft.start) routePoints = [draft.start]; updateMapRoute(fit); render(); return; }
    if (!draft.start || !draft.end) { updateMapRoute(fit); render(); return; }
    if (distance(draft.start, draft.end) < 1) { showMessage('Choose two points at least one meter apart, or use Hold one location in Options.'); updateMapRoute(fit); render(); return; }
    if (draft.routing === 'direct') { routePoints = [draft.start, draft.end]; totalMeters = routeLength(routePoints); updateMapRoute(fit); render(); return; }
    routeLoading = true; updateMapRoute(fit); render();
    network('route', { points: [draft.start, draft.end], profile: 'driving' }, data => {
      if (version !== routeVersion || locked()) return;
      routeLoading = false;
      const route = data && data.routes && data.routes[0];
      const coords = route && route.geometry && route.geometry.coordinates;
      if (!Array.isArray(coords) || coords.length < 2 || coords.length > 20000 || coords.some(p => !Array.isArray(p) || !validPoint([p[1], p[0]]))) {
        showMessage('No usable road route was found. Move a point nearer a road, or select Direct line.'); render(); return;
      }
      routePoints = coords.map(p => [p[1], p[0]]); totalMeters = routeLength(routePoints);
      if (totalMeters < 1) { routePoints = []; showMessage('These points resolve to the same road position. Choose a different destination.'); }
      updateMapRoute(fit); render();
    }, error => {
      if (version !== routeVersion) return;
      routeLoading = false; showMessage(`${error} Your road route has not been replaced with a direct line.`); render();
    });
  }
  function sendSpeed(immediate = false) {
    pendingSpeed = draft.speedKmh;
    if (speedSendTimer !== null) { clearTimeout(speedSendTimer); speedSendTimer = null; }
    const elapsed = performance.now() - lastSpeedSentAt;
    const flush = () => {
      speedSendTimer = null;
      if (active() && pendingSpeed !== null) { command({ action: 'speed', speedKmh: pendingSpeed }); lastSpeedSentAt = performance.now(); }
      pendingSpeed = null;
    };
    if (immediate || elapsed >= 150) flush(); else speedSendTimer = setTimeout(flush, 150 - elapsed);
  }
  function setSpeed(value, send = true, immediate = true) {
    const speed = Number(value); if (!Number.isFinite(speed)) return;
    draft.speedKmh = Math.round(Math.max(.5, Math.min(200, speed)) * 2) / 2; persist();
    if (send && active()) sendSpeed(immediate);
    render();
  }
  function render() {
    const isActive = active(), isLocked = locked();
    document.querySelector('.journey-panel').classList.toggle('simulating', isActive);
    $('journey-title').textContent = draft.static ? 'Hold a location' : isActive ? 'Your journey' : 'Plan a journey';
    $('setup-label').textContent = native ? status.mockReady ? 'Ready' : 'Set up' : 'Preview';
    $('setup-button').classList.toggle('ready', Boolean(native && status.mockReady));
    $('start-name').textContent = draft.startName || (draft.start ? 'Starting point' : 'Choose starting point');
    $('end-name').textContent = draft.endName || (draft.end ? 'Destination' : 'Where to?');
    $('start-coordinate').textContent = draft.start ? coordinates(draft.start) : draft.online === false ? 'Enter coordinates in Options' : 'Tap the map or search a place';
    $('end-coordinate').textContent = draft.end ? coordinates(draft.end) : 'Choose your destination';
    for (const which of ['start','end']) { $(which + '-point').disabled = isLocked; $(which + '-point').classList.toggle('selected', !isLocked && selection === which); $(which + '-point').setAttribute('aria-pressed', String(!isLocked && selection === which)); }
    $('end-point').hidden = draft.static; $('point-divider').hidden = draft.static;
    $('route-options').hidden = draft.static;
    $('road-button').classList.toggle('selected', draft.routing === 'road'); $('road-button').setAttribute('aria-pressed', String(draft.routing === 'road')); $('road-button').disabled = isLocked;
    $('direct-button').classList.toggle('selected', draft.routing === 'direct'); $('direct-button').setAttribute('aria-pressed', String(draft.routing === 'direct')); $('direct-button').disabled = isLocked;
    $('route-caption').textContent = draft.routing === 'road' ? 'Road routes follow driving roads at your chosen pace.' : 'Direct line crosses terrain between your points.';
    $('route-summary').textContent = routeLoading ? 'Finding a road route…' : totalMeters ? `${formatDistance(totalMeters)} · ${duration(totalMeters)}` : draft.start && draft.end ? 'Route unavailable' : '2 points to begin';
    if (document.activeElement !== $('speed-input')) $('speed-input').value = draft.speedKmh;
    $('speed-slider').value = draft.speedKmh;
    document.querySelectorAll('[data-speed]').forEach(button => { const selected = Number(button.dataset.speed) === draft.speedKmh; button.classList.toggle('selected', selected); button.setAttribute('aria-pressed', String(selected)); });
    $('search-input').disabled = isLocked; $('search-form').querySelector('button').disabled = isLocked;
    $('map-instruction').hidden = isLocked || draft.online === false;
    $('map-hint').textContent = selection === 'start' ? 'Tap the map to set your start' : 'Tap the map to set your destination';
    $('offline-note').hidden = draft.online !== false || Boolean(draft.start);
    $('start-button').hidden = isActive;
    $('start-button').disabled = startPending || routeLoading || !routePoints.length;
    $('start-button-label').textContent = startPending ? 'Starting…' : routeLoading ? 'Finding route…' : !draft.start ? 'Choose your start' : !draft.static && !draft.end ? 'Choose your destination' : !routePoints.length ? 'Choose a valid route' : draft.static ? 'Hold this location' : 'Start journey';
    $('pause-button').hidden = !isActive || draft.static || status.status === 'arrived';
    $('pause-label').textContent = status.status === 'paused' ? 'Resume' : 'Pause';
    $('pause-button').querySelector('path').setAttribute('d', status.status === 'paused' ? 'm9 5 11 7-11 7Z' : 'M8 5v14M16 5v14');
    $('stop-button').hidden = !isActive;
    $('session-progress').hidden = !isActive || draft.static;
    const progress = Math.max(0, Math.min(1, Number(status.progress) || 0));
    $('progress-bar').value = progress; $('progress-text').textContent = `${Math.round(progress * 100)}%`;
    $('session-status').textContent = status.status === 'paused' ? 'Journey paused' : status.status === 'arrived' ? 'Arrived · holding destination' : draft.repeat ? 'Moving · return trip on' : 'Moving';
    $('distance-text').textContent = `${formatDistance(Number(status.distanceMeters) || 0)} traveled`;
    $('remaining-text').textContent = status.status === 'arrived' ? 'Tap Stop to finish' : `${duration(Math.max(0, (Number(status.totalMeters) || totalMeters) * (1 - progress)))} remaining`;
    $('bottom-note').textContent = !native ? 'Preview only. System location is unchanged.' : isActive ? draft.static ? 'Holding your start. Tap Stop to restore device location.' : 'Location simulation continues when you leave the app.' : draft.repeat ? 'Return trip on · reverses at each end until stopped.' : '';
    $('bottom-note').hidden = !$('bottom-note').textContent;
    updateMarker('start', draft.start); updateMarker('end', draft.end);
  }
  function openSheet(title, kind, html) {
    if ($('sheet-backdrop').hidden) lastFocus = document.activeElement; sheetKind = kind;
    $('sheet-title').textContent = title; $('sheet-content').innerHTML = html;
    $('sheet-backdrop').hidden = false; $('sheet-close').hidden = kind === 'consent';
    document.body.style.overflow = 'hidden'; $('sheet').focus(); document.querySelector('main').setAttribute('aria-hidden', 'true');
  }
  function closeSheet() {
    if (awaitingConsent) return;
    $('sheet-backdrop').hidden = true; document.body.style.overflow = ''; document.querySelector('main').removeAttribute('aria-hidden'); sheetKind = '';
    if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
  }
  function consentSheet() {
    awaitingConsent = true;
    openSheet('A map for your next move', 'consent', '<p>Choose how to plan your simulated journey. Online maps connect to public services only when you use their features.</p><div class="network-list"><div><strong>Map tiles</strong><span>OpenStreetMap</span></div><div><strong>Place search</strong><span>Android geocoding</span></div><div><strong>Driving routes</strong><span>OSRM routing service</span></div></div><p class="sheet-small">Online providers may receive your IP address and the map area, search terms, or route coordinates needed for your request. Place search uses your device’s geocoding provider. Their availability is not guaranteed. The app has no ads or analytics.</p><button class="primary-button" id="consent-yes">Use online maps</button><button class="secondary-button" id="consent-no">Coordinates only · direct lines offline</button>');
    $('consent-yes').addEventListener('click', () => { awaitingConsent = false; setOnline(true); closeSheet(); if (!locked()) buildRoute(); else render(); });
    $('consent-no').addEventListener('click', () => { awaitingConsent = false; if (!locked()) draft.routing = 'direct'; setOnline(false); closeSheet(); if (!locked()) { buildRoute(); coordinateSheet(); } else render(); });
  }
  const chevron = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>';
  function optionsSheet() {
    openSheet('Your traveler', 'options', '<button class="option-row" id="option-setup"><span class="option-copy"><strong>Android setup</strong><span>Enable this app as your mock location provider</span></span>'+chevron+'</button><button class="option-row" id="option-coordinates"><span class="option-copy"><strong>Enter coordinates</strong><span>Set precise latitude and longitude</span></span>'+chevron+'</button><button class="option-row" id="option-static" role="switch" aria-checked="'+draft.static+'"><span class="option-copy"><strong>Hold one location</strong><span>Stay at your starting point</span></span><span class="toggle '+(draft.static?'on':'')+'"></span></button><button class="option-row" id="option-repeat" role="switch" aria-checked="'+draft.repeat+'"><span class="option-copy"><strong>Return trip</strong><span>Travel back and forth until stopped</span></span><span class="toggle '+(draft.repeat?'on':'')+'"></span></button><button class="option-row" id="option-online" role="switch" aria-checked="'+Boolean(draft.online)+'"><span class="option-copy"><strong>Online maps</strong><span>OpenStreetMap, device geocoding and OSRM</span></span><span class="toggle '+(draft.online?'on':'')+'"></span></button><button class="option-row" id="option-privacy"><span class="option-copy"><strong>Privacy & app compatibility</strong><span>How location simulation works</span></span>'+chevron+'</button><p class="sheet-brand">Moving Traveler · an open source location simulator</p>');
    $('option-coordinates').disabled = locked(); $('option-static').disabled = locked(); $('option-repeat').disabled = locked() || draft.static;
    $('option-setup').addEventListener('click', setupSheet);
    $('option-coordinates').addEventListener('click', coordinateSheet);
    $('option-static').addEventListener('click', () => { draft.static = !draft.static; selection = 'start'; persist(); closeSheet(); buildRoute(); });
    $('option-repeat').addEventListener('click', () => { draft.repeat = !draft.repeat; persist(); optionsSheet(); render(); });
    $('option-online').addEventListener('click', () => { if (draft.online) { setOnline(false); optionsSheet(); if (!locked()) buildRoute(false); } else consentSheet(); });
    $('option-privacy').addEventListener('click', privacySheet);
  }
  function coordinateSheet() {
    if (locked()) return;
    openSheet('Set your points', 'coordinates', '<p>Enter decimal coordinates. North and east are positive; south and west are negative.</p><form class="coordinates-form" id="coordinates-form"><label for="coord-start-lat">STARTING POINT</label><div class="coordinate-fields"><div class="coordinate-field"><input id="coord-start-lat" type="text" inputmode="text" autocapitalize="off" spellcheck="false" placeholder="Latitude" aria-label="Start latitude" required><small>Latitude · −90 to 90</small></div><div class="coordinate-field"><input id="coord-start-lon" type="text" inputmode="text" autocapitalize="off" spellcheck="false" placeholder="Longitude" aria-label="Start longitude" required><small>Longitude · −180 to 180</small></div></div><div id="destination-fields"><label for="coord-end-lat">DESTINATION</label><div class="coordinate-fields"><div class="coordinate-field"><input id="coord-end-lat" type="text" inputmode="text" autocapitalize="off" spellcheck="false" placeholder="Latitude" aria-label="Destination latitude"><small>Latitude · −90 to 90</small></div><div class="coordinate-field"><input id="coord-end-lon" type="text" inputmode="text" autocapitalize="off" spellcheck="false" placeholder="Longitude" aria-label="Destination longitude"><small>Longitude · −180 to 180</small></div></div></div><div class="form-error" id="coordinate-error" role="alert" hidden></div><button class="primary-button" type="submit">Set points</button></form>');
    for (const kind of ['start','end']) { if (draft[kind]) { $('coord-'+kind+'-lat').value = draft[kind][0]; $('coord-'+kind+'-lon').value = draft[kind][1]; } }
    $('destination-fields').hidden = draft.static;
    $('coordinates-form').addEventListener('submit', event => {
      event.preventDefault();
      const parse = id => { const text = $(id).value.trim(); return /^[-+]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text) ? Number(text) : NaN; };
      const a = [parse('coord-start-lat'),parse('coord-start-lon')], b = [parse('coord-end-lat'),parse('coord-end-lon')];
      if (!validPoint(a) || (!draft.static && !validPoint(b))) { $('coordinate-error').textContent = 'Enter valid decimal coordinates for each point. Latitude must be −90 to 90 and longitude −180 to 180.'; $('coordinate-error').hidden = false; return; }
      draft.start = a; draft.startName = ''; if (!draft.static) { draft.end = b; draft.endName = ''; } persist(); closeSheet(); buildRoute();
    });
  }
  function setupSheet() {
    openSheet('Ready in a minute', 'setup', '<p>Android uses the locations supplied by the mock location app you select in Developer options.</p><div class="setup-steps"><div class="setup-step"><strong>Enable Developer options</strong><br>In Android Settings → About phone, tap Build number seven times. The exact path varies by device.</div><div class="setup-step"><strong>Select Moving Traveler</strong><br>In Developer options, open Select mock location app and choose Moving Traveler.</div><div class="setup-step"><strong>Start a journey</strong><br>Choose your points and pace. A persistent notification lets you stop the simulation from anywhere.</div></div><button class="primary-button" id="open-developer-settings">Open Developer options</button><button class="secondary-button" id="enable-notifications">Enable notification controls</button><button class="secondary-button" id="enable-compatibility" hidden>App compatibility</button><p class="sheet-small">Optional approximate location permission enables Google Play Services compatibility; your real location is not read.</p><p class="sheet-small">Keep your device location switched on. Some apps reject Android mock locations, so compatibility with any specific app is not guaranteed.</p>');
    $('open-developer-settings').addEventListener('click', () => { if (native) command({ action:'setup' }); else { closeSheet(); showMessage('Preview only. Android setup is available in the installed app.', true); } });
    renderSetupActions();
    $('enable-compatibility').addEventListener('click', () => command({ action:'compatibility' }));
    $('enable-notifications').addEventListener('click', () => { if (native) command({ action:'notifications' }); else { closeSheet(); showMessage('Notification controls are available in the Android app.', true); } });
  }
  function renderSetupActions() {
    $('enable-notifications').textContent = status.notifications ? 'Notifications enabled' : 'Enable notification controls';
    $('enable-notifications').disabled = Boolean(status.notifications);
    $('enable-compatibility').hidden = !(native && status.compatibilityPermission === false);
  }
  function privacySheet() {
    openSheet('Private by design', 'privacy', '<p>Your route draft and preferences stay on this device. The app has no account, ads, tracking SDKs, or analytics.</p><h3 class="privacy-title">Online services</h3><p>When enabled, map tiles go to OpenStreetMap, submitted place searches use your device’s Android geocoding provider, and road route coordinates go to the configured OSRM routing service. Online providers may receive your IP address and operate under their own policies. Turn Online maps off to use coordinates and direct lines without these requests.</p><h3 class="privacy-title">Android mock locations</h3><p>Optional approximate location permission is used only for Google Play Services mock-location compatibility; the app does not read your real location. Simulated locations are marked as mock by Android. Other apps may use them, ignore them, or reject them. WhatsApp live location compatibility is not guaranteed; this app does not access WhatsApp, send messages, or bypass detection.</p><h3 class="privacy-title">When a journey ends</h3><p>The destination remains held until you tap Stop. Pause holds your current simulated location. Stop removes this app’s mock providers. Other apps may keep a cached location briefly.</p><p class="sheet-small">Use simulation for your own testing and demonstrations. Make it clear to anyone viewing a shared location that it is simulated.</p><button class="secondary-button" id="full-privacy">Read full privacy policy</button>');
    $('full-privacy').addEventListener('click', () => { if (native) command({ action:'openPrivacy' }); else showMessage('The full privacy policy is included in the Android app.',true); });
  }
  function hideResults() { $('search-results').hidden = true; $('search-results').replaceChildren(); }
  function search() {
    if (locked()) return;
    const query = $('search-input').value.trim(); if (query.length < 2) { showMessage('Enter at least two characters to search for a place.'); return; }
    const resultBox = $('search-results'); resultBox.replaceChildren(); resultBox.hidden = false;
    const loading = document.createElement('div'); loading.className = 'search-empty'; loading.textContent = 'Searching places…'; resultBox.append(loading);
    const queryId = ++requestSequence; search.latest = queryId;
    network('search', { query }, data => {
      if (search.latest !== queryId || locked()) return;
      resultBox.replaceChildren();
      const results = Array.isArray(data) ? data.slice(0,6) : [];
      let count = 0;
      results.forEach(result => {
        const point = [Number(result.lat),Number(result.lon)]; if (!validPoint(point)) return;
        count++;
        const name = String(result.display_name || result.name || coordinates(point));
        const button = document.createElement('button'); button.type = 'button'; button.className = 'search-result';
        const strong = document.createElement('strong'), small = document.createElement('small');
        strong.textContent = name.split(',')[0]; small.textContent = name.includes(',') ? name.slice(name.indexOf(',')+1).trim() : coordinates(point);
        button.append(strong,small); resultBox.append(button);
        button.addEventListener('click', () => { setPoint(selection, point, name.split(',')[0]); $('search-input').value = ''; $('search-input').blur(); map.setView(point,14,{animate:false}); });
      });
      if (!count) { const empty = document.createElement('div'); empty.className='search-empty'; empty.textContent='No places found. Try a city, address, or enter coordinates in Options.'; resultBox.append(empty); }
    }, error => { if (search.latest !== queryId) return; resultBox.replaceChildren(); const item=document.createElement('div'); item.className='search-empty'; item.textContent=error; resultBox.append(item); });
  }
  function start() {
    if (locked() || !routePoints.length) return;
    showMessage('');
    if (native && !status.mockReady) { setupSheet(); return; }
    if (!native) { startPreview(); return; }
    startPending = true; render();
    command({ action:'start', points: routePoints, speedKmh: draft.speedKmh, mode: draft.static ? 'static' : draft.repeat ? 'pingpong' : 'once' });
    setTimeout(() => { if (startPending) { startPending=false; showMessage('The journey did not start. Check the mock location selection in Android setup, then try again.'); command({action:'ready'}); render(); } },10000);
  }
  function interpolate(points, meters) {
    let remaining = meters;
    for (let i=1;i<points.length;i++) { const segment = distance(points[i-1],points[i]); if (remaining<=segment) { const t=segment ? remaining/segment : 0; return [points[i-1][0]+(points[i][0]-points[i-1][0])*t, points[i-1][1]+(points[i][1]-points[i-1][1])*t]; } remaining-=segment; }
    return points[points.length-1];
  }
  function startPreview() {
    clearInterval(previewTimer); previewDistance=0; previewDirection=1; lastPreviewTime=performance.now();
    window.Traveler.onState({status:'running',lat:routePoints[0][0],lon:routePoints[0][1],progress:0,distanceMeters:0,totalMeters,speedKmh:draft.speedKmh});
    previewTimer=setInterval(() => {
      const now=performance.now(),elapsed=(now-lastPreviewTime)/1000; lastPreviewTime=now;
      if(status.status!=='running'||draft.static)return;
      previewDistance+=elapsed*draft.speedKmh/3.6*previewDirection;
      if(previewDistance>=totalMeters || previewDistance<0) {
        previewDistance=Math.max(0,Math.min(totalMeters,previewDistance));
        if(draft.repeat)previewDirection*=-1; else status.status='arrived';
      }
      const p=interpolate(routePoints,previewDistance);
      window.Traveler.onState({status:status.status,lat:p[0],lon:p[1],progress:totalMeters?previewDistance/totalMeters:0,distanceMeters:previewDistance,totalMeters,speedKmh:draft.speedKmh});
    },250);
  }
  window.Traveler = {
    onNetwork(response) {
      if (!response || typeof response.id !== 'string') return;
      const item=pending.get(response.id); if(!item)return;
      clearTimeout(item.timeout); pending.delete(response.id);
      if (response.ok) { let data=response.data; if(typeof data==='string'){try{data=JSON.parse(data);}catch(_){item.reject('The service returned an unreadable response.');return;}} item.resolve(data); }
      else item.reject(typeof response.error==='string' ? response.error : 'The service is unavailable. Please try again.');
    },
    onState(next) {
      if(!next || typeof next!=='object')return;
      const wasActive=active();
      status={...status,...next}; startPending=false;
      if (sheetKind === 'setup') renderSetupActions();
      if (Number.isFinite(next.speedKmh) && next.speedKmh>0 && pendingSpeed === null && document.activeElement !== $('speed-slider') && document.activeElement !== $('speed-input')) draft.speedKmh=Math.max(.5,Math.min(200,next.speedKmh));
      if (active() && next.mode) { draft.static = next.mode === 'static'; draft.repeat = next.mode === 'pingpong'; }
      if (active() && validPoint(next.routeStart)) { draft.start = next.routeStart; draft.startName = ''; }
      if (active() && validPoint(next.routeEnd)) { draft.end = next.routeEnd; draft.endName = ''; }
      if (Array.isArray(next.routePoints) && next.routePoints.length && next.routePoints.every(validPoint) && active()) {
        routeLoading = false; ++routeVersion; routePoints=next.routePoints; draft.start=routePoints[0]; draft.end=routePoints[routePoints.length-1]; totalMeters=routeLength(routePoints);
        if(next.mode) { draft.static=next.mode==='static'; draft.repeat=next.mode==='pingpong'; }
        updateMapRoute(!wasActive); persist();
      }
      if (active() && Number.isFinite(next.lat) && Number.isFinite(next.lon)) {
        const point=[next.lat,next.lon];
        if(!markers.live)markers.live=L.marker(point,{icon:L.divIcon({className:'map-marker',html:'<div class="live-dot"></div>',iconSize:[19,19],iconAnchor:[9.5,9.5]}),zIndexOffset:1000,interactive:false,keyboard:false}).addTo(map); else markers.live.setLatLng(point);
      } else if (!active() && markers.live) { markers.live.remove(); markers.live=null; }
      if (next.message)showMessage(String(next.message),next.status!=='error');
      else if(next.status==='running' && native)showMessage('');
      if (active() && native && typeof next.fusedStatus === 'string' && /^(unavailable|update failed)/i.test(next.fusedStatus)) showMessage('GPS mock location is active. This device did not accept the fused provider; some apps may not use the simulation.', true);
      if(wasActive&&!active()){ clearInterval(previewTimer); clearTimeout(speedSendTimer); speedSendTimer = null; pendingSpeed = null; updateMapRoute(false); }
      queuePaint();
    },
    onGeo(point) {
      if (!point || !validPoint([point.lat, point.lon])) { showMessage('This location link does not contain valid coordinates.'); return; }
      if (locked()) { showMessage('Stop the current simulation before opening another location.'); return; }
      setPoint('start', [point.lat, point.lon], ''); fitRoute(); render();
    },
    onBack() { if(!$('sheet-backdrop').hidden&&!awaitingConsent){closeSheet();return true;} if(!$('search-results').hidden){hideResults();return true;} return false; }
  };
  map.on('click', event => { hideResults(); if (!locked()) setPoint(selection,[event.latlng.lat,event.latlng.wrap().lng],''); });
  $('start-point').addEventListener('click',()=>{selection='start';render();}); $('end-point').addEventListener('click',()=>{selection='end';render();});
  $('fit-button').addEventListener('click',fitRoute);
  $('menu-button').addEventListener('click',optionsSheet); $('setup-button').addEventListener('click',setupSheet); $('offline-coordinates').addEventListener('click',coordinateSheet);
  $('sheet-close').addEventListener('click',closeSheet); $('sheet-backdrop').addEventListener('click',event=>{if(event.target===$('sheet-backdrop'))closeSheet();});
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'){if(!awaitingConsent)closeSheet();hideResults();}
    if(event.key==='Tab'&&!$('sheet-backdrop').hidden){const focusable=[...$('sheet').querySelectorAll('button:not([disabled]):not([hidden]),input:not([disabled]),[tabindex="0"]')].filter(element=>element.offsetParent!==null);if(!focusable.length){event.preventDefault();return;}const first=focusable[0],last=focusable[focusable.length-1];if(event.shiftKey&&(document.activeElement===first||document.activeElement===$('sheet'))){event.preventDefault();last.focus();}else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===$('sheet'))){event.preventDefault();first.focus();}}
  });
  $('road-button').addEventListener('click',()=>{if(locked())return;draft.routing='road';persist();buildRoute();}); $('direct-button').addEventListener('click',()=>{if(locked())return;draft.routing='direct';persist();buildRoute();});
  document.querySelectorAll('[data-speed]').forEach(button=>button.addEventListener('click',()=>setSpeed(button.dataset.speed)));
  $('speed-slider').addEventListener('input',event=>setSpeed(event.target.value,true,false));
  $('speed-slider').addEventListener('change',event=>setSpeed(event.target.value,true,true));
  $('speed-input').addEventListener('change',event=>{setSpeed(event.target.value);event.target.value=draft.speedKmh;}); $('speed-input').addEventListener('blur',()=>{$('speed-input').value=draft.speedKmh;});
  $('search-form').addEventListener('submit',event=>{event.preventDefault();search();}); $('search-input').addEventListener('input',()=>{search.latest=++requestSequence;hideResults();});
  $('start-button').addEventListener('click',start);
  $('pause-button').addEventListener('click',()=>{const action=status.status==='paused'?'resume':'pause';if(native)command({action});else window.Traveler.onState({status:action==='pause'?'paused':'running'});});
  $('stop-button').addEventListener('click',()=>{if(native)command({action:'stop'});else{clearInterval(previewTimer);window.Traveler.onState({status:'idle',progress:0});showMessage('Preview stopped. Your system location was never changed.',true);}});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){map.invalidateSize();command({action:'ready'});lastPreviewTime=performance.now();}});
  window.addEventListener('resize',()=>map.invalidateSize());
  $('preview-badge').hidden=native; if(!native)$('app-label').textContent='BROWSER PREVIEW';
  if(draft.online!==null)setOnline(draft.online); else { $('search-form').hidden=true; consentSheet(); }
  updateMapRoute(true); render(); if(draft.online!==null)buildRoute();
  command({action:'ready'});
})();
