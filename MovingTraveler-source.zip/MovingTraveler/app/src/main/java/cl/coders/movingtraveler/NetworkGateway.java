// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Online work stays off the UI/service thread and only targets configured providers. */
final class NetworkGateway {
    interface Callback { void accept(JSONObject response); }
    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private long lastRequest = -2000;
    private boolean pending;
    private volatile boolean closed;
    private volatile HttpURLConnection connection;

    NetworkGateway(Context context) { this.context = context.getApplicationContext(); }

    synchronized void request(String raw, Callback callback) {
        JSONObject request;
        try {
            if (raw.length() > 64_000) throw new IllegalArgumentException("Request too large");
            request = new JSONObject(raw);
            String type = request.getString("type");
            if (!"route".equals(type) && !"search".equals(type)) throw new IllegalArgumentException("Unsupported request");
        } catch (Exception e) { return; }
        long now = SystemClock.elapsedRealtime();
        if (pending || now - lastRequest < 1100) {
            callback.accept(result(request, null, "Please wait a moment before trying again."));
            return;
        }
        pending = true;
        lastRequest = now;
        executor.execute(() -> {
            JSONObject response;
            try {
                if (!onlineAllowed()) throw new IllegalStateException("Enable online maps in settings to search or request a road route.");
                Object data = "search".equals(request.getString("type")) ? search(request.getString("query")) : route(request);
                response = result(request, data, null);
            } catch (Exception e) {
                String text = e instanceof IllegalArgumentException || e instanceof IllegalStateException ? e.getMessage()
                        : "Couldn't reach the map service. Check your connection or use a direct route.";
                response = result(request, null, text);
            } finally {
                synchronized (this) { pending = false; }
            }
            if (!closed) callback.accept(response);
        });
    }

    private boolean onlineAllowed() { return context.getSharedPreferences("settings", 0).getBoolean("online", false); }

    @SuppressWarnings("deprecation")
    private JSONArray search(String query) throws Exception {
        query = query.trim();
        if (query.length() < 2 || query.length() > 200) throw new IllegalArgumentException("Enter a place name between 2 and 200 characters.");
        if (!Geocoder.isPresent()) throw new IllegalStateException("Place search isn't available on this device. Select a point on the map or enter coordinates.");
        List<Address> addresses = new Geocoder(context, Locale.getDefault()).getFromLocationName(query, 5);
        JSONArray result = new JSONArray();
        if (addresses != null) for (Address address : addresses) {
            if (!address.hasLatitude() || !address.hasLongitude()) continue;
            String label = address.getMaxAddressLineIndex() >= 0 ? address.getAddressLine(0) : address.getFeatureName();
            result.put(new JSONObject().put("lat", address.getLatitude()).put("lon", address.getLongitude()).put("display_name", label == null ? query : label));
        }
        return result;
    }

    private JSONObject route(JSONObject request) throws Exception {
        JSONArray points = request.getJSONArray("points");
        if (points.length() < 2 || points.length() > 50) throw new IllegalArgumentException("A road route needs 2 to 50 selected points.");
        StringBuilder coordinates = new StringBuilder();
        for (int i = 0; i < points.length(); i++) {
            JSONArray point = points.getJSONArray(i);
            double lat = point.getDouble(0), lon = point.getDouble(1);
            if (Double.isNaN(lat) || Double.isInfinite(lat) || Double.isNaN(lon) || Double.isInfinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new IllegalArgumentException("Invalid map coordinate");
            if (i != 0) coordinates.append(';');
            coordinates.append(String.format(Locale.US, "%.6f,%.6f", lon, lat));
        }
        URI base = URI.create(BuildConfig.ROUTING_BASE_URL);
        if (!"https".equals(base.getScheme()) || base.getHost() == null || base.getUserInfo() != null || base.getQuery() != null || base.getFragment() != null) throw new IllegalStateException("Routing service must use a valid HTTPS URL.");
        URL url = new URL(BuildConfig.ROUTING_BASE_URL.replaceAll("/+$", "") + "/route/v1/driving/" + coordinates + "?overview=full&geometries=geojson&steps=false");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        connection = c;
        try {
            c.setConnectTimeout(10_000); c.setReadTimeout(15_000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", "MovingTraveler/" + BuildConfig.VERSION_NAME + " (Android; location route simulator)");
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) throw new IllegalStateException("Road routing is unavailable right now. Try again later or select Direct line.");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    if (closed || !onlineAllowed()) throw new IllegalStateException("Online maps are disabled.");
                    if (bytes.size() + read > 4_000_000) throw new IllegalArgumentException("This route is too long. Choose a shorter journey.");
                    bytes.write(buffer, 0, read);
                }
            }
            JSONObject data = new JSONObject(bytes.toString(StandardCharsets.UTF_8.name()));
            if (!"Ok".equals(data.optString("code"))) throw new IllegalStateException("No road route found between these points. Choose nearby roads or use Direct line.");
            return data;
        } finally { c.disconnect(); connection = null; }
    }

    private JSONObject result(JSONObject request, Object data, String error) {
        JSONObject result = new JSONObject();
        try {
            result.put("id", request.opt("id")); result.put("type", request.optString("type"));
            result.put("ok", error == null);
            if (data != null) result.put("data", data);
            if (error != null) result.put("error", error);
        } catch (Exception ignored) { }
        return result;
    }

    void close() {
        closed = true;
        HttpURLConnection c = connection;
        if (c != null) c.disconnect();
        executor.shutdownNow();
    }
}
