// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.util.Collections;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private WebView web;
    private NetworkGateway network;
    private boolean pageReady, resumed, receiverRegistered;
    private String pendingPlan;
    private boolean sentRoute;
    private boolean awaitingPermissions;
    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { sendState(); }
    };

    @SuppressLint("SetJavaScriptEnabled") // Only bundled trusted assets execute; CSP, navigation and network allowlists isolate the bridge.
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SimulationService.active) MockPublisher.recoverStale(this);
        network = new NetworkGateway(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(248, 250, 249));
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom, left, right;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                top = bars.top; bottom = bars.bottom; left = bars.left; right = bars.right;
            } else {
                top = insets.getSystemWindowInsetTop(); bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft(); right = insets.getSystemWindowInsetRight();
            }
            // Android 15/16 enforce edge-to-edge; keep controls clear of bars and the keyboard.
            if (Build.VERSION.SDK_INT >= 35) v.setPadding(left, top, right, bottom);
            return insets;
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setGeolocationEnabled(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUserAgentString(s.getUserAgentString() + " MovingTraveler/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost()) && "https".equals(uri.getScheme())) {
                    String path = uri.getPath();
                    if (path == null || !path.startsWith("/assets/") || path.contains("..")) return blocked();
                    try {
                        String asset = path.substring(8);
                        String mime = asset.endsWith(".html") ? "text/html" : asset.endsWith(".css") ? "text/css" : asset.endsWith(".js") ? "application/javascript" : asset.endsWith(".txt") ? "text/plain" : "application/octet-stream";
                        return new WebResourceResponse(mime, "utf-8", 200, "OK", Collections.singletonMap("Cache-Control", "no-cache"), getAssets().open(asset));
                    } catch (Exception e) { return blocked(); }
                }
                if (!request.isForMainFrame() && "https".equals(uri.getScheme()) && "tile.openstreetmap.org".equals(uri.getHost()) && onlineAllowed()) return null;
                return blocked();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri.toString().equals(ORIGIN + "/assets/index.html")) return false;
                if (request.hasGesture() && "https".equals(uri.getScheme())) openExternal(uri);
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.equals(ORIGIN + "/assets/index.html")) { pageReady = true; sendState(); }
            }
        });
        web.loadUrl(ORIGIN + "/assets/index.html");
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private final class Bridge {
        @JavascriptInterface public void command(String json) {
            if (json == null || json.length() > 1_500_000) return;
            runOnUiThread(() -> handleCommand(json));
        }
        @JavascriptInterface public void request(String json) {
            if (json == null) return;
            network.request(json, result -> runOnUiThread(() -> evaluate("onNetwork", result.toString())));
        }
    }

    private void handleCommand(String json) {
        if (isDestroyed()) return;
        try {
            JSONObject c = new JSONObject(json);
            String action = c.getString("action");
            switch (action) {
                case "ready": pageReady = true; sendState(); handleGeoIntent(); break;
                case "consent":
                    getSharedPreferences("settings", 0).edit().putBoolean("online", c.getBoolean("online")).apply();
                    break;
                case "start":
                    if (!resumed || SimulationService.active) { sendState(); break; }
                    new RoutePlan(json); // Validate before entering foreground state or changing any provider.
                    if (!mockReady()) { showSetup(); break; }
                    pendingPlan = json;
                    if (!getPreferences(0).getBoolean("playbackPermissionsAsked", false)) {
                        new AlertDialog.Builder(this).setTitle("Playback permissions")
                                .setMessage("Approximate location permission enables Google Play Services mock-location compatibility. This app does not read your real location. Notifications provide pause and stop controls while another app is open.\n\nBoth are optional; Android mock providers work without them.")
                                .setPositiveButton("Continue", (d, w) -> {
                                    getPreferences(0).edit().putBoolean("playbackPermissionsAsked", true).apply();
                                    java.util.ArrayList<String> permissions = new java.util.ArrayList<>();
                                    if (com.google.android.gms.common.GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == com.google.android.gms.common.ConnectionResult.SUCCESS && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
                                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permissions.add(Manifest.permission.POST_NOTIFICATIONS);
                                    if (permissions.isEmpty()) startPending();
                                    else { awaitingPermissions = true; requestPermissions(permissions.toArray(new String[0]), 10); }
                                }).setNegativeButton("Skip", (d, w) -> {
                                    getPreferences(0).edit().putBoolean("playbackPermissionsAsked", true).apply(); startPending();
                                }).setOnCancelListener(d -> { pendingPlan = null; sendState(); }).show();
                    } else startPending();
                    break;
                case "pause": case "resume": case "stop": case "speed":
                    if (SimulationService.active) {
                        Intent intent = new Intent(this, SimulationService.class).setAction(action);
                        if ("speed".equals(action)) {
                            double value = c.getDouble("speedKmh");
                            if (Double.isNaN(value) || Double.isInfinite(value) || value < .5 || value > 200) throw new IllegalArgumentException("Speed must be between 0.5 and 200 km/h");
                            intent.putExtra("speedKmh", value);
                        }
                        startService(intent);
                    } else sendState();
                    break;
                case "setup": showSetup(); break;
                case "notifications":
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
                    else startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                    break;
                case "compatibility":
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
                    break;
                case "openPrivacy": showPrivacy(); break;
                default: break;
            }
        } catch (Exception e) { showError(e.getMessage() == null ? "Unable to complete this action" : e.getMessage()); }
    }

    private void startPending() {
        if (!resumed || awaitingPermissions) return;
        if (pendingPlan == null || SimulationService.active) { pendingPlan = null; return; }
        SimulationService.stagedPlan = pendingPlan;
        Intent intent = new Intent(this, SimulationService.class).setAction("start");
        pendingPlan = null;
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        } catch (RuntimeException e) { SimulationService.stagedPlan = null; showError("Couldn't start playback. Return to the app and try again."); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) { awaitingPermissions = false; web.post(this::startPending); }
        sendState();
    }

    private boolean onlineAllowed() { return getSharedPreferences("settings", 0).getBoolean("online", false); }

    @SuppressWarnings("deprecation")
    private boolean mockReady() {
        try {
            return ((AppOpsManager) getSystemService(APP_OPS_SERVICE)).checkOpNoThrow("android:mock_location", Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
        } catch (RuntimeException e) { return false; }
    }

    private void sendState() {
        try {
            JSONObject state = new JSONObject(SimulationService.state);
            state.put("mockReady", mockReady());
            state.put("notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
            state.put("onlineAllowed", onlineAllowed());
            state.put("compatibilityPermission", checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED);
            if (!SimulationService.active) sentRoute = false;
            if (SimulationService.active && !sentRoute && SimulationService.routePoints != null) {
                state.put("routePoints", new org.json.JSONArray(SimulationService.routePoints));
                sentRoute = true;
            }
            evaluate("onState", state.toString());
        } catch (Exception ignored) { }
    }

    private void evaluate(String method, String json) {
        if (!pageReady || web == null || isDestroyed()) return;
        web.evaluateJavascript("window.Traveler && window.Traveler." + method + "(" + json.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029") + ")", null);
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        if (!SimulationService.active) {
            try { evaluate("onState", new JSONObject().put("status", "error").put("message", message).put("mockReady", mockReady()).toString()); }
            catch (Exception ignored) { }
        }
    }

    private void showSetup() {
        new AlertDialog.Builder(this).setTitle("Allow location simulation")
                .setMessage("1. Open phone Settings → About phone. Tap Build number seven times to enable Developer options.\n\n2. In Developer options, open Select mock location app and choose Moving Traveler.\n\n3. Return here and start your route. Other apps decide whether to accept mock locations.")
                .setPositiveButton("Developer options", (d, w) -> {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
                    catch (RuntimeException e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                }).setNegativeButton("Close", null).show();
    }

    private void showPrivacy() {
        new AlertDialog.Builder(this).setTitle("Privacy & open source")
                .setMessage("Moving Traveler does not read your real GPS location and has no accounts, ads, or analytics. Optional approximate-location permission enables the Google Play Services mock compatibility path; no real location is retrieved. Route choices and online-map preferences are stored on this device. Clear app storage to erase them.\n\nIf online maps are enabled: map tiles go to OpenStreetMap; submitted searches go to Android's geocoding provider; road-route coordinates go to the configured OSRM service. Providers receive your IP address and request data, and may log them. Maps and route choices can reveal places of interest.\n\nMock locations are supplied to Android and, when available, Google Play Services so other apps can receive them. They remain marked as mock. Stop removes the test providers and disables Play Services mock mode.\n\nThis app is based on FakeTraveler (GPL-3.0-or-later). Leaflet is BSD-2-Clause. Map data © OpenStreetMap contributors; road routing by OSRM. See the included source and release privacy-policy draft for full notices.")
                .setPositiveButton("Close", null)
                .setNegativeButton("Licenses", (d, w) -> showLicenses())
                .setNeutralButton("Provider privacy", (d, w) -> openExternal(Uri.parse("https://osmfoundation.org/wiki/Privacy_Policy"))).show();
    }

    private void showLicenses() {
        WebView licenses = new WebView(this);
        licenses.getSettings().setJavaScriptEnabled(false);
        licenses.getSettings().setAllowFileAccess(false);
        licenses.getSettings().setAllowContentAccess(false);
        licenses.loadUrl("file:///android_asset/THIRD-PARTY-NOTICES.txt");
        new AlertDialog.Builder(this).setTitle("Open source licenses").setView(licenses)
                .setPositiveButton("Close", (d, w) -> licenses.destroy()).setOnCancelListener(d -> licenses.destroy()).show();
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (RuntimeException e) { Toast.makeText(this, "No browser is installed", Toast.LENGTH_SHORT).show(); }
    }

    private void handleBack() {
        web.evaluateJavascript("window.Traveler && window.Traveler.onBack()", result -> {
            if (!"true".equals(result)) moveTaskToBack(true);
        });
    }

    @SuppressWarnings("deprecation")
    @SuppressLint("GestureBackNavigation") // API33+ registers OnBackInvokedCallback; this handles only legacy button/back dispatch.
    @Override public void onBackPressed() { handleBack(); }

    private void handleGeoIntent() {
        Uri uri = getIntent().getData();
        if (uri == null || !"geo".equals(uri.getScheme()) || SimulationService.active) return;
        try {
            String point = uri.getSchemeSpecificPart().split("[?;]")[0];
            String[] parts = point.split(",");
            double lat = Double.parseDouble(parts[0]), lon = Double.parseDouble(parts[1]);
            if (Double.isNaN(lat) || Double.isInfinite(lat) || Double.isNaN(lon) || Double.isInfinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
            evaluate("onGeo", new JSONObject().put("lat", lat).put("lon", lon).toString());
            getIntent().setData(null);
        } catch (Exception ignored) { }
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleGeoIntent(); }
    @SuppressLint("UnspecifiedRegisterReceiverFlag") // Older OS branch has no flag; its receiver only re-reads our local state.
    @Override protected void onResume() {
        super.onResume(); resumed = true;
        IntentFilter filter = new IntentFilter(SimulationService.CHANGE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, RECEIVER_NOT_EXPORTED); else registerReceiver(updates, filter);
        receiverRegistered = true;
        if (web != null) { web.onResume(); sendState(); }
        if (pendingPlan != null) web.post(this::startPending);
    }
    @Override protected void onPause() {
        resumed = false;
        if (receiverRegistered) { unregisterReceiver(updates); receiverRegistered = false; }
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override protected void onDestroy() {
        network.close();
        if (web != null) { web.removeJavascriptInterface("Android"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
