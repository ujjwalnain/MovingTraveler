# Moving Traveler

An Android location simulator with a compact map interface, selectable start and destination, and adjustable movement speed. Inspired by [FakeTraveler](https://github.com/mcastillof/FakeTraveler), reference commit `ff7ddfdcbe0063d4f77a73e4817fcc078fd5df38`.

## What it does

- Choose points on the map, search a place, or enter latitude/longitude.
- Follow a driving-road route, or explicitly choose a direct line. Walk, Cycle and Drive are **speed presets**; the road service currently returns driving geometry for all three.
- Set 0.5–200 km/h, including changes during playback.
- Pause/resume, travel back and forth, or hold one stationary location.
- Hold the destination after arrival until Stop is pressed.
- Continue a user-started session in a foreground service with notification controls.
- Publish timestamped coordinates, speed, accuracy and bearing through GPS/network test providers, framework fused where supported, and optional Google Play Services fused mocking.
- Plan a direct route without network access using coordinates. Previously selected route settings stay on the device.

There are no accounts, ads, analytics, subscriptions or embedded API keys. The app does not read real GPS coordinates. Approximate-location permission is optional and enables the Google Play Services compatibility path; denying it leaves Android test providers available. Android mock locations remain identifiable as mock.

## Install and use

1. Install the supplied **debug APK** on an Android 6.0+ test phone. This is a test build, separate from the release application ID.
2. Enable Developer options (usually Settings → About phone → tap Build number seven times).
3. Open Developer options → **Select mock location app** → **Moving Traveler**.
4. Open Moving Traveler. Choose online maps or coordinate-only planning, set the route and speed, then tap **Start journey**. Optional permissions are explained before Android asks for them.
5. Use Pause/Resume or Stop in the app or notification. Arrival continues holding the destination until Stop. Force-stopping the process is not equivalent to an orderly Stop; reopen the app to attempt stale-provider cleanup.

To assess WhatsApp, start the simulation and use WhatsApp's **Share live location** with a willing test contact. A static “send current location” message will not animate. WhatsApp/OEM versions may reject mock locations or update at their own cadence. **WhatsApp compatibility has not been verified on a physical phone.** See the [device test plan](docs/DEVICE-TEST-PLAN.md).

## Build

Open this folder in Android Studio, or use JDK 17/21 with Android SDK Platform 36 and Build Tools 36.0.0 installed:

```sh
./gradlew testDebugUnitTest lintDebug lintRelease assembleDebug bundleRelease
```

The wrapper pins Gradle 8.13 and verifies its download checksum. AGP is 8.13.2. Configure `ANDROID_HOME` or a local `local.properties` file with `sdk.dir=/path/to/your/android-sdk`. Machine-specific paths, caches, and signing keys are excluded from the source archive.

Generated artifacts:

- `app/build/outputs/apk/debug/app-debug.apk`: signed with a debug certificate, for testing.
- `app/build/outputs/bundle/release/app-release.aab`: optimized **unsigned** release bundle. Sign a new bundle with your own upload key through Android Studio before Play submission.

The optional Gradle property `debugKeystore` can redirect debug signing to an existing debug keystore in restricted build environments. It is never a release signing setting.

For production road routing, provision an OSRM-compatible HTTPS service, then build with:

```sh
./gradlew -ProutingBaseUrl=https://your-routing-host.example bundleRelease
```

The default public OSRM endpoint is for evaluation and has no service guarantee. Internet use is opt-in. Map tiles use OpenStreetMap, place search uses Android Geocoder, and route requests use the configured OSRM service. Online providers receive request data and may retain logs. Finalize the [privacy policy](docs/PRIVACY-POLICY-DRAFT.md) for the providers you actually use.

## Release preparation

Read [PLAY-RELEASE.md](docs/PLAY-RELEASE.md) before uploading. Finalize the publisher-owned package ID, upload key, support contact, public privacy/source URLs, routing service, store assets and Play declarations. The working name, icon and listing can change later; the package ID establishes the app's update identity. Builds target API 36 and declare a reviewed `specialUse` foreground-service use case.

Actual checks and remaining limitations are recorded in [VERIFICATION.md](docs/VERIFICATION.md). A successful build is not evidence of Play approval or all-device performance.

## Source and licenses

New application source is GPL-3.0-or-later with the narrowly scoped Google Play Services linking permission in [COPYING-EXCEPTION.md](docs/COPYING-EXCEPTION.md). The implementation was written independently using FakeTraveler as a conceptual reference; no upstream Java implementation or launcher artwork is bundled. Leaflet 1.9.4 assets retain their BSD-2-Clause license, and the Gradle wrapper retains its Apache license. [UPSTREAM.md](UPSTREAM.md) preserves the reference project's README and attribution to Matías Castillo Felmer; it describes that upstream project, not this app's exact behavior.

Distribute corresponding source for every published app version. Google Play Services client libraries have their own terms and are not relicensed by this project. Bundled notices are available in the app's privacy dialog and `app/src/main/assets/THIRD-PARTY-NOTICES.txt`.
