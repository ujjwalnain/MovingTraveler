# Moving Traveler 1.2.0 verification — 14 September 2026

The APK contains MapLibre/OpenFreeMap map configuration and accepts a personal Geoapify key in Settings → Routing access. It does not need Google billing, Firebase or a deployed backend. The supplied build has no embedded routing key or publisher URLs. No Geoapify account was created and no live Geoapify route was requested.

## Completed checks

- The final source passed `testDebugUnitTest lintDebug lintRelease assembleDebug bundleRelease` with JDK 21, Gradle 8.13, AGP 8.13.2 and Android SDK 36. Version code is 3, version name 1.2.0, minimum API 23 and target API 36. Java 17 and core-library desugaring are enabled. MapLibre Native OpenGL 13.6.1 supports the selected renderer; the Vulkan-only artifact is not used.
- **102 Android tests passed**, with no failures, errors or skipped tests: 27 network, 19 native UI, 18 activity/lifecycle, 12 service, 10 map gesture/math, 9 route-sampling, 6 routing-credential and 1 route-engine test wrapping 84 assertions.
- Network fixtures verify explicit walking/cycling/driving profiles, coordinate order, preserved GeoJSON geometry, connected multi-leg joins, endpoint snapping, mode mismatch rejection, malformed/oversized responses, sanitized access/quota errors, independent request lanes, stale replies, cancellation and bounded deadlines. These fixtures do not establish real-world route coverage.
- Route tests verify chosen-pace distance, bearings, corners, final arrival, pause/resume without catch-up, reverse traversal, duplicate points and dateline/polar cases. The animation sampler follows route segments without advancing the service's playback state.
- Activity/UI checks cover progressive setup/retry actions, invalid pace edits, Pause/Resume, coordinate-only operation on API 23, stationary taps, original-versus-snapped endpoint retention, provider-data persistence rules, rotation during requests, restored picker text, optional-permission cancellation/rotation, duplicate-start prevention and dialog cleanup. Screenshots of native widgets in portrait/landscape were inspected; their map areas are explicitly marked as not loaded. They are not native map or physical-phone screenshots.
- Map gesture tests cover long-press release without movement, cancel, stale drag recovery and avoiding a request for an unchanged pin. Camera math includes dateline framing. They do not initialize an OpenGL renderer.
- Credential tests cover validation, missing settings, corrupt ciphertext, stale-cache prevention, invalid saves and clearing. Real Android Keystore encryption still needs a physical-device test.
- Service tests use a recording LocationManager shadow to check mock payloads/timestamps, notification controls, wake-lock lifetime, pace changes, holding, malformed plans, provider failures and permission revocation. They test the application's behavior at that boundary, not actual GPS or fused mock delivery.
- Debug and release lint report **zero errors and three warnings**, all newer-version notices for pinned build/test/location dependencies. Gradle reports deprecated plugin features; this project pins Gradle 8.13. D8 also reports a Play Services companion-metadata warning. The dependency is retained; optional fused delivery requires device verification.

## Live map service and packaging

OpenFreeMap's Liberty style, vector TileJSON, sprite metadata and one Delhi vector tile returned HTTP 200. The style was checked with a representative actual MapLibre Android user-agent. This verifies service access from this host, not rendering, regional reachability, uptime or performance on every phone.

The final debug APK passed APK signature verification and `zipalign -c -P 16 -v 4`. Its debug signing certificate matches the supplied 1.1.0 APK. Bundletool validated the final release AAB, which is intentionally unsigned. ZIP integrity passed for both packages. Their embedded native notices match the source asset byte-for-byte.

Both 64-bit MapLibre libraries (`arm64-v8a` and `x86_64`) have 16 KiB ELF load-segment alignment. The legacy 32-bit libraries have 4 KiB alignment. APK native entries passed 16 KiB ZIP alignment. These static checks do not replace running the final release on a 16 KiB Android device.

Both packages include 64 generated Maven notice entries and the exact 29-section MapLibre core-notice aggregate from tag `android-v13.6.1` / commit `c7506d6`. The aggregate is cross-platform and does not imply every listed component is in Android. It is accessible through Library licenses. Provider attribution remains visible with the map, route and search data.

The merged release manifest has the intended version/identity and no fine-location, background-location, Wi-Fi-state or vibration permission. Google Maps/Firebase setup metadata and initialization are absent. Optional Play Services location remains for mock compatibility. The source archive excludes old Google backend/setup files, local secrets, signing keys and build caches.

## Checks still required before public release

1. Add a Geoapify key and test representative walking, cycling and driving routes in target countries. Check geometry against the intended paths, one-way restrictions, near-road snapping, search, quota/access errors and recovery. The app rejects snaps beyond 1 km and oversized responses; worldwide coverage does not guarantee a route for every point.
2. Test a real Android phone: map loading, gestures, smooth playback, permission dialogs, haptics, Android Keystore, screen-off operation, notification actions, battery use and Stop cleanup. `adb devices` found no attached device during this verification. No successful emulator run is used as evidence.
3. Verify actual GPS/network/framework fused and optional Google Play Services mock delivery. WhatsApp live-location compatibility remains untested; receiving apps can reject mock data, cache it or change update frequency. Static location messages do not animate.
4. Choose the public routing-access model and suitable provider plan, supply publisher identity and HTTPS privacy/terms/source URLs, finalize the package, and sign with the publisher's upload key. Run the signed release on Play's internal track and complete Play Console declarations. No public deployment, store upload or Play approval has been performed.

Use [Routing setup](ROUTING-SETUP.md), [Device test plan](DEVICE-TEST-PLAN.md) and [Play release preparation](PLAY-RELEASE.md). The build and automated tests establish the checks above; they do not establish universal lag-free operation, perfect routes or receiving-app acceptance.
