# Routing setup — Moving Traveler 1.2

## Enable search and routes in the installed app

Moving Traveler displays maps through MapLibre Native and OpenFreeMap. The basemap has **no account, billing setup or API key**. Geoapify supplies place search and route geometry. Personal testing needs one Geoapify account; it does not need a Google Cloud account, Firebase or a server.

1. Open [Geoapify MyProjects](https://myprojects.geoapify.com/), register or sign in, create a project and copy its API key. Keep the key private; do not put it in screenshots, issue reports or chat messages.
2. In the installed Moving Traveler APK, open **Settings → Routing access**, paste the key and save it. **There is no rebuild step.** The planning button **Set up routing** leads to the same setup.
3. Enable online planning when prompted. That choice permits map requests to OpenFreeMap and search/route requests to Geoapify.
4. Choose a start and destination, select **Walk**, **Cycle** or **Drive**, and wait for the route preview. Confirm the geometry, distance and chosen pace, then tap **Start journey**.

Saving a key does not itself prove that the account is active or the quota is available. The first search/route request validates actual access. Without a key, map point selection, coordinates and explicit **Direct line** or **Stay at start** remain available. No account was created and no key was supplied as part of this source package.

## Provider limits and coverage

As checked on 14 September 2026, Geoapify's Free plan includes **3,000 credits/day**, up to **5 requests/second**, with **no credit card required**. Route cost depends on the request; an ordinary short two-point route generally costs one credit, with additional costs for longer routes or options. Search consumes the same Geoapify budget. The OpenFreeMap basemap does not consume Geoapify credits. Check the [current pricing](https://www.geoapify.com/pricing/) and [routing cost rules](https://apidocs.geoapify.com/docs/routing/) before relying on a budget.

The app maps Walk → `walk`, Cycle → `bicycle`, Drive → `drive`. These are documented Geoapify profiles. Coverage is worldwide, based on available map data; it can be incomplete or differ locally by mode. A valid key cannot create a missing path. Test representative places in the countries you need. Playback follows the chosen constant pace and does not reproduce live traffic. [Geoapify routing documentation](https://apidocs.geoapify.com/docs/routing/)

The app accepts responses up to **2 MB (2,000,000 bytes)** and routes with at most **20,000 returned vertices**. It rejects a route if either returned endpoint is more than **1 km** from the selected point. A snap beyond **50 m** shows a warning; playback follows the displayed route without adding a straight connector to the original pin. Move the pin nearer an accessible road/path or choose a shorter journey when these checks reject a result. These are application validation limits; Geoapify's coverage, account quotas and service limits apply separately.

**Back and forth** replays the same loaded path backwards at each endpoint. It does not calculate a separate return route or validate return-direction restrictions; a driving route can have different restrictions in the opposite direction.

OpenFreeMap currently permits commercial use of its free public service without request quotas, but provides no availability SLA. It is separate infrastructure, not a guarantee that the entire application is free to operate at any scale. Geoapify's pricing FAQ allows free commercial use with attribution, while its formal terms describe limits for production use. Confirm the intended public release against the selected plan and [Geoapify terms](https://www.geoapify.com/terms-and-conditions/); see [OpenFreeMap terms](https://openfreemap.org/tos/) and [service information](https://openfreemap.org/).

## If a route does not load

| What you see | Next step |
| --- | --- |
| Set up routing | Add a personal Geoapify key in Settings → Routing access. |
| Enable routes | Enable online planning; it is required for new network routes. |
| Choose start / Choose destination | Complete the missing point by map, search or coordinates. |
| Finding route | Wait for the bounded request; moving a point starts a newer request. |
| Retry route / access error | Check the key, account quota, connectivity and point/mode coverage, then retry. |
| Map visible, search/routes fail | The basemap and routing are separate services; check Geoapify access. |
| Map unavailable | Check connectivity and OpenFreeMap availability. Coordinates/direct simulation remains available. |

For no-route cases, move the point nearer a mapped road/path or try another suitable profile. Choose **Direct line** explicitly only when a straight simulated path is intended. The app does not silently present a direct line as a road route.

## Personal keys and public distribution

A key entered on the phone is stored using Android Keystore-backed AES-GCM and can be replaced or removed in Routing access. Removing a personal key falls back to a publisher key if the APK contains one; turning online planning off stops new routing requests. Clearing app storage removes app-local configuration, not a key compiled into the installed APK. Revoke a compromised key in Geoapify MyProjects. The app sends the key directly to Geoapify over HTTPS when searching/routing; a personal account's usage belongs to its owner.

Geoapify supports IP, origin and referrer restrictions. Browser origin/referrer restrictions are not an Android package/signing-certificate restriction, and a phone's IP can change. Do not assume a browser restriction will authenticate this APK. Test any account restrictions with the real Android client. [Geoapify key configuration](https://apidocs.geoapify.com/docs/places/)

A publisher may optionally set `GEOAPIFY_API_KEY` in ignored `secrets.properties`, or as a Gradle project property, before building. That embeds a reusable, **extractable** key in the client. Android Keystore does not make that compiled shared key secret. Before public release, choose and document either user-supplied keys with clear onboarding or an appropriately protected publisher service/key arrangement. A managed server/proxy is a possible later publisher decision, not a dependency of this personal-testing build. Do not publish an unrestricted shared test key as a production access strategy.

Finalize `PUBLIC_PRIVACY_URL`, `PUBLIC_TERMS_URL` and `PUBLIC_SOURCE_URL` for the publisher's HTTPS pages. These build-time publishing fields are separate from entering a routing key in the installed app.

## Data and verification

Map area requests go to OpenFreeMap; searches, chosen points, profile and key go to Geoapify. Those providers also receive network metadata and apply their own retention policies. See [privacy](PRIVACY-POLICY-DRAFT.md), [OpenFreeMap privacy](https://openfreemap.org/privacy/) and [Geoapify privacy](https://www.geoapify.com/privacy-policy/).

Automated tests use controlled responses. Live routes still need an account-key test, followed by physical-device checks of map rendering, mock delivery, background playback and Stop cleanup. Record results in [Verification](VERIFICATION.md). Do not treat a fixture pass as confirmation that every city, profile or receiving app works.
