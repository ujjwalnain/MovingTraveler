// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Native map and controls. Road geometry is resolved once; playback runs on the device. */
public final class MainActivity extends Activity implements JourneyUi.Listener {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private JourneyUi ui;
    private NetworkGateway network;
    private MapSurface mapSurface;
    private ValueAnimator motion;
    private RouteEngine visualPath;
    private double[][] visualGeometry;
    private String visualMode = "";
    private double visualDistance = Double.NaN;
    private PlanningSession session;
    private Draft draft;
    private boolean started, resumed, registered, wasActive;
    private boolean routeLoading, routeFailed, permissionsPending;
    private boolean mapLoaded;
    private String mapError = "";
    private long sequence;
    private int selection = -1, commandGeneration;
    private String message = "", pendingAction = "", pendingPlan;
    private AlertDialog pointDialog, permissionDialog, routingDialog;
    private boolean permissionExplanation;
    private PointPicker currentPicker;
    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { readState(); }
    };

    /** Retained only in process. Provider geometry and search labels are never saved to disk. */
    static final class Draft {
        double[] start, end;
        boolean startFromProvider, endFromProvider;
        String startLabel = "", endLabel = "", travel = "walk", playback = "once", kind = "road";
        double speed = 5, distance, startSnapMeters, endSnapMeters;
        String routeWarning = "";
        double[][] geometry;
        JSONArray startAttributions = new JSONArray(), endAttributions = new JSONArray();
    }

    static final class Retained {
        PlanningSession session;
        String plan, pickerQuery;
        int selection = -1;
        Boolean pickerDestination;
        boolean permissionsPending, explanation;
    }

    /** Survives rotation without repeating a billable route request. No Activity is retained. */
    static final class PlanningSession {
        final Draft draft;
        final NetworkGateway network;
        final Handler main = new Handler(Looper.getMainLooper());
        MainActivity owner;
        long generation;
        boolean loading, failed, closed;
        String message = "", errorCode = "";
        PlanningSession(Context context, Draft draft) {
            this.draft = draft; network = new NetworkGateway(context.getApplicationContext());
        }
        void notifyOwner(boolean fit) {
            if (owner == null || owner.isDestroyed()) return;
            owner.routeLoading = loading; owner.routeFailed = failed; owner.message = message;
            owner.drawRoute(fit); owner.render();
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (!SimulationService.active) MockPublisher.recoverStale(this);
        Object retained = getLastNonConfigurationInstance();
        Retained memory = retained instanceof Retained ? (Retained) retained : null;
        session = memory == null ? new PlanningSession(this, restoreDraft()) : memory.session;
        draft = session.draft; session.owner = this;
        routeLoading = session.loading; routeFailed = session.failed; message = session.message;
        if (memory != null) selection = memory.selection;
        if (memory != null && memory.plan != null) {
            pendingPlan = memory.plan; pendingAction = "start";
            permissionsPending = memory.permissionsPending; permissionExplanation = memory.explanation;
        }
        boolean needsConsent = settings().getInt("openMapConsentVersion", 0) < 1;
        if (needsConsent) settings().edit().putBoolean("online", false).apply();
        network = session.network;
        ui = new JourneyUi(this, this);
        setContentView(ui.root());
        ui.root().setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 35) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            }
            return insets;
        });
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        setupMap(state == null ? null : state.getBundle("map"));
        readState();
        if (!SimulationService.active && draft.geometry == null && !session.loading) refreshRoute();
        handleGeoIntent();
        if (needsConsent) handler.post(this::showOnlineChoice);
        if (permissionExplanation) handler.post(this::showPermissionRationale);
        if (memory != null && memory.pickerDestination != null) handler.post(() -> {
            if (!locked()) new PointPicker(memory.pickerDestination, memory.pickerQuery).show();
        });
    }

    private SharedPreferences settings() { return getSharedPreferences("settings", MODE_PRIVATE); }
    private boolean online() { return settings().getBoolean("online", false); }
    private boolean routingConfigured() { return !RoutingCredentials.get(this).isEmpty(); }
    private boolean locked() { return SimulationService.active || !pendingAction.isEmpty(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void haptic() {
        ui.root().performHapticFeedback(Build.VERSION.SDK_INT >= 30
                ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.VIRTUAL_KEY);
    }

    private void setupMap(Bundle saved) {
        destroyMap(); ui.mapContainer.removeAllViews(); mapError = "";
        if (!online()) {
            TextView placeholder = text("Your journey starts here\n\nEnable the map to choose points, or enter coordinates.", 16);
            placeholder.setGravity(Gravity.CENTER);
            placeholder.setPadding(dp(28), dp(32), dp(28), dp(24));
            placeholder.setOnClickListener(v -> showOnlineChoice());
            ui.mapContainer.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
            updateHint(); return;
        }
        try {
            mapSurface = new MapSurface(this, ui.mapContainer, new MapSurface.Listener() {
                private boolean announced;
                @Override public void onTap(double lat, double lon) { mapTapped(lat, lon); }
                @Override public void onDrag(boolean destination, double lat, double lon) {
                    setPoint(destination, new double[]{lat, lon}, "", false);
                }
                @Override public void onReady() {
                    boolean fit = !announced && saved == null; announced = true;
                    mapLoaded = true; mapError = ""; drawRoute(fit); readState();
                }
                @Override public void onMapError(String error) { mapError = error; updateHint(); }
            });
            mapSurface.create(saved);
            if (started) mapSurface.start();
            if (resumed) mapSurface.resume();
            drawRoute(false); updateHint();
        } catch (RuntimeException | LinkageError error) {
            destroyMap();
            mapError = "The map could not start on this device. You can still enter coordinates.";
            TextView unavailable = text(mapError, 16); unavailable.setGravity(Gravity.CENTER);
            unavailable.setPadding(dp(24), dp(32), dp(24), dp(24));
            unavailable.setOnClickListener(v -> setupMap(null));
            ui.mapContainer.addView(unavailable, new FrameLayout.LayoutParams(-1, -1)); updateHint();
        }
    }

    private void destroyMap() {
        if (motion != null) { motion.cancel(); motion = null; }
        if (mapSurface != null) { mapSurface.destroy(); mapSurface = null; }
        mapLoaded = false; visualDistance = Double.NaN;
    }

    private void mapTapped(double latitude, double longitude) {
        if (locked()) return;
        if ("static".equals(draft.playback)) {
            setPoint(false, new double[]{latitude, longitude}, "", false);
            return;
        }
        if (selection >= 0 || draft.start == null || draft.end == null) {
            boolean destination = selection == 1 || (selection < 0 && draft.start != null);
            setPoint(destination, new double[]{latitude, longitude}, "", false);
        } else {
            new AlertDialog.Builder(this).setTitle("Use this point")
                    .setItems(new String[]{"Set start", "Set destination"}, (dialog, index) ->
                            setPoint(index == 1, new double[]{latitude, longitude}, "", false)).show();
        }
    }

    private void setPoint(boolean destination, double[] point, String label, boolean fromProvider) {
        if (locked() || !validPoint(point)) return;
        haptic();
        String shown = label == null || label.isEmpty() ? coordinates(point) : label;
        if (destination) { draft.end = point; draft.endLabel = shown; draft.endFromProvider = fromProvider; }
        else { draft.start = point; draft.startLabel = shown; draft.startFromProvider = fromProvider; }
        if (destination) draft.endAttributions = new JSONArray(); else draft.startAttributions = new JSONArray();
        selection = -1;
        saveDraft();
        refreshRoute();
    }

    private static boolean validPoint(double[] p) {
        return p != null && p.length == 2 && Double.isFinite(p[0]) && Double.isFinite(p[1])
                && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180;
    }
    private static String coordinates(double[] p) {
        return String.format(Locale.US, "%.5f, %.5f", p[0], p[1]);
    }
    static double[] parseCoordinates(String raw) {
        try {
            String[] parts = raw.trim().split(",", -1);
            if (parts.length != 2) return null;
            double[] point = {Double.parseDouble(parts[0].trim()), Double.parseDouble(parts[1].trim())};
            return validPoint(point) ? point : null;
        } catch (NumberFormatException ignored) { return null; }
    }

    private void refreshRoute() {
        if (locked()) return;
        network.cancel("route");
        long expected = ++session.generation;
        session.loading = session.failed = false; session.errorCode = "";
        session.message = ""; routeLoading = routeFailed = false; message = "";
        draft.geometry = null; draft.distance = 0; draft.routeWarning = "";
        draft.startSnapMeters = draft.endSnapMeters = 0;
        if (draft.start == null || (!"static".equals(draft.playback) && draft.end == null)) {
            session.notifyOwner(true); return;
        }
        if ("static".equals(draft.playback) || "direct".equals(draft.kind)) {
            try { setGeometry(draft, "static".equals(draft.playback) ? new double[][]{draft.start}
                    : new double[][]{draft.start, draft.end}); }
            catch (IllegalArgumentException error) { session.message = error.getMessage(); }
            session.notifyOwner(true); return;
        }
        if (!online() || !routingConfigured()) {
            session.message = !online() ? "Enable online planning to find a road route."
                    : "Add your free routing key once to find walking, cycling and driving routes.";
            session.notifyOwner(true); return;
        }
        session.loading = true; session.message = "Finding a route along roads and paths…";
        session.notifyOwner(true);
        final PlanningSession requested = session;
        try {
            JSONObject request = new JSONObject().put("id", String.valueOf(expected)).put("type", "route")
                    .put("points", new JSONArray(new double[][]{draft.start, draft.end}))
                    .put("travelMode", "cycle".equals(draft.travel) ? "BICYCLE" : draft.travel.toUpperCase(Locale.ROOT));
            network.request(request.toString(), result -> requested.main.post(() -> {
                if (requested.closed || requested.generation != expected) return;
                requested.loading = false;
                if (result.optBoolean("ok")) {
                    try {
                        JSONObject data = result.getJSONObject("data");
                        JSONArray a = data.getJSONArray("points"); double[][] points = new double[a.length()][2];
                        for (int i = 0; i < a.length(); i++) {
                            points[i][0] = a.getJSONArray(i).getDouble(0); points[i][1] = a.getJSONArray(i).getDouble(1);
                        }
                        setGeometry(requested.draft, points);
                        requested.draft.startSnapMeters = data.optDouble("startSnapMeters", 0);
                        requested.draft.endSnapMeters = data.optDouble("endSnapMeters", 0);
                        double snap = Math.max(requested.draft.startSnapMeters, requested.draft.endSnapMeters);
                        requested.draft.routeWarning = snap > 50 ? String.format(Locale.US,
                                "Nearest accessible path is %.0f m from a selected point. Playback follows the displayed route.", snap) : "";
                        requested.message = ""; requested.failed = false; requested.errorCode = "";
                    } catch (Exception invalid) {
                        requested.failed = true; requested.message = "This route could not be read. Choose nearby points and retry.";
                        requested.errorCode = "INVALID_RESPONSE";
                    }
                } else {
                    requested.failed = true; requested.message = result.optString("error", "Could not find a route. Try again.");
                    requested.errorCode = result.optString("errorCode");
                }
                requested.notifyOwner(true);
            }));
        } catch (Exception invalid) {
            session.loading = false; session.failed = true; session.message = "Could not request the route.";
            session.notifyOwner(false);
        }
    }

    private static void setGeometry(Draft draft, double[][] points) {
        RouteEngine engine = new RouteEngine(points, draft.speed, draft.playback);
        if (!"static".equals(draft.playback) && engine.current().totalMeters < 1)
            throw new IllegalArgumentException("Choose points at least one metre apart.");
        draft.geometry = points; draft.distance = engine.current().totalMeters;
    }

    private void drawRoute(boolean fit) {
        if (mapSurface == null) return;
        mapSurface.drawRoute(draft.start, draft.end, draft.startLabel, draft.endLabel,
                draft.geometry, "static".equals(draft.playback), locked(), fit);
    }

    private void moveTraveler(JSONObject state) {
        if (mapSurface == null || !state.has("lat") || draft.geometry == null) return;
        if (visualGeometry != draft.geometry || !visualMode.equals(draft.playback)) {
            visualGeometry = draft.geometry; visualMode = draft.playback;
            visualPath = new RouteEngine(draft.geometry, draft.speed, draft.playback); visualDistance = Double.NaN;
        }
        double target = state.optDouble("distanceMeters") + state.optInt("leg", 0) * state.optDouble("totalMeters");
        if (motion != null) { motion.cancel(); motion = null; }
        boolean followsPath = "running".equals(state.optString("status")) || "arrived".equals(state.optString("status"));
        if (!resumed || Double.isNaN(visualDistance) || !followsPath
                || target < visualDistance || Math.abs(target - visualDistance) < .001) {
            showTravelerAt(target); return;
        }
        double from = visualDistance;
        motion = ValueAnimator.ofFloat(0, 1); motion.setDuration(950);
        motion.setInterpolator(new android.view.animation.LinearInterpolator());
        motion.addUpdateListener(animation -> showTravelerAt(from + (target - from) * (float) animation.getAnimatedValue()));
        motion.start();
    }
    private void showTravelerAt(double distance) {
        if (mapSurface == null || visualPath == null) return;
        visualDistance = distance;
        RouteEngine.Sample sample = visualPath.sampleAtDistance(distance);
        mapSurface.moveTraveler(sample.latitude, sample.longitude, sample.bearingDegrees);
    }

    @Override public void onPrimary() {
        if (!pendingAction.isEmpty()) return;
        if (SimulationService.active) {
            try {
                String status = new JSONObject(SimulationService.state).optString("status");
                if ("arrived".equals(status) || "static".equals(draft.playback)) return;
                sendPlayback("paused".equals(status) ? "resume" : "pause");
            } catch (Exception ignored) { }
        } else if (draft.start == null) onPoint(false);
        else if (draft.end == null && !"static".equals(draft.playback)) onPoint(true);
        else if (draft.geometry == null && "road".equals(draft.kind) && !"static".equals(draft.playback) && !online()) showOnlineChoice();
        else if (draft.geometry == null && "road".equals(draft.kind) && !"static".equals(draft.playback)
                && (!routingConfigured() || "AUTH".equals(session.errorCode))) showRoutingSetup();
        else if (routeFailed) { haptic(); refreshRoute(); }
        else beginStart();
    }
    @Override public void onStopPlayback() { if (SimulationService.active && pendingAction.isEmpty()) sendPlayback("stop"); }

    private void beginStart() {
        if (!resumed || draft.geometry == null || routeLoading || locked()) return;
        if (!mockReady()) { showSetup(); return; }
        try {
            pendingPlan = new JSONObject().put("points", new JSONArray(draft.geometry))
                    .put("speedKmh", draft.speed).put("mode", draft.playback).toString();
            new RoutePlan(pendingPlan);
            SimulationService.state = "{\"status\":\"idle\"}";
            pendingAction = "start"; message = "Starting journey…"; haptic(); render();
            if (!settings().getBoolean("playbackPermissionsAsked", false)) showPermissionRationale();
            else dispatchStart();
        } catch (Exception error) { clearPending(); message = "Could not start this route."; render(); }
    }

    private void showPermissionRationale() {
        if (isDestroyed() || isFinishing() || pendingPlan == null) return;
        permissionsPending = true; permissionExplanation = true;
        permissionDialog = new AlertDialog.Builder(this).setTitle("Playback permissions")
                .setMessage("Approximate location enables Google Play Services mock-location compatibility. Moving Traveler does not read your actual location. Notifications give you playback controls while another app is open.\n\nBoth permissions are optional.")
                .setPositiveButton("Continue", (dialog, which) -> {
                    permissionExplanation = false;
                    settings().edit().putBoolean("playbackPermissionsAsked", true).apply();
                    ArrayList<String> permissions = new ArrayList<>();
                    if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == ConnectionResult.SUCCESS
                            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        permissions.add(Manifest.permission.POST_NOTIFICATIONS);
                    if (permissions.isEmpty()) { permissionsPending = false; dispatchStart(); }
                    else requestPermissions(permissions.toArray(new String[0]), 10);
                }).setNegativeButton("Skip", (dialog, which) -> {
                    permissionsPending = permissionExplanation = false;
                    settings().edit().putBoolean("playbackPermissionsAsked", true).apply(); dispatchStart();
                }).setOnCancelListener(dialog -> { clearPending(); message = ""; render(); }).create();
        permissionDialog.show();
    }

    private void dispatchStart() {
        if (!resumed || permissionsPending || pendingPlan == null) return;
        if (SimulationService.active) { clearPending(); readState(); return; }
        SimulationService.stagedPlan = pendingPlan;
        pendingPlan = null;
        try {
            Intent intent = new Intent(this, SimulationService.class).setAction("start");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
            armCommandTimeout();
        } catch (RuntimeException error) {
            SimulationService.stagedPlan = null;
            clearPending(); message = "Couldn't start playback. Return to the app and try again."; render();
        }
    }
    private void sendPlayback(String action) {
        if (!SimulationService.active || !pendingAction.isEmpty()) return;
        haptic(); pendingAction = action; render();
        try { startService(new Intent(this, SimulationService.class).setAction(action)); armCommandTimeout(); }
        catch (RuntimeException error) { clearPending(); message = "Playback control failed. Try again."; render(); }
    }
    private void armCommandTimeout() {
        int expected = ++commandGeneration;
        handler.postDelayed(() -> {
            if (isDestroyed() || expected != commandGeneration || pendingAction.isEmpty()) return;
            if ("start".equals(pendingAction) && !SimulationService.active) SimulationService.stagedPlan = null;
            clearPending(); message = "Playback did not respond. Check the notification and try again."; readState();
        }, 10_000);
    }
    private void clearPending() { commandGeneration++; pendingAction = ""; pendingPlan = null; permissionsPending = permissionExplanation = false; }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == 10) { permissionsPending = false; handler.post(this::dispatchStart); }
        readState();
    }

    private void readState() {
        if (ui == null || isDestroyed()) return;
        try {
            JSONObject state = new JSONObject(SimulationService.state);
            boolean active = SimulationService.active;
            String status = state.optString("status", "idle");
            boolean acknowledged = ("start".equals(pendingAction) && active)
                    || ("pause".equals(pendingAction) && ("paused".equals(status) || "arrived".equals(status)))
                    || ("resume".equals(pendingAction) && ("running".equals(status) || "arrived".equals(status)))
                    || ("stop".equals(pendingAction) && !active) || "error".equals(status);
            if (acknowledged) { clearPending(); message = ""; }
            if (active) {
                draft.speed = state.optDouble("speedKmh", draft.speed);
                draft.playback = state.optString("mode", draft.playback);
                if (!wasActive && SimulationService.routePoints != null) {
                    draft.geometry = SimulationService.routePoints;
                    // Preserve user-selected endpoints. A cold service restore has unknown provenance;
                    // conservatively keep those derived coordinates in memory only.
                    if (draft.start == null) { draft.start = draft.geometry[0]; draft.startFromProvider = true; }
                    if (draft.end == null) { draft.end = draft.geometry[draft.geometry.length - 1]; draft.endFromProvider = true; }
                    if (draft.startLabel.isEmpty()) draft.startLabel = coordinates(draft.start);
                    if (draft.endLabel.isEmpty()) draft.endLabel = coordinates(draft.end);
                    draft.distance = state.optDouble("totalMeters");
                    drawRoute(false);
                }
                moveTraveler(state);
            } else if (wasActive) {
                if (motion != null) motion.cancel();
                if (mapSurface != null) mapSurface.clearTraveler();
                visualDistance = Double.NaN;
                drawRoute(false);
            }
            drawRoute(false);
            wasActive = active;
            if ("error".equals(status)) message = state.optString("message", "Playback stopped.");
            render();
        } catch (Exception ignored) { render(); }
    }

    private void render() {
        if (ui == null) return;
        boolean active = SimulationService.active;
        String status = routeFailed ? "route_error" : "idle", shown = message;
        double remaining = draft.distance / (draft.speed / 3.6);
        if (active) try {
            JSONObject state = new JSONObject(SimulationService.state);
            status = state.optString("status", "running");
            shown = state.optString("message", "");
            remaining = Math.max(0, state.optDouble("totalMeters") - state.optDouble("distanceMeters")) / (draft.speed / 3.6);
        } catch (Exception ignored) { }
        boolean canStart = !routeLoading && draft.geometry != null;
        if (!active && pendingAction.isEmpty() && !routeLoading) {
            if (draft.start == null) { status = "select_start"; canStart = true; }
            else if (draft.end == null && !"static".equals(draft.playback)) { status = "select_destination"; canStart = true; }
            else if (draft.geometry == null && "road".equals(draft.kind) && !"static".equals(draft.playback)) {
                if (!online()) { status = "online_required"; canStart = true; }
                else if (!routingConfigured() || "AUTH".equals(session.errorCode)) { status = "setup_required"; canStart = true; }
                else if (routeFailed) { status = "route_error"; canStart = true; }
            }
        }
        if (draft.geometry != null && !draft.routeWarning.isEmpty() && !active)
            shown += (shown.isEmpty() ? "" : "\n") + draft.routeWarning;
        ui.render(status, shown, draft.startLabel, draft.endLabel, draft.speed, draft.distance, remaining,
                active, !pendingAction.isEmpty(), canStart, draft.travel, draft.playback, draft.kind, routeLoading);
        renderAttributions();
        updateHint();
    }
    private void renderAttributions() {
        android.text.SpannableStringBuilder credits = new android.text.SpannableStringBuilder();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        if ("road".equals(draft.kind) && draft.geometry != null && !"static".equals(draft.playback)) {
            credits.append("Powered by Geoapify");
            credits.setSpan(new android.text.style.URLSpan("https://www.geoapify.com/"), 0, credits.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            credits.append(" · "); int begin = credits.length(); credits.append("© OpenStreetMap");
            credits.setSpan(new android.text.style.URLSpan("https://www.openstreetmap.org/copyright"), begin, credits.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            seen.add("Geoapifyhttps://www.geoapify.com/");
            seen.add("OpenStreetMaphttps://www.openstreetmap.org/copyright");
        }
        JSONArray[] sources = "static".equals(draft.playback) ? new JSONArray[]{draft.startAttributions}
                : new JSONArray[]{draft.startAttributions, draft.endAttributions};
        for (JSONArray list : sources) for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i); if (item == null) continue;
            String provider = item.optString("provider"); String url = item.optString("providerUri");
            if (provider.isEmpty() || !seen.add(provider + url)) continue;
            credits.append(credits.length() == 0 ? "Place data: " : " · ");
            int begin = credits.length(); credits.append(provider);
            if (url.startsWith("https://") || url.startsWith("http://")) {
                credits.setSpan(new android.text.style.ClickableSpan() {
                    @Override public void onClick(View view) { openExternal(Uri.parse(url)); }
                }, begin, credits.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        ui.setAttributions(credits);
    }

    private void updateHint() {
        if (!online()) ui.setMapHint("Enable map in Settings · coordinates also work");
        else if (!mapError.isEmpty()) ui.setMapHint(mapError);
        else if (!mapLoaded) ui.setMapHint("Loading map…");
        else if (SimulationService.active) ui.setMapHint("Simulated location · " + ("static".equals(draft.playback) ? "Holding" : "Following route"));
        else if (selection == 0 || draft.start == null) ui.setMapHint("Tap the map to choose your start");
        else if (selection == 1 || (draft.end == null && !"static".equals(draft.playback))) ui.setMapHint("Tap the map to choose your destination");
        else if ("static".equals(draft.playback)) ui.setMapHint("Tap to move the stationary point");
        else if (routeLoading) ui.setMapHint("Finding a route along roads and paths…");
        else ui.setMapHint("Long press a pin to adjust it");
    }

    @Override public void onSpeed(double speed) {
        if (!Double.isFinite(speed) || speed < .5 || speed > 200 || !pendingAction.isEmpty()) return;
        draft.speed = speed; saveDraft();
        if (SimulationService.active) {
            try { startService(new Intent(this, SimulationService.class).setAction("speed").putExtra("speedKmh", speed)); }
            catch (RuntimeException error) { message = "Couldn't change the pace. Try again."; }
        }
        render();
    }
    @Override public void onPreset(String mode, double speed) {
        if (locked()) return;
        if (!"walk".equals(mode) && !"cycle".equals(mode) && !"drive".equals(mode)) return;
        boolean changed = !draft.travel.equals(mode);
        draft.travel = mode; draft.speed = speed; haptic(); saveDraft();
        if (changed && "road".equals(draft.kind) && !"static".equals(draft.playback)) refreshRoute(); else render();
    }

    @Override public void onOptions() {
        if (locked()) return;
        String[] choices = {"Road route", "Direct line", "One way · hold destination", "Back and forth", "Stay at start", "Swap start and destination", "Clear route"};
        new AlertDialog.Builder(this).setTitle("Route options").setItems(choices, (dialog, index) -> {
            if (locked()) return;
            haptic();
            String previousKind = draft.kind, previousPlayback = draft.playback;
            switch (index) {
                case 0: draft.kind = "road"; if ("static".equals(draft.playback)) draft.playback = "once"; break;
                case 1: draft.kind = "direct"; if ("static".equals(draft.playback)) draft.playback = "once"; break;
                case 2: draft.playback = "once"; break;
                case 3: draft.playback = "pingpong"; break;
                case 4: draft.playback = "static"; break;
                case 5:
                    double[] p = draft.start; draft.start = draft.end; draft.end = p;
                    String label = draft.startLabel; draft.startLabel = draft.endLabel; draft.endLabel = label;
                    boolean from = draft.startFromProvider; draft.startFromProvider = draft.endFromProvider; draft.endFromProvider = from;
                    JSONArray attribution = draft.startAttributions; draft.startAttributions = draft.endAttributions; draft.endAttributions = attribution;
                    break;
                case 6: draft.start = draft.end = null; draft.startLabel = draft.endLabel = ""; draft.startAttributions = new JSONArray(); draft.endAttributions = new JSONArray(); break;
                default: return;
            }
            selection = -1; saveDraft();
            boolean samePath = ((index == 2 || index == 3) && !"static".equals(previousPlayback))
                    || ((index == 0 || index == 1) && previousKind.equals(draft.kind)
                        && previousPlayback.equals(draft.playback));
            // Back-and-forth playback reverses the same geometry without a new route request.
            if (samePath) { if (draft.geometry != null) setGeometry(draft, draft.geometry); render(); }
            else refreshRoute();
        }).show();
    }

    @Override public void onPoint(boolean destination) {
        if (locked()) return;
        new PointPicker(destination, null).show();
    }

    private final class PointPicker {
        final boolean destination;
        final String restoredQuery;
        final LinearLayout content = new LinearLayout(MainActivity.this), results = new LinearLayout(MainActivity.this);
        final EditText input = new EditText(MainActivity.this);
        final TextView status = text("Search for a place, or enter latitude, longitude.", 14);
        long generation;
        boolean closed;
        Runnable debounce;
        AlertDialog dialog;
        PointPicker(boolean destination, String query) { this.destination = destination; restoredQuery = query; }
        void show() {
            if (pointDialog != null) pointDialog.dismiss();
            currentPicker = this;
            content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(22), dp(8), dp(22), 0);
            results.setOrientation(LinearLayout.VERTICAL);
            input.setSingleLine(true); input.setHint("Place or coordinates"); input.setTextSize(16);
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            content.addView(input, new LinearLayout.LayoutParams(-1, dp(56))); content.addView(status);
            ScrollView scroll = new ScrollView(MainActivity.this); scroll.addView(results);
            content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(180)));
            TextView attribution = text("Powered by Geoapify · OpenStreetMap", 11);
            attribution.setPadding(0, dp(8), 0, dp(6)); content.addView(attribution);
            dialog = new AlertDialog.Builder(MainActivity.this).setTitle(destination ? "Choose destination" : "Choose start")
                    .setView(content).setPositiveButton("Use coordinates", null)
                    .setNeutralButton("Choose on map", (d, w) -> { selection = destination ? 1 : 0; updateHint(); })
                    .setNegativeButton("Cancel", null).create();
            pointDialog = dialog;
            dialog.setOnDismissListener(d -> {
                closed = true; generation++; if (debounce != null) handler.removeCallbacks(debounce);
                network.cancel("search");
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
                if (pointDialog == dialog) pointDialog = null;
                if (currentPicker == this) currentPicker = null;
            });
            dialog.show();
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setVisibility(mapSurface == null || !mapSurface.ready() ? View.GONE : View.VISIBLE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                double[] point = parseCoordinates(input.getText().toString());
                if (point != null) { setPoint(destination, point, "", false); dialog.dismiss(); }
                else if (!routingConfigured()) { dialog.dismiss(); showRoutingSetup(); }
                else input.setError("Use latitude, longitude within valid ranges.");
            });
            input.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
                @Override public void onTextChanged(CharSequence value, int start, int before, int count) { scheduleSearch(value.toString()); }
                @Override public void afterTextChanged(Editable value) { }
            });
            double[] existing = destination ? draft.end : draft.start;
            String initial = restoredQuery != null ? restoredQuery : existing == null ? "" : coordinates(existing);
            input.setText(initial); input.setSelection(input.length());
            if (initial.isEmpty()) scheduleSearch("");
        }
        void scheduleSearch(String query) {
            generation++; network.cancel("search");
            if (debounce != null) handler.removeCallbacks(debounce);
            results.removeAllViews();
            boolean coordinates = parseCoordinates(query) != null;
            Button use = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            use.setText(!coordinates && !routingConfigured() ? "Set up routing" : "Use coordinates");
            use.setEnabled(coordinates || !routingConfigured());
            if (coordinates) { status.setText(R.string.search_coordinates_ready); return; }
            if (!routingConfigured()) { status.setText(R.string.search_setup_needed); return; }
            if (query.trim().length() < 3) { status.setText(R.string.search_minimum); return; }
            if (query.matches("[+\\-0-9.,\\s]+")) { status.setText(R.string.search_coordinate_hint); return; }
            if (!online()) { status.setText(R.string.search_offline); return; }
            status.setText(R.string.search_loading);
            long expected = generation;
            debounce = () -> {
                try {
                    JSONObject request = new JSONObject().put("type", "search").put("id", String.valueOf(++sequence))
                            .put("query", query.trim());
                    network.request(request.toString(), response -> runOnUiThread(() -> {
                        if (closed || expected != generation || isDestroyed()) return;
                        if (!response.optBoolean("ok")) { status.setText(response.optString("error", "Search failed. Edit your search to retry.")); return; }
                        JSONArray list = response.optJSONArray("data");
                        status.setText(list == null || list.length() == 0 ? "No places found. Try an address, nearby landmark or map point." : "Choose a place");
                        if (list != null) for (int i = 0; i < list.length(); i++) {
                            JSONObject place = list.optJSONObject(i); if (place == null) continue;
                            Button item = new Button(MainActivity.this); item.setAllCaps(false); item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                            item.setText(place.optString("label")); item.setMinHeight(dp(52)); item.setTextSize(14);
                            item.setOnClickListener(v -> {
                                double[] point = {place.optDouble("lat", Double.NaN), place.optDouble("lon", Double.NaN)};
                                if (!validPoint(point)) { status.setText(R.string.place_no_coordinates); return; }
                                setPoint(destination, point, place.optString("label"), true);
                                JSONArray credits = place.optJSONArray("attributions");
                                if (credits != null) {
                                    if (destination) draft.endAttributions = credits; else draft.startAttributions = credits;
                                }
                                renderAttributions(); dialog.dismiss();
                            });
                            results.addView(item, new LinearLayout.LayoutParams(-1, -2));
                        }
                    }));
                } catch (Exception invalid) { status.setText(R.string.search_failure); }
            };
            handler.postDelayed(debounce, 600);
        }
    }

    @Override public void onSettings() {
        ArrayList<String> choices = new ArrayList<>();
        choices.add(online() ? "Turn off online planning" : "Enable map and routes");
        choices.add("Routing access"); choices.add("Mock location setup");
        choices.add("Notifications and compatibility"); choices.add("Privacy and licenses");
        if (online() && !mapError.isEmpty()) choices.add("Reload map");
        new AlertDialog.Builder(this).setTitle("Settings").setItems(choices.toArray(new String[0]), (dialog, which) -> {
            switch (which) {
                case 0: if (online()) setOnline(false); else showOnlineChoice(); break;
                case 1: showRoutingSetup(); break;
                case 2: showSetup(); break;
                case 3: openExternal(Uri.parse("package:" + getPackageName()), Settings.ACTION_APPLICATION_DETAILS_SETTINGS); break;
                case 4: showPrivacy(); break;
                case 5: setupMap(null); break;
                default: break;
            }
        }).show();
    }
    private void showOnlineChoice() {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this).setTitle("Enable map and routes?")
                .setMessage("OpenFreeMap receives the map areas you view. Geoapify receives your place searches and selected route points when you add routing access. Providers receive network metadata. The app does not read your actual GPS location.\n\nMovement runs on your phone. You can also use direct paths and coordinates offline.")
                .setPositiveButton("Enable", (dialog, which) -> setOnline(true))
                .setNegativeButton("Coordinates only", (dialog, which) -> {
                    if (!locked()) { draft.kind = "direct"; draft.geometry = null; saveDraft(); }
                    setOnline(false);
                }).show();
    }
    private void setOnline(boolean enabled) {
        settings().edit().putBoolean("online", enabled).putInt("openMapConsentVersion", 1).apply();
        network.cancel("all"); ++session.generation; session.loading = false; routeLoading = false;
        if (pointDialog != null) pointDialog.dismiss();
        setupMap(null);
        if (!locked() && draft.geometry == null) refreshRoute(); else render();
    }
    private void showRoutingSetup() {
        if (isFinishing() || isDestroyed()) return;
        if (routingDialog != null) routingDialog.dismiss();
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), dp(6));
        TextView description = text("The map works now. Add your free Geoapify API key to search places and calculate road routes worldwide. No card or Google billing is needed.\n\nCreate a project at myprojects.geoapify.com, then copy its API key here. Usage counts toward your provider plan.", 14);
        content.addView(description);
        TextView state = text(routingConfigured() ? "Routing access saved. Leave blank to keep it." : "No routing key saved yet.", 13);
        state.setPadding(0, dp(12), 0, dp(4)); content.addView(state);
        EditText key = new EditText(this); key.setHint("Geoapify API key"); key.setSingleLine(true);
        key.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setSaveEnabled(false);
        if (Build.VERSION.SDK_INT >= 26) key.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        content.addView(key, new LinearLayout.LayoutParams(-1, dp(56)));
        if (routingConfigured()) {
            Button clear = new Button(this); clear.setText(R.string.routing_key_remove); clear.setAllCaps(false);
            clear.setOnClickListener(v -> {
                RoutingCredentials.clear(this); key.setText("");
                state.setText(routingConfigured() ? "Using the publisher's configured access." : "Saved routing key removed.");
                network.cancel("all"); ++session.generation; session.loading = false; routeLoading = false;
                session.errorCode = "";
                if (!locked() && draft.geometry == null) refreshRoute(); else render();
            }); content.addView(clear);
        }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Routing access").setView(content)
                .setPositiveButton("Save key", null).setNegativeButton("Close", null)
                .setNeutralButton("Get free key", (d, w) -> openExternal(Uri.parse("https://myprojects.geoapify.com/"))).create();
        routingDialog = dialog;
        dialog.setOnDismissListener(d -> { key.setText(""); if (routingDialog == dialog) routingDialog = null; });
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String value = key.getText().toString().trim();
            if (value.isEmpty() && routingConfigured()) { dialog.dismiss(); return; }
            if (!RoutingCredentials.valid(value)) { key.setError("Paste the API key from your Geoapify project."); return; }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            key.setEnabled(false);
            for (int i = 0; i < content.getChildCount(); i++)
                if (content.getChildAt(i) instanceof Button) content.getChildAt(i).setEnabled(false);
            state.setText(R.string.routing_key_saving);
            Context app = getApplicationContext();
            PlanningSession savingSession = session;
            Thread saver = new Thread(() -> {
                boolean saved;
                try { RoutingCredentials.save(app, value); saved = true; } catch (Exception unavailable) { saved = false; }
                final boolean success = saved;
                savingSession.main.post(() -> {
                    if (!isDestroyed() && !isFinishing()) {
                        if (!success) { state.setText(R.string.routing_key_save_failure);
                            key.setEnabled(true);
                            for (int i = 0; i < content.getChildCount(); i++)
                                if (content.getChildAt(i) instanceof Button) content.getChildAt(i).setEnabled(true);
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true); return; }
                        key.setText(""); dialog.dismiss();
                    }
                    MainActivity owner = savingSession.owner;
                    if (!success || savingSession.closed || owner == null || owner.isDestroyed() || owner.isFinishing()) return;
                    savingSession.errorCode = ""; owner.haptic();
                    if (!owner.online()) owner.showOnlineChoice(); else if (!owner.locked()) owner.refreshRoute(); else owner.render();
                });
            }, "Save-routing-access"); saver.start();
        });
    }
    @SuppressWarnings("deprecation") private boolean mockReady() {
        try { return ((AppOpsManager) getSystemService(APP_OPS_SERVICE)).checkOpNoThrow("android:mock_location", Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED; }
        catch (RuntimeException error) { return false; }
    }
    private void showSetup() {
        new AlertDialog.Builder(this).setTitle("Allow location simulation")
                .setMessage("1. Open Settings → About phone and tap Build number seven times to enable Developer options.\n\n2. Open Developer options → Select mock location app → Moving Traveler.\n\n3. Return here and start your journey. Other apps decide whether to accept mock locations.")
                .setPositiveButton("Developer options", (dialog, which) -> {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
                    catch (RuntimeException error) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                }).setNegativeButton("Close", null).show();
    }
    private void showPrivacy() {
        new AlertDialog.Builder(this).setTitle("Privacy and licenses")
                .setMessage("Moving Traveler does not retrieve your actual GPS location. Approximate-location permission enables optional Google Play Services mock-location delivery.\n\nOpenFreeMap provides the map. Geoapify receives searches and selected route points directly when routing access is configured. They can process network metadata and keep logs under their policies. Turning online planning off stops new map, search and route requests.\n\nManual coordinate drafts stay on your device. Search results and road geometry remain in memory for this session. Your saved routing key is encrypted with Android Keystore. There are no added ads or analytics.\n\nApplication code is GPL-3.0-or-later with a Google Play Services linking permission. MapLibre and other libraries retain their own licenses.")
                .setPositiveButton("Close", null).setNegativeButton("Privacy policy", (d, w) -> {
                    if (BuildConfig.PUBLIC_PRIVACY_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_PRIVACY_URL));
                    else toast("The publisher's public privacy policy must be configured before release.");
                }).setNeutralButton("More", (d, w) -> new AlertDialog.Builder(this).setTitle("Providers and source")
                        .setItems(new String[]{"Geoapify privacy", "OpenFreeMap privacy", "Open source licenses", "Application source", "App terms"}, (dialog, index) -> {
                            if (index == 0) openExternal(Uri.parse("https://www.geoapify.com/privacy-policy/"));
                            if (index == 1) openExternal(Uri.parse("https://openfreemap.org/privacy/"));
                            if (index == 2) showLicenses();
                            if (index == 3) {
                                if (BuildConfig.PUBLIC_SOURCE_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_SOURCE_URL));
                                else toast("See the included source archive. The publisher must add a public source URL before release.");
                            }
                            if (index == 4) {
                                if (BuildConfig.PUBLIC_TERMS_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_TERMS_URL));
                                else toast("The publisher's public terms must be configured before release.");
                            }
                        }).show()).show();
    }
    private void showLicenses() {
        String licenses;
        try (java.io.InputStream in = getAssets().open("THIRD-PARTY-NOTICES.txt")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int n; while ((n = in.read(buffer)) != -1) bytes.write(buffer, 0, n);
            licenses = bytes.toString("UTF-8");
        } catch (Exception ignored) { licenses = "See the corresponding source archive for complete licenses."; }
        TextView body = text(licenses, 13); body.setPadding(dp(20), dp(12), dp(20), dp(12));
        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        new AlertDialog.Builder(this).setTitle("Open source licenses").setView(scroll).setPositiveButton("Close", null)
                .setNeutralButton("Library licenses", (dialog, which) -> LicenseViewer.show(this)).show();
    }
    private TextView text(String value, int size) {
        TextView text = new TextView(this); text.setText(value); text.setTextSize(size); text.setTextColor(Color.rgb(49,65,61)); return text;
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private void openExternal(Uri uri) { openExternal(uri, Intent.ACTION_VIEW); }
    private void openExternal(Uri uri, String action) {
        try { startActivity(new Intent(action, uri)); } catch (RuntimeException error) { toast("No app is available to open this."); }
    }

    private Draft restoreDraft() {
        Draft value = new Draft();
        try {
            JSONObject json = new JSONObject(getSharedPreferences("nativeDraft", 0).getString("value", "{}"));
            value.start = savedPoint(json.optJSONArray("start")); value.end = savedPoint(json.optJSONArray("end"));
            value.startLabel = value.start == null ? "" : coordinates(value.start);
            value.endLabel = value.end == null ? "" : coordinates(value.end);
            value.speed = Math.max(.5, Math.min(200, json.optDouble("speed", 5)));
            if (!Double.isFinite(value.speed)) value.speed = 5;
            String travel = json.optString("travel", "walk");
            if ("walk".equals(travel) || "cycle".equals(travel) || "drive".equals(travel)) value.travel = travel;
            String playback = json.optString("playback", "once");
            if ("once".equals(playback) || "pingpong".equals(playback) || "static".equals(playback)) value.playback = playback;
            value.kind = "direct".equals(json.optString("kind")) ? "direct" : "road";
        } catch (Exception ignored) { }
        return value;
    }
    private double[] savedPoint(JSONArray array) {
        if (array == null || array.length() != 2) return null;
        double[] p = {array.optDouble(0), array.optDouble(1)}; return validPoint(p) ? p : null;
    }
    private void saveDraft() {
        try {
            JSONObject json = new JSONObject().put("speed", draft.speed).put("travel", draft.travel)
                    .put("playback", draft.playback).put("kind", draft.kind);
            if (draft.start != null && !draft.startFromProvider) json.put("start", new JSONArray(draft.start));
            if (draft.end != null && !draft.endFromProvider) json.put("end", new JSONArray(draft.end));
            getSharedPreferences("nativeDraft", 0).edit().putString("value", json.toString()).apply();
        } catch (Exception ignored) { }
    }
    static double[] parseGeoUri(Uri uri) {
        if (uri == null || !"geo".equals(uri.getScheme())) return null;
        String raw = uri.getEncodedSchemeSpecificPart();
        int question = raw.indexOf('?');
        if (question >= 0) {
            for (String pair : raw.substring(question + 1).split("&")) {
                int equals = pair.indexOf('=');
                if (equals >= 0 && "q".equals(Uri.decode(pair.substring(0, equals)))) {
                    String query = Uri.decode(pair.substring(equals + 1)).replace('+', ' ');
                    int label = query.indexOf('('); if (label >= 0) query = query.substring(0, label);
                    return parseCoordinates(query);
                }
            }
        }
        return parseCoordinates(Uri.decode(raw.split("[?;]", 2)[0]));
    }
    private void handleGeoIntent() {
        Uri uri = getIntent().getData();
        if (uri == null || !"geo".equals(uri.getScheme()) || locked()) return;
        getIntent().setData(null);
        double[] point = parseGeoUri(uri);
        if (point != null) setPoint(false, point, "", false);
        else toast("Choose the shared place by name or enter its coordinates.");
    }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleGeoIntent(); }
    private void handleBack() {
        if (selection >= 0) { selection = -1; updateHint(); } else moveTaskToBack(true);
    }
    @SuppressWarnings("deprecation") @SuppressLint("GestureBackNavigation")
    @Override public void onBackPressed() { handleBack(); }
    @Override public Object onRetainNonConfigurationInstance() {
        Retained value = new Retained(); value.session = session; value.plan = pendingPlan;
        value.selection = selection;
        if (currentPicker != null) { value.pickerDestination = currentPicker.destination; value.pickerQuery = currentPicker.input.getText().toString(); }
        value.permissionsPending = permissionsPending; value.explanation = permissionExplanation;
        return value;
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (mapSurface != null) { Bundle mapState = new Bundle(); mapSurface.saveState(mapState); state.putBundle("map", mapState); }
    }
    @Override protected void onStart() {
        super.onStart(); started = true;
        if (mapSurface != null) mapSurface.start();
    }
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override protected void onResume() {
        super.onResume(); resumed = true;
        if (!registered) {
            IntentFilter filter = new IntentFilter(SimulationService.CHANGE);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, RECEIVER_NOT_EXPORTED); else registerReceiver(updates, filter);
            registered = true;
        }
        if (mapSurface != null) mapSurface.resume();
        readState();
        if (pendingPlan != null) handler.post(this::dispatchStart);
    }
    @Override protected void onPause() {
        resumed = false;
        if (registered) { unregisterReceiver(updates); registered = false; }
        if (motion != null) motion.cancel();
        visualDistance = Double.NaN;
        if (mapSurface != null) mapSurface.pause();
        super.onPause();
    }
    @Override protected void onStop() {
        started = false;
        if (mapSurface != null) mapSurface.stop();
        super.onStop();
    }
    @Override public void onLowMemory() { super.onLowMemory(); if (mapSurface != null) mapSurface.lowMemory(); }
    @Override protected void onDestroy() {
        if (pointDialog != null) pointDialog.dismiss();
        if (permissionDialog != null) permissionDialog.dismiss();
        if (routingDialog != null) routingDialog.dismiss();
        handler.removeCallbacksAndMessages(null);
        if (session != null) {
            if (session.owner == this) session.owner = null;
            if (!isChangingConfigurations()) { session.closed = true; session.network.close(); session.main.removeCallbacksAndMessages(null); }
        }
        if (ui != null) destroyMap();
        super.onDestroy();
    }
}
