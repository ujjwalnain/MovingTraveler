// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertSame;
import static org.robolectric.Shadows.shadowOf;

import android.Manifest;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Looper;
import android.os.Process;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import org.maplibre.android.maps.MapView;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;
import org.robolectric.shadows.ShadowAlertDialog;
import org.robolectric.util.ReflectionHelpers;

/**
 * Native activity lifecycle regressions with online planning disabled. Android
 * records service Intents; these tests do not start mock providers, contact map
 * services, or initialize the native MapLibre renderer. API 35 covers the runtime
 * notification-request branch, API 23 checks coordinate-only operation, and
 * configuration changes exercise retained planning state without API calls.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = Application.class, qualifiers = "w360dp-h740dp-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
public final class MainActivityTest {
    private static final String MANUAL_ROUTE = "{\"start\":[28.6001,77.2001],\"end\":[28.6201,77.2301],"
            + "\"speed\":5,\"kind\":\"direct\",\"playback\":\"once\",\"travel\":\"walk\"}";
    private ActivityController<MainActivity> controller;
    private MainActivity activity;

    @Before public void resetSession() {
        SimulationService.active = false;
        SimulationService.state = "{\"status\":\"idle\"}";
        SimulationService.stagedPlan = null;
        SimulationService.routePoints = null;
        application().getSharedPreferences("settings", 0).edit().clear()
                .putBoolean("online", false).putInt("openMapConsentVersion", 1).commit();
        application().getSharedPreferences("nativeDraft", 0).edit().clear().commit();
        RoutingCredentials.clear(application());
        drainServiceIntents();
    }

    @After public void cleanupSession() {
        if (controller != null) controller.pause().stop().destroy();
        SimulationService.active = false;
        SimulationService.state = "{\"status\":\"idle\"}";
        SimulationService.stagedPlan = null;
        SimulationService.routePoints = null;
        drainServiceIntents();
    }

    @Test public void offlineLaunchOffersChooseStartWithoutCreatingMapOrStartingPlayback() {
        launch();
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertTrue(button("Choose start").isEnabled());
        assertNull(nextServiceIntent());
    }

    @Test @Config(sdk = 23)
    public void api23CoordinatesRemainUsableWithoutMapsOrRoutingCredentials() throws Exception {
        saveDraft("{\"kind\":\"direct\"}");
        launch();
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertTrue(button("Choose start").isEnabled());

        enterCoordinates(false, "28.6139,77.2090");
        enterCoordinates(true, "28.6200,77.2200");
        assertTrue(button("Start journey").isEnabled());
        assertEquals(28.6139, savedDraft().getJSONArray("start").getDouble(0), 0);
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertNull(nextServiceIntent());
    }

    @Test public void coordinatesCanPlanAnOfflineRouteAndRejectInvalidNumbers() throws Exception {
        saveDraft("{\"kind\":\"direct\"}");
        launch();
        enterCoordinates(false, " 28.6139, 77.2090 ");
        enterCoordinates(true, "28.6200, 77.2200");
        assertTrue(button("Start journey").isEnabled());
        JSONObject saved = savedDraft();
        assertEquals(28.6139, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2200, saved.getJSONArray("end").getDouble(1), 0);
        assertArrayEquals(new double[]{-90, 180}, MainActivity.parseCoordinates("-90, 180"), 0);
        for (String bad : new String[]{"91,0", "0,181", "NaN,0", "Infinity,0", "1,2,3", "one,two", ""}) {
            assertNull(bad, MainActivity.parseCoordinates(bad));
        }
        assertNull(nextServiceIntent());
    }

    @Test public void successiveStationaryMapTapsUpdateStartWithoutCreatingHiddenDestination() throws Exception {
        saveDraft("{\"kind\":\"direct\",\"playback\":\"static\"}");
        launch();
        tapMap(28.6139, 77.2090);
        tapMap(28.6200, 77.2200);
        JSONObject saved = savedDraft();
        assertEquals(28.6200, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2200, saved.getJSONArray("start").getDouble(1), 0);
        assertFalse("Stationary map taps must not create an invisible destination", saved.has("end"));
        assertTrue(button("Start location").isEnabled());
        assertNull(nextServiceIntent());
    }

    @Test public void stationaryMapTapUpdatesStartEvenWhenOldJourneyHasDestination() throws Exception {
        saveDraft(MANUAL_ROUTE.replace("\"once\"", "\"static\""));
        launch();
        tapMap(28.6300, 77.2400);
        JSONObject saved = savedDraft();
        assertEquals(28.6300, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2400, saved.getJSONArray("start").getDouble(1), 0);
        assertEquals("A hidden previous destination must remain unchanged", 28.6201,
                saved.getJSONArray("end").getDouble(0), 0);
        assertTrue(button("Start location").isEnabled());
        assertNull(nextServiceIntent());
    }

    @Test public void rationaleSurvivesBackgroundResumeWithoutStartingUntilExplicitSkip() {
        readyRoute();
        activity.onPrimary();
        AlertDialog rationale = rationale();
        assertTrue(rationale.isShowing());
        assertFalse(button("Please wait…").isEnabled());
        controller.pause().stop().start().resume();
        idle();
        assertNull("Returning to the app must not choose Skip for the user", nextServiceIntent());
        assertNull(SimulationService.stagedPlan);
        rationale.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
        idle();
        assertSingleStart();
        controller.pause().resume();
        idle();
        assertNull("Resume must not enqueue another start", nextServiceIntent());
    }

    @Test public void cancellingPermissionRationaleImmediatelyRestoresReadyControls() {
        readyRoute();
        activity.onPrimary();
        rationale().cancel();
        idle();
        assertTrue(button("Start journey").isEnabled());
        assertNull(nextServiceIntent());
        assertNull(SimulationService.stagedPlan);
        controller.pause().resume();
        idle();
        assertNull("A cancelled start cannot return on resume", nextServiceIntent());
    }

    @Test public void recreationKeepsPermissionExplanationAndStartsOnlyAfterChoice() {
        readyRoute();
        activity.onPrimary();
        AlertDialog previous = rationale();
        controller.recreate();
        activity = controller.get();
        idle();
        AlertDialog restored = rationale();
        assertFalse("The old activity must release its dialog window", previous.isShowing());
        assertTrue(restored.isShowing());
        assertNull(nextServiceIntent());
        restored.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
        idle();
        assertSingleStart();
    }

    @Test @Config(sdk = 35)
    public void recreationDuringRuntimePermissionRequestContinuesOnceEvenWhenDenied() {
        shadowOf(application()).denyPermissions(Manifest.permission.POST_NOTIFICATIONS);
        readyRoute();
        activity.onPrimary();
        rationale().getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        idle();
        assertNotNull("API 35 must request the optional notification permission",
                shadowOf(activity).getLastRequestedPermission());
        assertNull(nextServiceIntent());
        controller.recreate();
        activity = controller.get();
        idle();
        assertNull("Recreation must still wait for the platform permission result", nextServiceIntent());
        activity.onRequestPermissionsResult(10, new String[]{Manifest.permission.POST_NOTIFICATIONS},
                new int[]{PackageManager.PERMISSION_DENIED});
        idle();
        assertSingleStart();
        activity.onRequestPermissionsResult(10, new String[]{Manifest.permission.POST_NOTIFICATIONS},
                new int[]{PackageManager.PERMISSION_DENIED});
        idle();
        assertNull("A duplicate callback must not duplicate the service start", nextServiceIntent());
    }

    @Test public void restoringServiceGeometryDoesNotPersistUnknownProviderEndpoints() throws Exception {
        activeService();
        launch();
        activity.onSpeed(8);
        JSONObject saved = savedDraft();
        assertFalse("Service-derived start stays in memory", saved.has("start"));
        assertFalse("Service-derived destination stays in memory", saved.has("end"));
        assertFalse(saved.has("geometry"));
        assertEquals(8, saved.getDouble("speed"), 0);
    }

    @Test public void serviceUpdatesPreserveOriginalManualEndpointsInsteadOfSnappedPoints() throws Exception {
        saveDraft(MANUAL_ROUTE);
        activeService();
        launch();
        activity.onSpeed(12);
        JSONObject saved = savedDraft();
        assertEquals(28.6001, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2001, saved.getJSONArray("start").getDouble(1), 0);
        assertEquals(28.6201, saved.getJSONArray("end").getDouble(0), 0);
        assertEquals(77.2301, saved.getJSONArray("end").getDouble(1), 0);
    }

    @Test public void offlineRoadRouteDoesNotBecomeADirectLine() throws Exception {
        saveDraft(MANUAL_ROUTE.replace("\"direct\"", "\"road\""));
        launch();
        MainActivity.Draft draft = ReflectionHelpers.getField(activity, "draft");
        assertNull("A missing provider response cannot become a direct shortcut", draft.geometry);
        assertTrue(button("Enable routes").isEnabled());
        assertEquals("road", savedDraft().getString("kind"));
        assertNull(nextServiceIntent());
    }

    @Test public void selectedProviderCoordinatesAndLabelsStayOutOfSavedDraft() throws Exception {
        saveDraft(MANUAL_ROUTE);
        launch();
        ReflectionHelpers.callInstanceMethod(activity, "setPoint",
                ReflectionHelpers.ClassParameter.from(boolean.class, false),
                ReflectionHelpers.ClassParameter.from(double[].class, new double[]{51.5, -0.12}),
                ReflectionHelpers.ClassParameter.from(String.class, "Selected provider address"),
                ReflectionHelpers.ClassParameter.from(boolean.class, true));
        activity.onSpeed(7);
        JSONObject saved = savedDraft();
        assertFalse(saved.has("start"));
        assertTrue("The other manually selected endpoint is retained", saved.has("end"));
        assertFalse(saved.has("geometry"));
        assertFalse(saved.toString().contains("Selected provider address"));
        assertNull(nextServiceIntent());
    }

    @Test public void recreationRetainsTheSameRouteAndGatewayWithoutRefetching() {
        saveDraft(MANUAL_ROUTE);
        launch();
        MainActivity previous = activity;
        MainActivity.PlanningSession session = ReflectionHelpers.getField(activity, "session");
        MainActivity.Draft draft = session.draft;
        draft.kind = "road";
        draft.startFromProvider = true;
        draft.startLabel = "Provider selection retained in memory";
        double[][] geometry = draft.geometry;
        long generation = session.generation;
        controller.recreate(); activity = controller.get(); idle();
        assertSame(session, ReflectionHelpers.getField(activity, "session"));
        assertSame(session.network, ReflectionHelpers.getField(activity, "network"));
        assertSame(geometry, session.draft.geometry);
        assertEquals(generation, session.generation);
        assertEquals("Provider selection retained in memory", session.draft.startLabel);
        assertTrue(session.draft.startFromProvider);
        assertSame(activity, session.owner);
        assertTrue(previous.isDestroyed());
        assertFalse(session.closed);
        assertTrue(button("Start journey").isEnabled());
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertNull(nextServiceIntent());
    }

    @Test public void recreationPreservesPendingRouteSessionAndUpdatesItsNewOwner() {
        saveDraft(MANUAL_ROUTE);
        launch();
        MainActivity.PlanningSession session = ReflectionHelpers.getField(activity, "session");
        session.draft.kind = "road";
        session.draft.geometry = null;
        session.loading = true;
        session.message = "Finding a route along roads and paths…";
        session.generation = 42;
        session.notifyOwner(false);
        controller.recreate(); activity = controller.get(); idle();
        assertSame(session, ReflectionHelpers.getField(activity, "session"));
        assertSame(activity, session.owner);
        assertEquals("Rotation must not restart an in-flight route request", 42, session.generation);
        assertTrue(session.loading);
        assertFalse(session.closed);
        // Deliver a provider-shaped result to the retained state, without a native map or HTTP call.
        session.draft.geometry = new double[][]{{28.6001, 77.2001}, {28.6100, 77.2200}, {28.6201, 77.2301}};
        session.draft.distance = 3400;
        session.loading = false; session.message = "";
        session.notifyOwner(false);
        assertTrue(button("Start journey").isEnabled());
        assertFalse(ReflectionHelpers.<Boolean>getField(activity, "routeLoading"));
        assertNull(nextServiceIntent());
    }

    @Test public void recreationRestoresPickerTextAndReleasesTheOldWindow() {
        launch();
        activity.onPoint(true);
        AlertDialog previous = ShadowAlertDialog.getLatestAlertDialog();
        EditText input = find(previous.getWindow().getDecorView(), EditText.class);
        assertNotNull(input);
        input.setText("東京駅, Japan");
        controller.recreate(); activity = controller.get(); idle();
        AlertDialog restored = ShadowAlertDialog.getLatestAlertDialog();
        assertFalse(previous.isShowing());
        assertTrue(restored.isShowing());
        EditText restoredInput = find(restored.getWindow().getDecorView(), EditText.class);
        assertNotNull(restoredInput);
        assertEquals("東京駅, Japan", restoredInput.getText().toString());
        Object picker = ReflectionHelpers.getField(activity, "currentPicker");
        assertTrue(ReflectionHelpers.<Boolean>getField(picker, "destination"));
        assertNull(nextServiceIntent());
    }

    @Test public void finishingAnActivityClosesItsPlanningSessionAndDetachesItsOwner() {
        launch();
        MainActivity.PlanningSession session = ReflectionHelpers.getField(activity, "session");
        controller.pause().stop().destroy(); controller = null;
        assertTrue(session.closed);
        assertNull(session.owner);
    }

    @Test public void routingKeyEntryIsNotRetainedAndItsWindowIsReleasedOnRotation() {
        launch();
        ReflectionHelpers.callInstanceMethod(activity, "showRoutingSetup");
        AlertDialog previous = ReflectionHelpers.getField(activity, "routingDialog");
        assertNotNull(previous);
        EditText input = find(previous.getWindow().getDecorView(), EditText.class);
        assertNotNull(input);
        assertFalse("A routing secret must not enter Android saved view state", input.isSaveEnabled());
        input.setText("test_fixture_key_not_real_123456");
        controller.recreate(); activity = controller.get(); idle();
        assertFalse(previous.isShowing());
        assertEquals("", input.getText().toString());
        assertNull(ReflectionHelpers.getField(activity, "routingDialog"));
        assertFalse(application().getSharedPreferences("routingAccess", 0).contains("sealed"));
        assertNull(nextServiceIntent());
    }

    private void readyRoute() {
        saveDraft(MANUAL_ROUTE);
        launch();
        AppOpsManager appOps = (AppOpsManager) activity.getSystemService(Context.APP_OPS_SERVICE);
        shadowOf(appOps).setMode("android:mock_location", Process.myUid(), activity.getPackageName(), AppOpsManager.MODE_ALLOWED);
        assertTrue(button("Start journey").isEnabled());
    }

    private void launch() {
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        activity = controller.get();
        idle();
    }

    private void enterCoordinates(boolean destination, String text) {
        activity.onPoint(destination);
        AlertDialog dialog = ShadowAlertDialog.getLatestAlertDialog();
        EditText input = find(dialog.getWindow().getDecorView(), EditText.class);
        assertNotNull(input);
        input.setText(text);
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled());
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        idle();
        assertFalse(dialog.isShowing());
    }

    private AlertDialog rationale() {
        AlertDialog dialog = ReflectionHelpers.getField(activity, "permissionDialog");
        assertNotNull("Starting a fresh session must display its explanation", dialog);
        return dialog;
    }

    private void tapMap(double latitude, double longitude) {
        // Invoke the map callback directly; no native renderer or routing access is involved.
        ReflectionHelpers.callInstanceMethod(activity, "mapTapped",
                ReflectionHelpers.ClassParameter.from(double.class, latitude),
                ReflectionHelpers.ClassParameter.from(double.class, longitude));
        idle();
    }

    private void assertSingleStart() {
        Intent intent = nextServiceIntent();
        assertNotNull("Expected one start service Intent", intent);
        assertEquals("start", intent.getAction());
        assertEquals(SimulationService.class.getName(), intent.getComponent().getClassName());
        assertNotNull(SimulationService.stagedPlan);
        assertNull(nextServiceIntent());
    }

    private static void activeService() {
        SimulationService.active = true;
        SimulationService.routePoints = new double[][]{{28.6009, 77.2009}, {28.6209, 77.2309}};
        SimulationService.state = "{\"status\":\"running\",\"speedKmh\":5,\"mode\":\"once\","
                + "\"totalMeters\":3200,\"distanceMeters\":0,\"lat\":28.6009,\"lon\":77.2009}";
    }
    private static Application application() { return RuntimeEnvironment.getApplication(); }
    private static void idle() { shadowOf(Looper.getMainLooper()).idle(); }
    private static Intent nextServiceIntent() { return shadowOf(application()).getNextStartedService(); }
    private static void drainServiceIntents() { while (nextServiceIntent() != null) { } }
    private static void saveDraft(String value) {
        application().getSharedPreferences("nativeDraft", 0).edit().putString("value", value).commit();
    }
    private static JSONObject savedDraft() throws Exception {
        return new JSONObject(application().getSharedPreferences("nativeDraft", 0).getString("value", "{}"));
    }
    private Button button(String label) {
        Button result = findButton(activity.findViewById(android.R.id.content), label);
        assertNotNull("Missing button: " + label, result);
        return result;
    }
    private static Button findButton(View view, String label) {
        if (view instanceof Button && label.contentEquals(((Button) view).getText())) return (Button) view;
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            Button found = findButton(((ViewGroup) view).getChildAt(i), label);
            if (found != null) return found;
        }
        return null;
    }
    private static <T extends View> T find(View view, Class<T> type) {
        if (type.isInstance(view)) return type.cast(view);
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            T found = find(((ViewGroup) view).getChildAt(i), type);
            if (found != null) return found;
        }
        return null;
    }
}
