/* SPDX-License-Identifier: GPL-3.0-or-later */
package cl.coders.movingtraveler;

import android.app.Activity;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.util.ReflectionHelpers;
import org.robolectric.annotation.Config;

import static org.junit.Assert.*;

/** Camera math and Android gesture ownership; no native GPU or live tile testing. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class MapSurfaceTest {
    @Test public void previewContainsBendsOutsideEndpointRectangle() {
        double[] bounds = MapSurface.fitExtent(new double[]{10, 20}, new double[]{11, 21},
                new double[][]{{10,20}, {13,18}, {8,24}, {11,21}});
        assertArrayEquals(new double[]{13,24,8,18}, bounds, 1e-9);
    }

    @Test public void dateLineRouteFitsNearbyWorldCopy() {
        double[] bounds = MapSurface.fitExtent(new double[]{-16,179.5}, new double[]{-17,-179.7},
                new double[][]{{-16,179.5},{-16.4,179.9},{-16.7,-179.9},{-17,-179.7}});
        assertArrayEquals(new double[]{-16,180.3,-17,179.5}, bounds, 1e-8);
        assertTrue(bounds[1] - bounds[3] < 1);
    }

    @Test public void singlePointHasZeroSpan() {
        assertArrayEquals(new double[]{52.5,13.4,52.5,13.4},
                MapSurface.fitExtent(new double[]{52.5,13.4}, null, null), 1e-9);
    }

    @Test public void cameraIncludesManuallySelectedPointsOutsideSnappedGeometry() {
        assertArrayEquals(new double[]{13,24,8,18}, MapSurface.fitExtent(
                new double[]{13,18}, new double[]{8,24}, new double[][]{{12,20},{10,22}}), 1e-9);
    }

    @Test public void draggedWorldCopiesReturnConventionalCoordinates() {
        assertEquals(-179, MapSurface.wrap(181), 0);
        assertEquals(179, MapSurface.wrap(-181), 0);
        assertEquals(1, MapSurface.wrap(721), 0);
        assertEquals(-180, MapSurface.wrap(180), 0);
    }

    @Test public void releaseImmediatelyAfterLongPressClearsDragWithoutMovingPin() throws Exception {
        DragFixture fixture = new DragFixture();
        fixture.dispatch(MotionEvent.ACTION_DOWN);
        fixture.begin(); // Native long-press detection is outside this renderer-free test.
        fixture.dispatch(MotionEvent.ACTION_UP);
        assertEquals(-1, (int) ReflectionHelpers.getField(fixture.surface, "dragging"));
        assertEquals(1, fixture.childCancels);
        assertEquals(0, fixture.commits);
        fixture.dispatch(MotionEvent.ACTION_DOWN);
        fixture.dispatch(MotionEvent.ACTION_UP);
        assertEquals("The next gesture must remain a normal map gesture", 2, fixture.childDowns);
    }

    @Test public void cancelImmediatelyAfterLongPressClearsDrag() throws Exception {
        DragFixture fixture = new DragFixture();
        fixture.dispatch(MotionEvent.ACTION_DOWN); fixture.begin();
        fixture.dispatch(MotionEvent.ACTION_CANCEL);
        assertEquals(-1, (int) ReflectionHelpers.getField(fixture.surface, "dragging"));
        assertEquals(0, fixture.commits);
    }

    @Test public void noOpOrRoundingOnlyDragDoesNotRequestAnotherRoute() throws Exception {
        DragFixture fixture = new DragFixture(); fixture.begin();
        ReflectionHelpers.setField(fixture.surface, "start", new double[]{51.50000000001, -0.1});
        ReflectionHelpers.callInstanceMethod(fixture.surface, "finishDrag",
                ReflectionHelpers.ClassParameter.from(boolean.class, true));
        assertEquals(0, fixture.commits);
        assertArrayEquals(new double[]{51.5, -0.1},
                ReflectionHelpers.getField(fixture.surface, "start"), 0);
    }

    @Test public void completedDragCommitsExactlyOnce() throws Exception {
        DragFixture fixture = new DragFixture(); fixture.begin();
        ReflectionHelpers.setField(fixture.surface, "start", new double[]{51.501, -0.102});
        ReflectionHelpers.callInstanceMethod(fixture.surface, "finishDrag",
                ReflectionHelpers.ClassParameter.from(boolean.class, true));
        ReflectionHelpers.callInstanceMethod(fixture.surface, "finishDrag",
                ReflectionHelpers.ClassParameter.from(boolean.class, true));
        assertEquals(1, fixture.commits);
        assertArrayEquals(new double[]{51.501, -0.102}, fixture.position, 0);
    }

    @Test public void newGestureCancelsAnOrphanedDrag() throws Exception {
        DragFixture fixture = new DragFixture(); fixture.begin();
        fixture.dispatch(MotionEvent.ACTION_DOWN);
        assertEquals(-1, (int) ReflectionHelpers.getField(fixture.surface, "dragging"));
        assertEquals(1, fixture.childDowns);
        assertEquals(0, fixture.commits);
    }

    private static final class DragFixture {
        final MapSurface surface;
        final FrameLayout host;
        int commits, childCancels, childDowns;
        double[] position;
        final long down = SystemClock.uptimeMillis();
        DragFixture() throws Exception {
            Activity activity = Robolectric.buildActivity(Activity.class).setup().get();
            surface = new MapSurface(activity, new FrameLayout(activity), new MapSurface.Listener() {
                @Override public void onTap(double lat, double lon) { }
                @Override public void onDrag(boolean destination, double lat, double lon) {
                    commits++; position = new double[]{lat, lon};
                }
                @Override public void onReady() { }
                @Override public void onMapError(String message) { }
            });
            Class<?> hostClass = Class.forName("cl.coders.movingtraveler.MapSurface$DragHost");
            java.lang.reflect.Constructor<?> constructor = hostClass.getDeclaredConstructor(MapSurface.class);
            constructor.setAccessible(true); host = (FrameLayout) constructor.newInstance(surface);
            View child = new View(activity);
            child.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN) childDowns++;
                if (event.getActionMasked() == MotionEvent.ACTION_CANCEL) childCancels++;
                return true;
            });
            host.addView(child, new FrameLayout.LayoutParams(-1, -1));
            activity.setContentView(host);
            int exact = View.MeasureSpec.makeMeasureSpec(400, View.MeasureSpec.EXACTLY);
            host.measure(exact, exact); host.layout(0, 0, 400, 400);
        }
        void begin() {
            ReflectionHelpers.setField(surface, "start", new double[]{51.5,-0.1});
            ReflectionHelpers.setField(surface, "dragOriginal", new double[]{51.5,-0.1});
            ReflectionHelpers.setField(surface, "dragging", 0);
            host.requestDisallowInterceptTouchEvent(false);
        }
        void dispatch(int action) {
            MotionEvent event = MotionEvent.obtain(down, down + 800, action, 100, 100, 0);
            host.dispatchTouchEvent(event); event.recycle();
        }
    }
}
