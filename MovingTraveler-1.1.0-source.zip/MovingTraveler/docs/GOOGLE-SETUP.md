# Enable Google Maps in Moving Traveler

The 1.1.0 source implements native Google Maps, route calculation and place search. The supplied APK has **no account configuration**: coordinates, direct paths and mock playback can be tested, but Google maps/search/routes cannot work until you complete this setup and rebuild. No Cloud project, paid service or deployment has been created for you.

## 1. Choose the app identity

The current debug package is `cl.coders.movingtraveler.debug`; release is `cl.coders.movingtraveler`. Choose a package controlled by you before first Play publication. You can change the visible name later in `app/src/main/res/values/strings.xml`; changing the package after publication creates a different app. Keep your upload/signing keys private.

For testing, run `./gradlew signingReport` to find the **debug SHA-1**. For a Play release, use **Play Console → Setup → App integrity → App signing key certificate**, not just the upload certificate: Android Maps restrictions use SHA-1 and Firebase Play Integrity registration uses SHA-256.

## 2. Create the Google project

1. Open [Google Cloud Console](https://console.cloud.google.com/) and create a project under your account.
2. Attach your billing account. Billing must be enabled even when requests remain inside free allowances.
3. Enable **Maps SDK for Android**, **Routes API**, and **Places API (New)** in APIs & Services → Library.
4. Set quotas and billing alerts. Budget alerts are notifications, not spending caps. Limits apply across your users. Route calls, autocomplete requests, and selected-place details are separate billable services. The implementation uses basic routes without traffic and Essentials place fields.

[Google project setup](https://developers.google.com/maps/documentation/android-sdk/cloud-setup) · [Global prices](https://developers.google.com/maps/billing-and-pricing/pricing) · [India prices](https://developers.google.com/maps/billing-and-pricing/pricing-india)

India pricing requires billing in India and a large majority of usage in India; do not assume eligibility from your address alone. [Eligibility](https://developers.google.com/maps/billing-and-pricing/india)

## 3. Create two different Maps keys

**Android map key**

- Create an API key with **Android applications** restrictions.
- Add the package and matching signing SHA-1 certificate for the build you install.
- Restrict the API to **Maps SDK for Android** only.
- Use a separate debug key/project where practical. Never use an unrestricted key.

The Android map key is packaged in the APK and can be extracted. Its package/certificate and API restrictions protect it; `secrets.properties` prevents accidental source publication but does not make an APK key secret.

**Server route/search key**

- Create a separate key restricted to **Routes API** and **Places API (New)**.
- Store it in Cloud Secret Manager as the proxy's `GOOGLE_MAPS_SERVER_KEY`.
- Add a server IP restriction after configuring static outbound IP for Cloud Run. An Android application restriction is not suitable for the server key.
- Never copy this key into `secrets.properties`, source code, the APK, a public URL or a chat message.

[API key security](https://developers.google.com/maps/api-security-best-practices)

## 4. Set up Firebase App Check

Add Firebase to the same Google Cloud project at [Firebase Console](https://console.firebase.google.com/). Analytics is not needed.

1. Register your Android package. Debug and release have different package IDs and should be separate Firebase Android app registrations.
2. Record `mobilesdk_app_id`, `project_id` and the Firebase Android `current_key` from that app's downloaded `google-services.json`. These become `FIREBASE_APPLICATION_ID`, `FIREBASE_PROJECT_ID` and `FIREBASE_API_KEY`. The project initializes Firebase explicitly; do not add the Google Services Gradle plugin or ship the JSON file.
3. For release, register App Check with **Play Integrity** and the **Play app-signing SHA-256**. Follow Firebase's instructions to link the Cloud project and configure attestation for your distribution. Do not require a stronger verdict than your supported devices can provide.
4. For a debug build, this project includes the debug provider only in the debug source set. After installation and an attempted search/route, find the App Check debug token in Android Studio Logcat and register it under Firebase → App Check → your debug app → Manage debug tokens. Treat that token as a secret; never register arbitrary third-party tokens.
5. The backend allows one `FIREBASE_APP_ID`. Use separate test and production deployments (and limits) for the two app registrations. Changing it to your debug App ID excludes release apps until changed back.

[Play Integrity setup](https://firebase.google.com/docs/app-check/android/play-integrity-provider) · [Debug setup](https://firebase.google.com/docs/app-check/android/debug-provider)

## 5. Deploy the included proxy

Follow [backend/README.md](../backend/README.md) for the Node 24 service, environment values, Cloud Run/Secret Manager setup and request limits. It uses Firebase Admin to verify App Check, accepts only `/route`, `/search` and `/place`, and never accepts an arbitrary Google URL from the phone.

Use a dedicated service identity, HTTPS, no development bypass, and initially at most one Cloud Run instance. The backend's in-memory limits reset on restart and apply per instance; they are not a monthly billing ceiling. Configure provider quotas and use a shared limiter before scaling. Cloud Run hosting and any static egress infrastructure have separate costs.

The included Dockerfile installs only required production packages. Optional Firebase Admin Storage/Firestore packages are omitted because this proxy does not use those products. `package-lock.json` pins dependency resolution.

Record the deployed HTTPS service origin, such as `https://YOUR-SERVICE.REGION.run.app`, as `GOOGLE_PROXY_BASE_URL`. Do not include `/route` on the base URL. `/healthz` checks that the process is running without calling Google; it does not validate billing or real app attestation.

## 6. Configure and rebuild the Android app

Copy `secrets.properties.example` to **`secrets.properties`** in the project root and fill it locally:

```properties
MAPS_API_KEY=YOUR_RESTRICTED_ANDROID_MAP_KEY
GOOGLE_PROXY_BASE_URL=https://YOUR-DEPLOYED-SERVICE
FIREBASE_APPLICATION_ID=YOUR_FIREBASE_ANDROID_APP_ID
FIREBASE_PROJECT_ID=YOUR_FIREBASE_PROJECT_ID
FIREBASE_API_KEY=YOUR_FIREBASE_ANDROID_API_KEY
PUBLIC_PRIVACY_URL=https://YOUR-DOMAIN/privacy
PUBLIC_TERMS_URL=https://YOUR-DOMAIN/terms
PUBLIC_SOURCE_URL=https://YOUR-PUBLIC-CORRESPONDING-SOURCE
```

Firebase's Android API key is public app configuration, not the secret Maps server key. Follow [Firebase API key guidance](https://firebase.google.com/docs/projects/api-keys), including compatible API restrictions. Keep backend service credentials and App Check debug tokens out of this file.

Install Android SDK Platform 36, Build Tools 36.0.0 and JDK 17/21, then run:

```sh
./gradlew testDebugUnitTest lintDebug lintRelease assembleDebug bundleRelease
```

Install `app/build/outputs/apk/debug/app-debug.apk`. Enable online maps in Settings. A missing configuration shows a setup message; the app never substitutes a straight line for a failed Google road route. **Direct line** remains an explicit Route option.

If the map is blank, check billing, enabled Maps SDK, package name and the installed certificate's SHA-1. If routes/search fail, check the proxy URL, service health, App Check token registration, allowed Firebase App ID, server key restrictions and quotas. Check Cloud logs without enabling request-body/header logging. Try walking/cycling in a region where Google supports that mode; unavailable routes should show a retryable error.

## 7. Verify before publishing

Use a real Google Play services phone and the final signed build. Test a start/destination selected by map and by search; visible route; all supported travel modes; pace changes; fast repeated point edits; airplane mode and retries; cancellation; rotation; start/pause/resume/stop; background notification; denied optional permissions; system haptics disabled; and Google attribution. Check live requests against billing/quotas with a small controlled test. Test malformed/missing App Check tokens against the deployed service.

The simulation is local after a route is fetched. It does not request a new Google route on every location tick. Search is debounced, each endpoint uses its own session token, and Details requests are limited to Essentials fields plus required attribution. Native map display is configured without a map ID/cloud styling.

Google routes, search labels and Places coordinates remain in process memory for the planning/playback session; the app does not persist them as saved routes. User-entered coordinates/map points and non-content preferences can be saved locally. Google's SDK may manage its own cache. Keep the required Google attribution visible and review the terms applicable to your billing region.

Finish [PLAY-RELEASE.md](PLAY-RELEASE.md), publish your privacy policy and terms, sign your bundle with your own upload key and test through Play's internal track. The supplied unconfigured unsigned AAB is **not a ready-to-submit Play release**. Google rendering, Play Integrity, physical mock-location delivery, WhatsApp compatibility and Play approval cannot be established by the automated fixture tests.
