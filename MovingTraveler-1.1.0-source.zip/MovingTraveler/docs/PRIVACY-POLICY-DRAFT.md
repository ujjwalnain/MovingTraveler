# Moving Traveler privacy policy — publisher draft

**Not ready to publish.** Replace all bracketed fields, verify the final version 1.1.0 binary and deployed services, and remove this notice before publication. This draft is not a submitted Google Play Data Safety declaration. Configuration steps are in `docs/GOOGLE-SETUP.md` and `backend/README.md`.

Effective date: **[EFFECTIVE DATE]**  
Publisher: **[PUBLISHER LEGAL/DISPLAY NAME]**  
Privacy contact: **[PRIVACY CONTACT EMAIL OR CONTACT FORM]**  
Public privacy policy: **[PUBLIC HTTPS PRIVACY POLICY URL]**  
Application terms: **[PUBLIC HTTPS APPLICATION TERMS URL]**  
Corresponding source: **[PUBLIC HTTPS SOURCE URL FOR VERSION 1.1.0]**

Moving Traveler holds a simulated location or plays a route at your chosen pace using Android's developer mock-location feature. The application does not retrieve your actual device location or enable the Google map's My Location feature. Optional approximate-location permission enables its Google Play Services mock-publication path; declining it leaves Android framework simulation available. The app does not access WhatsApp messages, contacts or accounts, send messages, or start location sharing in another app.

## Information on your device

The app saves manually entered or manually selected start/destination coordinates, pace, travel mode, route/playback options and online-planning preference in local app storage. It also remembers permission-prompt choices and the Google consent version. These preferences remain until replaced, cleared or the app is uninstalled.

Places search results, Places-derived coordinates and labels, provider credits, and Google route geometry are held in the app's memory for the current session. The app does not write those results to its saved draft or a route-history database. Activity rotation may retain them in process. Ending playback does not necessarily clear the current in-memory plan. Google Maps and Firebase SDKs can maintain their own caches, identifiers or token state; these are separate from the app's draft storage and follow the applicable SDK behavior and provider policies. There is no app account, advertising feature or analytics dashboard, and no advertising or analytics SDK added for those purposes. Firebase is used for App Check, not Firestore or user-account authentication.

Android backup is disabled in the manifest. Use Android **Settings → Apps → Moving Traveler → Storage → Clear storage** to erase app-local drafts, preferences and app-local SDK storage, or uninstall the app. This does not delete provider records or storage controlled by Google Play Services outside the app. Stop ends a simulation but does not erase saved preferences.

## Optional online planning

The app asks whether to enable Google online planning before initializing its Google map and Firebase App Check or making its place/route requests. Version 1.1 asks for this Google choice again if an older online-map preference exists. Coordinate-only planning supports direct routes and fixed positions without these planning requests.

When online planning is enabled, the native Google map displays the selected area. Searches and selected points pass through **[PUBLISHER PROXY OPERATOR, HTTPS ENDPOINT, HOSTING REGION AND PRIVACY URL]** to Google. The map does not send its display requests through that proxy.

| Feature | Information and recipients | Purpose |
| --- | --- | --- |
| Google map display | Google receives requested map areas, map interactions and SDK/network metadata. | Display and operate the map. |
| Place autocomplete and selection | The publisher's proxy and Google Places receive entered search text, a temporary search-session token, and the selected place ID. Google returns coordinates, an address and any provider credits. | Find and select a point. |
| Route planning | The publisher's proxy and Google Routes receive the chosen start/destination coordinates and walking, cycling or driving mode. | Calculate route geometry. Playback uses the user's chosen pace rather than Google's travel-time estimate. |
| App verification | Firebase App Check and Google Play Integrity process app/device attestation material and associated service metadata. The publisher's proxy receives an App Check token in the request header and verifies it before forwarding a planning request. | Restrict access to the app's planning service and reduce abuse. |
| Service operation | The publisher's host, Google and relevant infrastructure can process IP addresses, request timing/status, application identifiers and other operational metadata. | Deliver, secure and operate the services. |

Search text and chosen coordinates may reveal places of interest, even when a journey is fictional. Playback position, pace changes and pause/resume do not generate new route calculations; the loaded simulation runs locally. App planning requests use HTTPS.

Google documents automatic Maps SDK collection including request/device metadata, diagnostics, IP addresses and a unique identifier, with map-interaction handling depending on configuration. See the [Maps SDK data disclosure](https://developers.google.com/maps/documentation/android-sdk/play-data-disclosure) and [Google privacy policy](https://policies.google.com/privacy). Firebase describes App Check attestation material, tokens and service data in its [privacy information](https://firebase.google.com/support/privacy). The [Play Integrity provider](https://firebase.google.com/docs/app-check/android/play-integrity-provider) has its own attestation behavior. These provider disclosures must be reviewed against the versions and settings actually deployed; disabling default Firebase collection does not disable processing required for App Check.

## Proxy processing and retention

The supplied proxy does not maintain a place/route database or cache route geometry. Its application code does not log request bodies, search text, coordinates, raw tokens or headers. It processes planning data in memory to forward the request and returns responses with `Cache-Control: no-store`.

For rate limiting, the proxy holds a hash of an App Check token, request counts and reset timestamps in bounded process memory. These records can remain until a key is reused, capacity cleanup runs or the process stops; there is no promise of deletion exactly when a counting window expires. The counters reset on process restart and are not a user account. Infrastructure may separately keep access, security, billing and operational logs. App Check verification is not a promise of anonymity, and the supplied implementation does not use token-consumption replay protection.

**Publisher must complete:** **[HOST/LOAD-BALANCER LOG FIELDS, RETENTION PERIODS, ACCESS CONTROLS, PURPOSES, DELETION PROCESS, CONTACT AND ANY ADDITIONAL LOGGING]**. Also state **[APPLICABLE PROCESSING LOCATIONS, INTERNATIONAL TRANSFER INFORMATION AND LEGAL BASIS WHERE REQUIRED]**. Provider retention follows the applicable service agreements and policies; this draft does not promise immediate deletion or system-wide absence of logging.

Turning online planning off in Settings cancels pending app planning work, prevents new map/search/route requests and disables App Check token auto-refresh. It cannot recall a request already received by a provider or remove existing logs, and an SDK operation already in progress may finish. The control does not govern Android or Google Play Services' independent system activity.

## Simulation, permissions and controls

The app publishes simulated coordinates, speed, bearing, accuracy and timestamps to Android test providers. With Google Play Services available and optional approximate-location permission granted, it also uses the Fused Location Provider's mock APIs. It does not use that permission to request your actual location. Values remain marked as mock; receiving apps decide whether to use them and may cache their last received fix.

- Developer options' **Select mock location app** authorizes simulation.
- Optional approximate-location permission enables the Google compatibility path. The app requests neither fine nor background-location permission. Permission can be revoked in Android Settings.
- Internet/network permissions support optional online planning and app verification.
- Optional notification permission on Android 13 and later makes playback controls visible in the notification drawer. In-app Stop remains available if permission is denied.
- A foreground service and partial wake lock keep a user-started session updating while another app is open or the screen is off. The lock does not keep the display on and is released during normal cleanup.

Pausing or arriving at a destination keeps publishing the stationary simulated position until Stop. Stop requests removal of this app's test providers, disables its Play Services mock mode when active, and ends the service. A killed process or reboot does not automatically resume a journey. Recovery and delivery can vary by device and receiving app.

You can stop playback, change the selected mock app in Developer options, turn off online planning, clear storage or uninstall. If you manually share a location through another app, its recipients and retention are governed by that app. Make clear to recipients that the location is simulated.

## Terms, contact and changes

Use of Google Maps content is subject to the applicable [Google Maps terms](https://maps.google.com/help/terms_maps/) and [Google privacy policy](https://policies.google.com/privacy), in addition to **[PUBLIC APPLICATION TERMS URL]**. The publisher's public terms must include the applicable Google terms references. Source for this application version is available at **[PUBLIC CORRESPONDING SOURCE URL]**.

For privacy questions or requests, contact **[PRIVACY CONTACT EMAIL OR CONTACT FORM]**. **[PUBLISHER: EXPLAIN REQUEST VERIFICATION, RESPONSE PROCESS, APPLICABLE RIGHTS AND ANY RETENTION OBLIGATIONS.]** Requests concerning a provider's independent records may need to be directed to that provider.

We will update this policy and effective date when our data practices change. Additional collection or new services require revised disclosures and consent where applicable.
