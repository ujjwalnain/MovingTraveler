# Moving Traveler — store listing draft

Draft for version **1.1.0 / code 2**. Supply publisher/contact details, working Google configuration, public policy/terms/source URLs and actual release screenshots. Publish only after the corresponding device and service tests pass. See `docs/GOOGLE-SETUP.md` and `docs/PLAY-RELEASE.md`.

## App name

Moving Traveler

## Short description

Simulate Android locations along a route at your chosen pace.

## Full description

Plan a simulated journey and control how it moves. Moving Traveler uses Android's developer mock-location feature for location testing and demonstrations.

Choose a starting point and destination on a native Google map, search for a place, or enter latitude and longitude. Pick a travel mode and pace, start the journey, and follow its progress.

- Google road routes support walking, cycling and driving where available. Direct routes travel straight between your selected points.
- Walk, Cycle and Drive select a routing mode and a starting pace of 5, 15 or 50 km/h. Set a custom pace from 0.5 to 200 km/h and change it during playback.
- Pause holds the current simulated position; Resume continues from there.
- Back and forth reverses along the selected route at each endpoint until stopped.
- Stay at start holds one static simulated location.
- A one-way journey holds the destination after arrival until you tap Stop.
- A foreground service supports playback while you switch apps, with notification controls when allowed.
- Coordinate-only planning supports direct routes and fixed positions without online planning requests.

Your selected pace controls movement independently of Google's travel-time estimate. Road routing does not reproduce live traffic, physical footsteps or every detail of real travel. Walking/cycling coverage may be incomplete. Direct lines can cross buildings or water. Moving Traveler is a location-testing tool, not a navigation or road-safety guide.

Setup requires Android 6.0 or later and selecting Moving Traveler under Developer options → Select mock location app. Google map display requires compatible Google Play Services. Optional approximate-location permission enables the Google Play Services mock-publication path; declining it keeps Android framework simulation available. The app does not retrieve your actual location. Simulated fixes remain marked as mock, and other apps can accept, ignore or reject them. Compatibility with a particular third-party app is not guaranteed.

Google online planning is optional. When enabled, Google receives map requests; searches and route points pass through the publisher's planning service to Google Places and Google Routes. Firebase App Check and Play Integrity verify access to that service. Providers receive service, device and network metadata and may retain records under their policies. Review the privacy policy for details.

Manual coordinate drafts and preferences stay in local app storage. The app keeps Google place results and route geometry in memory for the current session; SDK-managed caches are separate. There are no app accounts, ads or analytics features added by Moving Traveler.

The independently developed application is open source under GPL-3.0-or-later with an additional Google linking permission. It takes inspiration from FakeTraveler's mock-location mechanism and preserves its attribution. Use it for your own tests and demonstrations, and tell anyone viewing a shared location that it is simulated.

## Release metadata to finalize

| Field | Draft value / action |
| --- | --- |
| Category | Tools; confirm the final app's actual core purpose. |
| Developer | [PUBLISHER DISPLAY NAME] |
| Support | [SUPPORT EMAIL / WEBSITE] |
| Privacy policy | [PUBLIC HTTPS PUBLISHER PRIVACY POLICY URL] → `PUBLIC_PRIVACY_URL` |
| Application terms | [PUBLIC HTTPS APPLICATION TERMS URL] → `PUBLIC_TERMS_URL` |
| Corresponding source | [PUBLIC HTTPS SOURCE URL FOR THIS RELEASE] → `PUBLIC_SOURCE_URL` |
| Ads | No, for this implementation; reassess if monetization changes. |
| Content rating | Answer the Play questionnaire for the final binary; do not predeclare a rating. |

Finalize the public pages and publisher service configuration using `docs/GOOGLE-SETUP.md`. Do not publish this listing while online functionality still depends on missing keys, Firebase registration or an undeployed proxy. Provider metadata and app verification must be reflected in Data Safety; the absence of app accounts/ads does not mean no data is processed.

## Screenshot capture plan

Capture actual signed-release screens: map with selected start/destination and a loaded route; chosen mode/pace; active progress; pause; Back and forth; Stay at start. Include portrait and landscape in the test record and choose legible storefront images. Keep the Google map attribution and any Places provider credits visible. Show a clearly identified demonstration route. Do not fabricate WhatsApp screenshots or use its branding to imply affiliation.

Avoid “undetectable,” “works everywhere,” “zero lag,” “guaranteed WhatsApp support,” or Play approval badges. Describe tested behavior and limitations accurately. [Google Play listing guidance](https://support.google.com/googleplay/android-developer/answer/13393723?hl=en)
