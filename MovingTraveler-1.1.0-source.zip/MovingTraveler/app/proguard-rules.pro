# Google and Firebase SDKs supply their own consumer rules.
