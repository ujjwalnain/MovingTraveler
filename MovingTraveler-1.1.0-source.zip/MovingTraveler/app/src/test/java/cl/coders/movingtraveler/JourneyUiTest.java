// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.app.Activity;
import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.annotation.LooperMode;

/** Native widget/layout checks; these do not emulate Google Maps or Android mock delivery. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = Application.class, qualifiers = "w360dp-h740dp-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public final class JourneyUiTest {
    private ActivityController<Activity> controller;
    private Activity activity;
    private JourneyUi ui;
    private RecordingListener listener;

    @Before public void setup() {
        controller = Robolectric.buildActivity(Activity.class).setup();
        activity = controller.get();
        activity.setTheme(android.R.style.Theme_Material_Light_NoActionBar);
        listener = new RecordingListener();
        ui = new JourneyUi(activity, listener);
        activity.setContentView(ui.root());
    }

    @After public void cleanup() { controller.pause().stop().destroy(); RuntimeEnvironment.setFontScale(1); }

    @Test public void initialAndCleanFocusedSpeedArePopulated() {
        EditText editor = find(EditText.class);
        assertEquals("5", editor.getText().toString());
        assertTrue(editor.requestFocus());
        ui.render("idle", "", "Start", "End", 15, 1600, 200,
                false, false, true, "cycle", "once", "road", false);
        assertEquals("15", editor.getText().toString());
        assertTrue(listener.events.isEmpty());
        layout(360, 740);
        assertTrue("Numeric text uses the actual field width", editor.getLayout().getWidth() <= editor.getWidth());
    }

    @Test public void compactInsetsKeepTheCoreSpeedSliderAboveTheActionBar() {
        ready();
        ui.root().setPadding(8, 24, 8, 28);
        layout(360, 740);
        Rect sliderBounds = bounds(find(SeekBar.class));
        Rect formBounds = bounds(find(ScrollView.class));
        assertTrue("Full slider must remain visible before scrolling: slider=" + sliderBounds + ", form=" + formBounds
                + ", editor=" + bounds(find(EditText.class)) + ", map=" + bounds(ui.mapContainer)
                + ", fontScale=" + RuntimeEnvironment.getFontScale(), sliderBounds.bottom <= formBounds.bottom);
        assertTrue(sliderBounds.top >= formBounds.top);
        assertTrue(sliderBounds.height() >= 48);
        assertTrue(bounds(ui.mapContainer).height() >= 250);
    }

    @Test public void doubleSizeTextRemainsReadableAndActionsStayVisible() {
        RuntimeEnvironment.setFontScale(2);
        ui = new JourneyUi(activity, listener);
        activity.setContentView(ui.root());
        ui.render("idle", "Walking routes may not include every path. Use caution.",
                "Madison Square Park", "Washington Square Park", 15, 1600, 200,
                false, false, true, "walk", "once", "road", false);
        ui.root().setPadding(8, 24, 8, 28);
        layout(360, 740);
        EditText editor = find(EditText.class);
        assertTrue("Speed editor cannot clip large text", editor.getHeight() >= editor.getLineHeight());
        assertTrue(bounds(editor).right <= 352);
        assertTrue(bounds(button("Start journey")).bottom <= 712);
        assertTrue(bounds(button("Start journey")).height() >= 48);
        assertTrue("Large text has a scrollable form", find(ScrollView.class).canScrollVertically(1));
    }

    @Test public void renderingNeverDispatchesACommand() {
        ready();
        ui.render("running", "", "Start", "End", 15, 1600, 200,
                true, false, false, "cycle", "once", "road", false);
        ui.render("paused", "", "Start", "End", 50, 1600, 100,
                true, false, false, "drive", "once", "road", false);
        assertEquals(0, listener.events.size());
    }

    @Test public void compactPortraitKeepsActionsVisibleAndMapSeparateFromForm() {
        ready();
        ui.root().setPadding(8, 24, 8, 28);
        layout(360, 740);
        Rect primaryBounds = bounds(button("Start journey"));
        Rect mapBounds = bounds(ui.mapContainer);
        assertTrue(primaryBounds.bottom <= 740 - 28);
        assertTrue(primaryBounds.height() >= 48);
        assertEquals(8, mapBounds.left);
        assertEquals(352, mapBounds.right);
        assertTrue("Map retains useful portrait space", mapBounds.height() >= 250);
        assertTrue("Map ends above route controls", mapBounds.bottom < primaryBounds.top);
        for (View view : descendants(ui.root())) {
            if (view instanceof Button && view.getVisibility() == View.VISIBLE && view.isShown()) {
                assertTrue("Button touch target: " + ((Button) view).getText(), view.getHeight() >= 48);
            }
        }
    }

    @Test public void landscapeKeepsMapBesideVisiblePrimaryAction() {
        ready();
        layout(740, 360);
        Rect mapBounds = bounds(ui.mapContainer);
        Rect primaryBounds = bounds(button("Start journey"));
        assertTrue(mapBounds.width() >= 350);
        assertTrue(primaryBounds.left >= mapBounds.right);
        assertTrue(primaryBounds.bottom <= 360);
    }

    @Test public void retryRouteIsAnEnabledPrimaryActionAndLoadingIsDisabled() {
        ui.render("route_error", "No route found", "Start", "End", 5, 0, 0,
                false, false, true, "walk", "once", "road", false);
        Button retry = button("Retry route");
        assertTrue(retry.isEnabled());
        retry.performClick();
        assertEquals("primary", listener.events.get(0));
        ui.render("idle", "", "Start", "End", 5, 0, 0,
                false, false, false, "walk", "once", "road", true);
        assertFalse(button("Finding route…").isEnabled());
    }

    @Test public void runningAndPausedOfferCorrectActionsWithoutEditableRoute() {
        ui.render("running", "", "Start", "End", 5, 1600, 200,
                true, false, false, "walk", "once", "road", false);
        layout(360, 740);
        assertTrue(button("Pause").isEnabled());
        assertTrue(button("Stop").isShown());
        assertTrue(bounds(button("Stop")).bottom <= 740);
        assertFalse(button("Walk").isShown());
        for (View view : descendants(ui.root())) {
            if (view.getContentDescription() != null && view.getContentDescription().toString().startsWith("Starting point.")) assertFalse(view.isEnabled());
        }
        ui.render("paused", "", "Start", "End", 5, 1600, 200,
                true, false, false, "walk", "once", "road", false);
        button("Resume").performClick();
        assertEquals("primary", listener.events.get(0));
    }

    @Test public void arrivedAndStationarySessionsHaveOneFullWidthStopAction() {
        ui.render("arrived", "", "Start", "End", 5, 1600, 0,
                true, false, false, "walk", "once", "road", false);
        layout(360, 740);
        assertTrue(bounds(button("Stop")).width() >= 300);
        ui.render("running", "", "Start", "", 5, 0, 0,
                true, false, false, "walk", "static", "direct", false);
        layout(360, 740);
        assertTrue(bounds(button("Stop")).width() >= 300);
        assertFalse(find(SeekBar.class).isShown());
        button("Stop").performClick();
        assertEquals("stop", listener.events.get(0));
    }

    @Test public void stateRefreshPreservesFocusedSpeedTextAndCursor() {
        ready();
        EditText editor = find(EditText.class);
        assertTrue(editor.requestFocus());
        editor.setText("17.");
        editor.setSelection(2);
        ui.render("idle", "", "Start", "End", 50, 1600, 200,
                false, false, true, "walk", "once", "road", false);
        assertEquals("17.", editor.getText().toString());
        assertEquals(2, editor.getSelectionStart());
        assertTrue(listener.events.isEmpty());
        editor.onEditorAction(EditorInfo.IME_ACTION_DONE);
        assertEquals(1, listener.events.size());
        assertEquals("speed:17.0", listener.events.get(0));
    }

    @Test public void touchSliderDispatchesOnlyTheReleasedValue() {
        ready();
        layout(360, 740);
        SeekBar slider = find(SeekBar.class);
        long when = SystemClock.uptimeMillis();
        dispatch(slider, when, MotionEvent.ACTION_DOWN, 10);
        dispatch(slider, when + 20, MotionEvent.ACTION_MOVE, slider.getWidth() * .3f);
        dispatch(slider, when + 40, MotionEvent.ACTION_MOVE, slider.getWidth() * .6f);
        assertEquals(0, listener.events.size());
        dispatch(slider, when + 60, MotionEvent.ACTION_UP, slider.getWidth() * .6f);
        assertEquals(1, listener.events.size());
        assertTrue(listener.events.get(0).startsWith("speed:"));
    }

    @Test public void invalidSpeedNeverReachesTheListener() {
        ready();
        EditText editor = find(EditText.class);
        editor.requestFocus();
        editor.setText("201");
        editor.onEditorAction(EditorInfo.IME_ACTION_DONE);
        assertNotNull(editor.getError());
        assertTrue(listener.events.isEmpty());
        editor.setText("0.5");
        editor.onEditorAction(EditorInfo.IME_ACTION_DONE);
        assertEquals("speed:0.5", listener.events.get(0));
    }

    /** Optional capture of actual native widgets; deliberately contains no fabricated map. */
    @Test @GraphicsMode(GraphicsMode.Mode.NATIVE)
    public void nativeWidgetRenderCanBeCapturedForReview() throws Exception {
        String outputDirectory = System.getenv("JOURNEY_UI_SCREENSHOT_DIR");
        if (outputDirectory == null || outputDirectory.isBlank()) return;
        ready();
        ui.setMapHint("Native UI preview · Google Maps is not loaded");
        layout(390, 844);
        ui.root().getViewTreeObserver().dispatchOnPreDraw();
        EditText editor = find(EditText.class);
        System.out.println("Native speed editor: text=" + editor.getText() + ", bounds=" + bounds(editor)
                + ", focus=" + editor.hasFocus() + ", scrollX=" + editor.getScrollX()
                + ", layout=" + (editor.getLayout() == null ? "null" : editor.getLayout().getWidth() + "x" + editor.getLayout().getHeight()));
        Bitmap bitmap = Bitmap.createBitmap(390, 844, Bitmap.Config.ARGB_8888);
        ui.root().draw(new Canvas(bitmap));
        File directory = new File(outputDirectory);
        if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Cannot create screenshot directory");
        try (FileOutputStream output = new FileOutputStream(new File(directory, "native-ui-preview-no-map.png"))) {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output));
        }
        bitmap.recycle();
    }

    private void ready() {
        ui.render("idle", "", "Madison Square Park", "Washington Square Park", 5, 1600, 1152,
                false, false, true, "walk", "once", "road", false);
    }

    private void layout(int width, int height) {
        ui.root().measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
        ui.root().layout(0, 0, width, height);
    }

    private Rect bounds(View view) {
        Rect rect = new Rect();
        view.getDrawingRect(rect);
        ((ViewGroup) ui.root()).offsetDescendantRectToMyCoords(view, rect);
        return rect;
    }

    private Button button(String label) {
        for (View view : descendants(ui.root())) {
            if (view instanceof Button && label.contentEquals(((TextView) view).getText())) return (Button) view;
        }
        throw new AssertionError("Missing button: " + label);
    }

    private <T extends View> T find(Class<T> type) {
        for (View view : descendants(ui.root())) if (type.isInstance(view)) return type.cast(view);
        throw new AssertionError("Missing widget: " + type.getSimpleName());
    }

    private static List<View> descendants(View root) {
        List<View> result = new ArrayList<>();
        result.add(root);
        if (root instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) root;
            for (int i = 0; i < group.getChildCount(); i++) result.addAll(descendants(group.getChildAt(i)));
        }
        return result;
    }

    private static void dispatch(SeekBar slider, long when, int action, float x) {
        MotionEvent event = MotionEvent.obtain(when, when, action, x, slider.getHeight() / 2f, 0);
        try { slider.dispatchTouchEvent(event); } finally { event.recycle(); }
    }

    private static final class RecordingListener implements JourneyUi.Listener {
        final List<String> events = new ArrayList<>();
        @Override public void onPoint(boolean destination) { events.add("point:" + destination); }
        @Override public void onPrimary() { events.add("primary"); }
        @Override public void onStopPlayback() { events.add("stop"); }
        @Override public void onSettings() { events.add("settings"); }
        @Override public void onOptions() { events.add("options"); }
        @Override public void onSpeed(double speedKmh) { events.add("speed:" + speedKmh); }
        @Override public void onPreset(String mode, double speedKmh) { events.add("preset:" + mode + ":" + speedKmh); }
    }
}
