// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.robolectric.Shadows.shadowOf;

import android.Manifest;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Looper;
import android.os.Process;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import com.google.android.gms.maps.MapView;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.LooperMode;
import org.robolectric.shadows.ShadowAlertDialog;
import org.robolectric.util.ReflectionHelpers;

/**
 * Native activity lifecycle regressions with online planning disabled. Android
 * records service Intents; these tests do not start mock providers, call Google,
 * emulate a MapView renderer, or attest a device. API 35 covers the real runtime
 * notification-request branch, API 23 checks offline authentication failure,
 * and other tests use the existing API 28 fixture.
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = Application.class, qualifiers = "w360dp-h740dp-mdpi")
@LooperMode(LooperMode.Mode.PAUSED)
public final class MainActivityTest {
    private static final String MANUAL_ROUTE = "{\"start\":[28.6001,77.2001],\"end\":[28.6201,77.2301],"
            + "\"speed\":5,\"kind\":\"direct\",\"playback\":\"once\",\"travel\":\"walk\"}";
    private ActivityController<MainActivity> controller;
    private MainActivity activity;

    @Before public void resetSession() {
        SimulationService.active = false;
        SimulationService.state = "{\"status\":\"idle\"}";
        SimulationService.stagedPlan = null;
        SimulationService.routePoints = null;
        application().getSharedPreferences("settings", 0).edit().clear()
                .putBoolean("online", false).putInt("googleConsentVersion", 1).commit();
        application().getSharedPreferences("nativeDraft", 0).edit().clear().commit();
        GoogleAuth.disable();
        for (FirebaseApp app : new ArrayList<>(FirebaseApp.getApps(application()))) app.delete();
        ReflectionHelpers.setStaticField(GoogleAuth.class, "check", null);
        drainServiceIntents();
    }

    @After public void cleanupSession() {
        if (controller != null) controller.pause().stop().destroy();
        GoogleAuth.disable();
        SimulationService.active = false;
        SimulationService.state = "{\"status\":\"idle\"}";
        SimulationService.stagedPlan = null;
        SimulationService.routePoints = null;
        drainServiceIntents();
    }

    @Test public void offlineLaunchDoesNotCreateGoogleMapFirebaseOrStartPlayback() {
        launch();
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertTrue(FirebaseApp.getApps(activity).isEmpty());
        assertNull(ReflectionHelpers.getStaticField(GoogleAuth.class, "check"));
        assertFalse(button("Start journey").isEnabled());
        assertNull(nextServiceIntent());
    }

    @Test @Config(sdk = 23)
    public void api23OfflineAuthFailsClearlyWhileCoordinateControlsRemainUsable() throws Exception {
        saveDraft("{\"kind\":\"direct\"}");
        launch();
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertTrue(FirebaseApp.getApps(activity).isEmpty());
        assertFalse(button("Start journey").isEnabled());

        Future<String> token = GoogleAuth.getAppCheckToken();
        assertTrue("An unconfigured token request must fail without waiting for network", token.isDone());
        try {
            token.get();
            fail("Offline planning must not return an App Check token");
        } catch (ExecutionException expected) {
            assertTrue(expected.getCause() instanceof IllegalStateException);
            assertTrue(expected.getCause().getMessage().contains("not configured"));
        }

        enterCoordinates(false, "28.6139,77.2090");
        enterCoordinates(true, "28.6200,77.2200");
        assertTrue(button("Start journey").isEnabled());
        assertEquals(28.6139, savedDraft().getJSONArray("start").getDouble(0), 0);
        assertNull(find(activity.findViewById(android.R.id.content), MapView.class));
        assertTrue(FirebaseApp.getApps(activity).isEmpty());
        assertNull(ReflectionHelpers.getStaticField(GoogleAuth.class, "check"));
        assertNull(nextServiceIntent());
    }

    @Test public void coordinatesCanPlanAnOfflineRouteAndRejectInvalidNumbers() throws Exception {
        saveDraft("{\"kind\":\"direct\"}");
        launch();
        enterCoordinates(false, " 28.6139, 77.2090 ");
        enterCoordinates(true, "28.6200, 77.2200");
        assertTrue(button("Start journey").isEnabled());
        JSONObject saved = savedDraft();
        assertEquals(28.6139, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2200, saved.getJSONArray("end").getDouble(1), 0);
        assertArrayEquals(new double[]{-90, 180}, MainActivity.parseCoordinates("-90, 180"), 0);
        for (String bad : new String[]{"91,0", "0,181", "NaN,0", "Infinity,0", "1,2,3", "one,two", ""}) {
            assertNull(bad, MainActivity.parseCoordinates(bad));
        }
        assertNull(nextServiceIntent());
        assertTrue(FirebaseApp.getApps(activity).isEmpty());
    }

    @Test public void rationaleSurvivesBackgroundResumeWithoutStartingUntilExplicitSkip() {
        readyRoute();
        activity.onPrimary();
        AlertDialog rationale = rationale();
        assertTrue(rationale.isShowing());
        assertFalse(button("Please wait…").isEnabled());
        controller.pause().stop().start().resume();
        idle();
        assertNull("Returning to the app must not choose Skip for the user", nextServiceIntent());
        assertNull(SimulationService.stagedPlan);
        rationale.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
        idle();
        assertSingleStart();
        controller.pause().resume();
        idle();
        assertNull("Resume must not enqueue another start", nextServiceIntent());
    }

    @Test public void cancellingPermissionRationaleImmediatelyRestoresReadyControls() {
        readyRoute();
        activity.onPrimary();
        rationale().cancel();
        idle();
        assertTrue(button("Start journey").isEnabled());
        assertNull(nextServiceIntent());
        assertNull(SimulationService.stagedPlan);
        controller.pause().resume();
        idle();
        assertNull("A cancelled start cannot return on resume", nextServiceIntent());
    }

    @Test public void recreationKeepsPermissionExplanationAndStartsOnlyAfterChoice() {
        readyRoute();
        activity.onPrimary();
        AlertDialog previous = rationale();
        controller.recreate();
        activity = controller.get();
        idle();
        AlertDialog restored = rationale();
        assertFalse("The old activity must release its dialog window", previous.isShowing());
        assertTrue(restored.isShowing());
        assertNull(nextServiceIntent());
        restored.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
        idle();
        assertSingleStart();
    }

    @Test @Config(sdk = 35)
    public void recreationDuringRuntimePermissionRequestContinuesOnceEvenWhenDenied() {
        shadowOf(application()).denyPermissions(Manifest.permission.POST_NOTIFICATIONS);
        readyRoute();
        activity.onPrimary();
        rationale().getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        idle();
        assertNotNull("API 35 must request the optional notification permission",
                shadowOf(activity).getLastRequestedPermission());
        assertNull(nextServiceIntent());
        controller.recreate();
        activity = controller.get();
        idle();
        assertNull("Recreation must still wait for the platform permission result", nextServiceIntent());
        activity.onRequestPermissionsResult(10, new String[]{Manifest.permission.POST_NOTIFICATIONS},
                new int[]{PackageManager.PERMISSION_DENIED});
        idle();
        assertSingleStart();
        activity.onRequestPermissionsResult(10, new String[]{Manifest.permission.POST_NOTIFICATIONS},
                new int[]{PackageManager.PERMISSION_DENIED});
        idle();
        assertNull("A duplicate callback must not duplicate the service start", nextServiceIntent());
    }

    @Test public void restoringServiceGeometryDoesNotPersistUnknownGoogleEndpoints() throws Exception {
        activeService();
        launch();
        activity.onSpeed(8);
        JSONObject saved = savedDraft();
        assertFalse("Service-derived start stays in memory", saved.has("start"));
        assertFalse("Service-derived destination stays in memory", saved.has("end"));
        assertFalse(saved.has("geometry"));
        assertEquals(8, saved.getDouble("speed"), 0);
    }

    @Test public void serviceUpdatesPreserveOriginalManualEndpointsInsteadOfSnappedPoints() throws Exception {
        saveDraft(MANUAL_ROUTE);
        activeService();
        launch();
        activity.onSpeed(12);
        JSONObject saved = savedDraft();
        assertEquals(28.6001, saved.getJSONArray("start").getDouble(0), 0);
        assertEquals(77.2001, saved.getJSONArray("start").getDouble(1), 0);
        assertEquals(28.6201, saved.getJSONArray("end").getDouble(0), 0);
        assertEquals(77.2301, saved.getJSONArray("end").getDouble(1), 0);
    }

    private void readyRoute() {
        saveDraft(MANUAL_ROUTE);
        launch();
        AppOpsManager appOps = (AppOpsManager) activity.getSystemService(Context.APP_OPS_SERVICE);
        shadowOf(appOps).setMode("android:mock_location", Process.myUid(), activity.getPackageName(), AppOpsManager.MODE_ALLOWED);
        assertTrue(button("Start journey").isEnabled());
    }

    private void launch() {
        controller = Robolectric.buildActivity(MainActivity.class).setup();
        activity = controller.get();
        idle();
    }

    private void enterCoordinates(boolean destination, String text) {
        activity.onPoint(destination);
        AlertDialog dialog = ShadowAlertDialog.getLatestAlertDialog();
        EditText input = find(dialog.getWindow().getDecorView(), EditText.class);
        assertNotNull(input);
        input.setText(text);
        assertTrue(dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled());
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
        idle();
        assertFalse(dialog.isShowing());
    }

    private AlertDialog rationale() {
        AlertDialog dialog = ReflectionHelpers.getField(activity, "permissionDialog");
        assertNotNull("Starting a fresh session must display its explanation", dialog);
        return dialog;
    }

    private void assertSingleStart() {
        Intent intent = nextServiceIntent();
        assertNotNull("Expected one start service Intent", intent);
        assertEquals("start", intent.getAction());
        assertEquals(SimulationService.class.getName(), intent.getComponent().getClassName());
        assertNotNull(SimulationService.stagedPlan);
        assertNull(nextServiceIntent());
    }

    private static void activeService() {
        SimulationService.active = true;
        SimulationService.routePoints = new double[][]{{28.6009, 77.2009}, {28.6209, 77.2309}};
        SimulationService.state = "{\"status\":\"running\",\"speedKmh\":5,\"mode\":\"once\","
                + "\"totalMeters\":3200,\"distanceMeters\":0,\"lat\":28.6009,\"lon\":77.2009}";
    }
    private static Application application() { return RuntimeEnvironment.getApplication(); }
    private static void idle() { shadowOf(Looper.getMainLooper()).idle(); }
    private static Intent nextServiceIntent() { return shadowOf(application()).getNextStartedService(); }
    private static void drainServiceIntents() { while (nextServiceIntent() != null) { } }
    private static void saveDraft(String value) {
        application().getSharedPreferences("nativeDraft", 0).edit().putString("value", value).commit();
    }
    private static JSONObject savedDraft() throws Exception {
        return new JSONObject(application().getSharedPreferences("nativeDraft", 0).getString("value", "{}"));
    }
    private Button button(String label) {
        Button result = findButton(activity.findViewById(android.R.id.content), label);
        assertNotNull("Missing button: " + label, result);
        return result;
    }
    private static Button findButton(View view, String label) {
        if (view instanceof Button && label.contentEquals(((Button) view).getText())) return (Button) view;
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            Button found = findButton(((ViewGroup) view).getChildAt(i), label);
            if (found != null) return found;
        }
        return null;
    }
    private static <T extends View> T find(View view, Class<T> type) {
        if (type.isInstance(view)) return type.cast(view);
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
            T found = find(((ViewGroup) view).getChildAt(i), type);
            if (found != null) return found;
        }
        return null;
    }
}
