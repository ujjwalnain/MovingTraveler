// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import static org.junit.Assert.*;
import android.app.Application;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/** Deterministic transport/auth fixtures. No Google requests or billable calls. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28, application = Application.class)
public final class NetworkGatewayTest {
    private static final String SESSION = "13eac630-5665-4c40-916b-8b615f0a1d34";
    private static final String ROUTE = "{\"points\":[[0,0],[0,0.001]],\"distanceMeters\":112,\"durationSeconds\":30}";
    private static final String PLACE = "{\"lat\":51.5,\"lon\":-0.12,\"label\":\"Selected address\"}";
    private final List<NetworkGateway> gateways = new ArrayList<>();

    @After public void closeGateways() { for (NetworkGateway gateway : gateways) gateway.close(); }

    @Test public void routeAndPlaceProceedWhileSearchIsPending() throws Exception {
        CountDownLatch searchEntered = new CountDownLatch(1), releaseSearch = new CountDownLatch(1);
        CountDownLatch routeDone = new CountDownLatch(1), placeDone = new CountDownLatch(1);
        List<String> sent = Collections.synchronizedList(new ArrayList<>());
        AtomicReference<JSONObject> routeResponse = new AtomicReference<>();
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            assertEquals("app-check-fixture", token);
            JSONObject payload = new JSONObject(body);
            assertFalse("Only endpoint payload reaches the server", payload.has("id"));
            assertFalse(payload.has("type"));
            sent.add(url.getPath());
            if (url.getPath().equals("/search")) {
                assertEquals(SESSION, payload.getString("sessionToken"));
                searchEntered.countDown();
                releaseSearch.await();
                return ok("[]");
            }
            if (url.getPath().equals("/place")) {
                assertEquals(SESSION, payload.getString("sessionToken"));
                return ok(PLACE);
            }
            assertEquals("DRIVE", payload.getString("travelMode"));
            assertEquals(2, payload.getJSONArray("points").length());
            return ok(ROUTE);
        });
        gateway.request(search("search-1"), ignored -> {});
        await(searchEntered);
        gateway.request(route("route-1"), response -> { routeResponse.set(response); routeDone.countDown(); });
        gateway.request(place("place-1"), response -> { assertTrue(response.optBoolean("ok")); placeDone.countDown(); });
        await(routeDone);
        await(placeDone);
        assertEquals("route-1", routeResponse.get().getString("id"));
        assertTrue(routeResponse.get().getBoolean("ok"));
        assertTrue(sent.contains("/route") && sent.contains("/search") && sent.contains("/place"));
        releaseSearch.countDown();
    }

    @Test public void replacingAnInflightRouteCancelsItAndOnlyReturnsTheNewestRoute() throws Exception {
        CountDownLatch firstEntered = new CountDownLatch(1), firstCancelled = new CountDownLatch(1);
        CountDownLatch newestDone = new CountDownLatch(1);
        AtomicInteger calls = new AtomicInteger();
        List<String> responses = Collections.synchronizedList(new ArrayList<>());
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            if (calls.incrementAndGet() == 1) {
                cancellation.onCancel(firstCancelled::countDown);
                firstEntered.countDown();
                firstCancelled.await();
            }
            return ok(ROUTE);
        });
        gateway.request(route("old"), response -> responses.add(response.optString("id")));
        await(firstEntered);
        gateway.request(route("new"), response -> { responses.add(response.optString("id")); newestDone.countDown(); });
        await(firstCancelled);
        await(newestDone);
        assertEquals(Collections.singletonList("new"), responses);
        assertEquals(2, calls.get());
    }

    @Test public void rapidEditsKeepOnlyTheLatestQueuedRequest() throws Exception {
        CountDownLatch firstEntered = new CountDownLatch(1), releaseFirst = new CountDownLatch(1);
        CountDownLatch latestDone = new CountDownLatch(1);
        AtomicInteger calls = new AtomicInteger();
        List<String> responses = Collections.synchronizedList(new ArrayList<>());
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            if (calls.incrementAndGet() == 1) {
                firstEntered.countDown();
                // Model an outstanding DNS/transport operation that finishes after cancellation.
                boolean released = false;
                while (!released) {
                    try { releaseFirst.await(); released = true; }
                    catch (InterruptedException ignored) { }
                }
            }
            return ok(ROUTE);
        });
        gateway.request(route("old"), response -> responses.add(response.optString("id")));
        await(firstEntered);
        for (int i = 0; i < 40; i++) {
            gateway.request(route("edit-" + i), response -> {
                responses.add(response.optString("id"));
                if ("edit-39".equals(response.optString("id"))) latestDone.countDown();
            });
        }
        releaseFirst.countDown();
        await(latestDone);
        assertEquals(Collections.singletonList("edit-39"), responses);
        assertEquals("Superseded queued requests never reach the proxy", 2, calls.get());
    }

    @Test public void cancelSuppressesLateCallbackAndDoesNotCancelOtherLanes() throws Exception {
        CountDownLatch entered = new CountDownLatch(1), cancelled = new CountDownLatch(1);
        CountDownLatch searchDone = new CountDownLatch(1), nextDone = new CountDownLatch(1);
        AtomicInteger routeCalls = new AtomicInteger(), staleResponses = new AtomicInteger();
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            if (url.getPath().equals("/search")) return ok("[]");
            if (routeCalls.incrementAndGet() == 1) {
                cancellation.onCancel(cancelled::countDown);
                entered.countDown();
                cancelled.await();
            }
            return ok(ROUTE);
        });
        gateway.request(route("cancelled"), response -> staleResponses.incrementAndGet());
        await(entered);
        gateway.cancel("route");
        await(cancelled);
        gateway.request(search("search-after"), response -> searchDone.countDown());
        gateway.request(route("route-after"), response -> nextDone.countDown());
        await(searchDone);
        await(nextDone);
        assertEquals(0, staleResponses.get());
    }

    @Test public void requestDeadlineAbortsTransportAndLaneCanBeUsedAgain() throws Exception {
        CountDownLatch entered = new CountDownLatch(1), aborted = new CountDownLatch(1);
        CountDownLatch expired = new CountDownLatch(1), nextDone = new CountDownLatch(1);
        AtomicInteger calls = new AtomicInteger();
        AtomicReference<JSONObject> error = new AtomicReference<>();
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            if (calls.incrementAndGet() == 1) {
                cancellation.onCancel(aborted::countDown);
                entered.countDown();
                aborted.await();
            }
            return ok(ROUTE);
        }, 200);
        gateway.request(route("timeout"), response -> { error.set(response); expired.countDown(); });
        await(entered);
        await(expired);
        await(aborted);
        assertFalse(error.get().getBoolean("ok"));
        assertTrue(error.get().getString("error").contains("timed out"));
        gateway.request(route("retry"), response -> { assertTrue(response.optBoolean("ok")); nextDone.countDown(); });
        await(nextDone);
    }

    @Test public void closeAbortsAllLanesAndSuppressesCallbacks() throws Exception {
        CountDownLatch entered = new CountDownLatch(3), aborted = new CountDownLatch(3);
        AtomicInteger responses = new AtomicInteger();
        NetworkGateway gateway = gateway((url, body, token, cancellation) -> {
            cancellation.onCancel(aborted::countDown);
            entered.countDown();
            aborted.await();
            return ok(url.getPath().equals("/search") ? "[]" : url.getPath().equals("/place") ? PLACE : ROUTE);
        });
        gateway.request(route("r"), response -> responses.incrementAndGet());
        gateway.request(search("s"), response -> responses.incrementAndGet());
        gateway.request(place("p"), response -> responses.incrementAndGet());
        await(entered);
        gateway.close();
        await(aborted);
        gateway.request(route("after-close"), response -> responses.incrementAndGet());
        assertEquals(0, responses.get());
    }

    @Test public void parserPreservesNormalizedGeometryAndAcceptsEmptySearchResults() throws Exception {
        JSONObject route = (JSONObject) NetworkGateway.parseData("route", ROUTE);
        assertEquals(2, route.getJSONArray("points").length());
        assertEquals(0.001, route.getJSONArray("points").getJSONArray(1).getDouble(1), 0);
        assertEquals(112, route.getDouble("distanceMeters"), 0);
        assertEquals(30, route.getDouble("durationSeconds"), 0);
        assertEquals(0, ((JSONArray) NetworkGateway.parseData("search", "[]")).length());
        JSONObject place = (JSONObject) NetworkGateway.parseData("place", PLACE);
        assertEquals(51.5, place.getDouble("lat"), 0);
        assertEquals("Selected address", place.getString("label"));
        assertEquals(0, place.getJSONArray("attributions").length());
        JSONArray suggestions = (JSONArray) NetworkGateway.parseData("search", "[{\"placeId\":\"ChIJabc\",\"label\":\"Address\"}]");
        assertEquals("ChIJabc", suggestions.getJSONObject(0).getString("placeId"));
    }

    @Test public void placeParserPreservesProviderCreditsAndOptionalLinks() throws Exception {
        JSONObject response = new JSONObject(PLACE).put("attributions", new JSONArray()
                .put(new JSONObject().put("provider", "Data provider").put("providerUri", "https://provider.example.test/about"))
                .put(new JSONObject().put("provider", "Provider without link")));
        JSONObject place = (JSONObject) NetworkGateway.parseData("place", response.toString());
        JSONArray attributions = place.getJSONArray("attributions");
        assertEquals(2, attributions.length());
        assertEquals("Data provider", attributions.getJSONObject(0).getString("provider"));
        assertEquals("https://provider.example.test/about", attributions.getJSONObject(0).getString("providerUri"));
        assertEquals("", attributions.getJSONObject(1).getString("providerUri"));
    }

    @Test public void placeParserRejectsMalformedOrExecutableProviderLinks() throws Exception {
        for (String link : new String[]{"javascript:alert(1)", "intent://example", "file:///private/file",
                "https://user:secret@provider.example.test", "//provider.example.test", "https://"}) {
            invalid("place", new JSONObject(PLACE).put("attributions", new JSONArray()
                    .put(new JSONObject().put("provider", "Provider").put("providerUri", link))).toString());
        }
        invalid("place", new JSONObject(PLACE).put("attributions", JSONObject.NULL).toString());
        invalid("place", new JSONObject(PLACE).put("attributions", new JSONArray()
                .put(new JSONObject().put("provider", "bad\ncredit"))).toString());
        invalid("place", new JSONObject(PLACE).put("attributions", new JSONArray()
                .put(new JSONObject().put("provider", "Provider").put("providerUri", JSONObject.NULL))).toString());
        JSONArray many = new JSONArray();
        for (int i = 0; i < 33; i++) many.put(new JSONObject().put("provider", "Provider"));
        invalid("place", new JSONObject(PLACE).put("attributions", many).toString());
    }

    @Test public void parserRejectsInvalidGeometryWithoutSubstitutingADirectLine() throws Exception {
        invalid("route", "{\"points\":[[0,0]],\"distanceMeters\":5,\"durationSeconds\":1}");
        invalid("route", "{\"points\":[[0,0],[91,0]],\"distanceMeters\":5,\"durationSeconds\":1}");
        invalid("route", "{\"points\":[[0,0],[\"0\",\"1\"]],\"distanceMeters\":5,\"durationSeconds\":1}");
        invalid("route", "{\"points\":[[0,0],[0,0]],\"distanceMeters\":5,\"durationSeconds\":1}");
        invalid("route", "{\"points\":[[0,0],[0,1]],\"distanceMeters\":-1,\"durationSeconds\":1}");
        invalid("route", "{\"points\":[[0,0],[0,1]],\"distanceMeters\":5,\"durationSeconds\":-1}");
        invalid("route", ROUTE + "trailing");
        invalid("route", "{\"routes\":[]}");
        invalid("place", "{\"lat\":0,\"lon\":181,\"label\":\"Wrong\"}");
        invalid("search", "[{\"placeId\":\"id\",\"label\":\"bad\\nlabel\"}]");
        JSONArray many = new JSONArray();
        for (int i = 0; i <= RouteEngine.MAX_POINTS; i++) many.put(new JSONArray().put(0).put(i * 0.00001));
        invalid("route", new JSONObject().put("points", many).put("distanceMeters", 1000).put("durationSeconds", 100).toString());
    }

    @Test public void proxyFailureReturnsAnErrorWithoutInventedGeometry() throws Exception {
        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<JSONObject> response = new AtomicReference<>();
        NetworkGateway gateway = gateway((url, body, token, cancellation) ->
                new NetworkGateway.HttpResult(404, "{\"error\":{\"code\":\"NO_ROUTE\",\"message\":\"upstream details\"}}"));
        gateway.request(route("missing"), result -> { response.set(result); done.countDown(); });
        await(done);
        assertFalse(response.get().getBoolean("ok"));
        assertFalse(response.get().has("data"));
        assertTrue(response.get().getString("error").contains("no route"));
        assertFalse(response.get().getString("error").contains("upstream details"));
    }

    @Test public void offlineAndUnconfiguredRequestsNeverCallTransport() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        NetworkGateway.Transport transport = (url, body, token, cancellation) -> { calls.incrementAndGet(); return ok(ROUTE); };
        CountDownLatch offlineDone = new CountDownLatch(1), configDone = new CountDownLatch(1);
        NetworkGateway offline = new NetworkGateway(() -> false, "https://proxy.example.test",
                () -> CompletableFuture.completedFuture("fixture"), transport, 5000);
        gateways.add(offline);
        offline.request(route("offline"), response -> { assertFalse(response.optBoolean("ok")); offlineDone.countDown(); });
        NetworkGateway unconfigured = new NetworkGateway(() -> true, "",
                () -> CompletableFuture.completedFuture("fixture"), transport, 5000);
        gateways.add(unconfigured);
        unconfigured.request(route("configuration"), response -> {
            assertTrue(response.optString("error").contains("configured"));
            configDone.countDown();
        });
        await(offlineDone);
        await(configDone);
        assertEquals(0, calls.get());
    }

    @Test public void endpointsRequireHttpsAndRejectCredentialsQueryAndTraversal() throws Exception {
        assertEquals("https://proxy.example.test/api/route", NetworkGateway.endpoint("https://proxy.example.test/api/", "route").toString());
        for (String base : new String[] {"http://proxy.example.test", "https://user:pass@proxy.example.test",
                "https://proxy.example.test?secret=value", "https://proxy.example.test/#route",
                "https://proxy.example.test/a/../b"}) {
            try { NetworkGateway.endpoint(base, "route"); fail("Accepted unsafe base URL"); }
            catch (NetworkGateway.UserError expected) { }
        }
    }

    private NetworkGateway gateway(NetworkGateway.Transport transport) { return gateway(transport, 5000); }
    private NetworkGateway gateway(NetworkGateway.Transport transport, long timeout) {
        NetworkGateway result = new NetworkGateway(() -> true, "https://proxy.example.test",
                () -> CompletableFuture.completedFuture("app-check-fixture"), transport, timeout);
        gateways.add(result);
        return result;
    }
    private static NetworkGateway.HttpResult ok(String body) { return new NetworkGateway.HttpResult(200, body); }
    private static String route(String id) throws Exception {
        return new JSONObject().put("id", id).put("type", "route").put("travelMode", "DRIVE")
                .put("points", new JSONArray("[[0,0],[0,0.001]]")).toString();
    }
    private static String search(String id) throws Exception {
        return new JSONObject().put("id", id).put("type", "search").put("query", "Selected address")
                .put("sessionToken", SESSION).toString();
    }
    private static String place(String id) throws Exception {
        return new JSONObject().put("id", id).put("type", "place").put("placeId", "ChIJfixture")
                .put("sessionToken", SESSION).toString();
    }
    private static void await(CountDownLatch latch) throws InterruptedException {
        assertTrue("Asynchronous operation did not finish", latch.await(5, TimeUnit.SECONDS));
    }
    private static void invalid(String type, String json) throws Exception {
        try { NetworkGateway.parseData(type, json); fail("Expected malformed payload rejection"); }
        catch (NetworkGateway.UserError expected) { }
    }
}
