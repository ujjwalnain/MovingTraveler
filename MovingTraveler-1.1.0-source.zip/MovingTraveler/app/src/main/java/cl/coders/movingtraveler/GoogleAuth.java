// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.appcheck.FirebaseAppCheck;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

/** App Check protects the proxy. It is initialized only after online consent. */
final class GoogleAuth {
    private static FirebaseAppCheck check;
    private static volatile boolean enabled;

    static boolean configured() {
        return !BuildConfig.FIREBASE_APPLICATION_ID.isEmpty()
                && !BuildConfig.FIREBASE_PROJECT_ID.isEmpty()
                && !BuildConfig.FIREBASE_API_KEY.isEmpty();
    }

    static synchronized void enable(Context context) {
        if (!configured()) return;
        if (check == null) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApplicationId(BuildConfig.FIREBASE_APPLICATION_ID)
                    .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
                    .setApiKey(BuildConfig.FIREBASE_API_KEY).build();
            FirebaseApp app;
            try { app = FirebaseApp.getInstance("planning"); }
            catch (IllegalStateException missing) {
                app = FirebaseApp.initializeApp(context.getApplicationContext(), options, "planning");
            }
            app.setDataCollectionDefaultEnabled(false);
            check = FirebaseAppCheck.getInstance(app);
            check.installAppCheckProviderFactory(AppCheckFactory.provider());
        }
        enabled = true;
        check.setTokenAutoRefreshEnabled(true);
    }

    static synchronized void disable() {
        enabled = false;
        if (check != null) check.setTokenAutoRefreshEnabled(false);
    }

    // FutureTask is available on API23; CompletableFuture is not part of Android's
    // supported core-library desugaring surface on that API level.
    private static final class TokenFuture extends FutureTask<String> {
        TokenFuture() { super(() -> ""); }
        void success(String token) { set(token); }
        void fail(Exception error) { setException(error); }
    }

    static synchronized Future<String> getAppCheckToken() {
        TokenFuture result = new TokenFuture();
        if (!enabled || check == null) {
            result.fail(new IllegalStateException(
                    "Online planning is not configured. See the Google setup guide."));
            return result;
        }
        check.getAppCheckToken(false).addOnSuccessListener(token -> {
            if (enabled) result.success(token.getToken());
            else result.fail(new IllegalStateException("Online planning is disabled."));
        }).addOnFailureListener(error -> result.fail(new IllegalStateException(
                "App verification failed. Check the Firebase App Check setup for this build.")));
        return result;
    }
}
