// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BooleanSupplier;

/**
 * Authenticated Google proxy client. Route, search and place requests have
 * independent latest-request-wins lanes. Nothing is cached or logged here.
 * Cancellation suppresses callbacks and disconnects any outstanding HTTP call.
 */
final class NetworkGateway {
    interface Callback { void accept(JSONObject response); }
    interface TokenSource { Future<String> get(); }
    interface Transport {
        HttpResult post(URL endpoint, String body, String appCheckToken, Cancellation cancellation)
                throws Exception;
    }

    static final long REQUEST_TIMEOUT_MILLIS = 20_000;
    static final int MAX_RESPONSE_BYTES = 2_000_000;
    private final BooleanSupplier online;
    private final String baseUrl;
    private final TokenSource tokens;
    private final Transport transport;
    private final long timeoutMillis;
    private final Map<String, Lane> lanes = new HashMap<>();
    private final ScheduledExecutorService deadlines = Executors.newSingleThreadScheduledExecutor(
            runnable -> daemon(runnable, "Google-request-deadlines"));
    private boolean closed;

    NetworkGateway(Context context) {
        this(() -> context.getApplicationContext().getSharedPreferences("settings", 0)
                        .getBoolean("online", false),
                BuildConfig.GOOGLE_PROXY_BASE_URL, GoogleAuth::getAppCheckToken,
                new HttpTransport(), REQUEST_TIMEOUT_MILLIS);
    }

    /** Package-private dependency seam: deterministic tests never call Google. */
    NetworkGateway(BooleanSupplier online, String baseUrl, TokenSource tokens,
            Transport transport, long timeoutMillis) {
        if (timeoutMillis < 1) throw new IllegalArgumentException("Invalid request deadline");
        this.online = online;
        this.baseUrl = baseUrl;
        this.tokens = tokens;
        this.transport = transport;
        this.timeoutMillis = timeoutMillis;
        for (String type : new String[] {"route", "search", "place"}) lanes.put(type, new Lane(type));
    }

    void request(String raw, Callback callback) {
        if (callback == null) return;
        JSONObject request;
        try {
            if (raw == null || raw.length() > 64_000) return;
            request = new JSONObject(raw);
            if (!(request.opt("id") instanceof String) || request.getString("id").length() > 120
                    || request.getString("id").isEmpty()) return;
        } catch (JSONException invalid) { return; }
        String type = request.optString("type");
        Lane lane = lanes.get(type);
        if (lane == null) {
            callback.accept(response(request, null, "Unsupported map request."));
            return;
        }
        Job job = new Job(request, callback, lane, timeoutMillis);
        synchronized (this) {
            if (closed) return;
            if (lane.current != null) lane.current.cancel();
            lane.executor.purge();
            lane.current = job;
            job.deadline = deadlines.schedule(() -> expire(job), timeoutMillis, TimeUnit.MILLISECONDS);
            job.future = lane.executor.submit(() -> run(job));
        }
    }

    /** A lane name is route, search or place. "all" cancels every request. */
    void cancel(String channel) {
        synchronized (this) {
            if ("all".equals(channel)) {
                for (Lane lane : lanes.values()) cancelLane(lane);
            } else {
                Lane lane = lanes.get(channel);
                if (lane != null) cancelLane(lane);
            }
        }
    }

    private void cancelLane(Lane lane) {
        if (lane.current != null) lane.current.cancel();
        lane.current = null;
        lane.executor.purge();
    }

    private void run(Job job) {
        try {
            job.cancellation.check();
            requireOnline();
            URL endpoint = endpoint(baseUrl, job.lane.type);
            JSONObject payload = payload(job.request);
            String token;
            try {
                token = tokens.get().get(Math.min(6000, job.cancellation.remainingMillis()),
                        TimeUnit.MILLISECONDS);
            } catch (ExecutionException failure) {
                throw new UserError("App verification is unavailable. Check Google setup and try again.");
            } catch (TimeoutException timeout) {
                throw new UserError("App verification timed out. Check your connection and try again.");
            }
            if (token == null || token.isEmpty() || token.length() > 4096
                    || token.indexOf('\r') >= 0 || token.indexOf('\n') >= 0) {
                throw new UserError("App verification is unavailable. Reopen the app and try again.");
            }
            job.cancellation.check();
            requireOnline();
            HttpResult result = transport.post(endpoint, payload.toString(), token, job.cancellation);
            job.cancellation.check();
            requireOnline();
            if (result.status < 200 || result.status >= 300) {
                throw new UserError(httpError(result.status, result.body));
            }
            complete(job, parseData(job.lane.type, result.body), null);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        } catch (CancellationException ignored) {
            // A newer request or explicit cancellation owns this lane now.
        } catch (UserError invalid) {
            complete(job, null, invalid.getMessage());
        } catch (SocketTimeoutException | TimeoutException timeout) {
            complete(job, null, "The Google request timed out. Check your connection and try again.");
        } catch (Exception failure) {
            complete(job, null, "Couldn't reach Google maps. Check your connection and try again.");
        }
    }

    private void expire(Job job) {
        synchronized (this) {
            if (closed || job.cancellation.isCancelled() || job.lane.current != job) return;
            job.lane.current = null;
            job.cancel();
            job.lane.executor.purge();
            job.callback.accept(response(job.request, null,
                    "The Google request timed out. Check your connection and try again."));
        }
    }

    private void complete(Job job, Object data, String error) {
        synchronized (this) {
            if (closed || job.cancellation.isCancelled() || job.lane.current != job) return;
            job.lane.current = null;
            if (job.deadline != null) job.deadline.cancel(false);
            // Callback commitment is serialized with replacement and cancellation.
            job.callback.accept(response(job.request, data, error));
        }
    }

    private void requireOnline() throws UserError {
        if (!online.getAsBoolean()) throw new UserError("Online maps are off. Enable them to search or request a route.");
    }

    static URL endpoint(String base, String type) throws UserError {
        try {
            if (base == null || base.trim().isEmpty()) {
                throw new UserError("Google routing isn't configured yet. Complete Google setup first.");
            }
            URI uri = URI.create(base);
            if (!"https".equals(uri.getScheme()) || uri.getHost() == null
                    || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null
                    || !uri.normalize().equals(uri)) throw new IllegalArgumentException();
            return new URL(base.replaceAll("/+$", "") + "/" + type);
        } catch (IllegalArgumentException | IOException invalid) {
            throw new UserError("The Google proxy needs a valid HTTPS address. Check app configuration.");
        }
    }

    private static JSONObject payload(JSONObject request) throws JSONException, UserError {
        String type = request.getString("type");
        JSONObject body = new JSONObject();
        if ("route".equals(type)) {
            JSONArray points = request.optJSONArray("points");
            if (points == null || points.length() != 2) throw new UserError("Choose a start and destination for your route.");
            body.put("points", checkedPoints(points, 2, 2));
            String mode = request.optString("travelMode", "DRIVE");
            if (!"DRIVE".equals(mode) && !"WALK".equals(mode) && !"BICYCLE".equals(mode)) {
                throw new UserError("Choose driving, walking or cycling.");
            }
            body.put("travelMode", mode);
        } else {
            String token = request.optString("sessionToken");
            if (!token.matches("[A-Za-z0-9_-]{16,36}")) throw new UserError("Restart place search to begin a new session.");
            body.put("sessionToken", token);
            if ("search".equals(type)) {
                String query = request.optString("query").trim();
                if (query.length() < 2 || query.length() > 200) throw new UserError("Enter a place name between 2 and 200 characters.");
                body.put("query", query);
            } else {
                String placeId = checkedText(request.opt("placeId"), 512, "Invalid place selection.");
                if (!placeId.matches("[A-Za-z0-9_-]+")) throw new UserError("Invalid place selection.");
                body.put("placeId", placeId);
            }
        }
        return body;
    }

    /** Proxy responses are normalized; the backend decodes Google's encoded polyline. */
    static Object parseData(String type, String text) throws UserError {
        try {
            if (text == null || text.getBytes(StandardCharsets.UTF_8).length > MAX_RESPONSE_BYTES) {
                throw new UserError("The Google response was too large. Choose a shorter route.");
            }
            JSONTokener parser = new JSONTokener(text);
            Object value = parser.nextValue();
            if (parser.nextClean() != 0) throw new JSONException("Trailing content");
            if ("search".equals(type)) {
                if (!(value instanceof JSONArray)) throw new JSONException("Expected suggestions");
                JSONArray input = (JSONArray) value;
                if (input.length() > 5) throw new JSONException("Too many suggestions");
                JSONArray output = new JSONArray();
                for (int i = 0; i < input.length(); i++) {
                    JSONObject suggestion = input.getJSONObject(i);
                    output.put(new JSONObject()
                            .put("placeId", checkedText(suggestion.opt("placeId"), 512, "Invalid place response."))
                            .put("label", checkedText(suggestion.opt("label"), 1024, "Invalid place response.")));
                }
                return output;
            }
            if (!(value instanceof JSONObject)) throw new JSONException("Expected object");
            JSONObject input = (JSONObject) value;
            if ("place".equals(type)) {
                double lat = number(input.opt("lat")), lon = number(input.opt("lon"));
                checkCoordinate(lat, lon);
                return new JSONObject().put("lat", lat).put("lon", lon)
                        .put("label", checkedText(input.opt("label"), 1024, "Invalid place response."))
                        .put("attributions", checkedAttributions(input.opt("attributions")));
            }
            if (!"route".equals(type)) throw new JSONException("Unknown response");
            JSONArray points = checkedPoints(input.getJSONArray("points"), 2, RouteEngine.MAX_POINTS);
            double distance = number(input.opt("distanceMeters"));
            double duration = number(input.opt("durationSeconds"));
            if (distance < 1 || duration < 0 || distance > 100_000_000 || duration > 100_000_000) {
                throw new UserError("No usable Google route was found. Choose different points.");
            }
            double[][] route = new double[points.length()][2];
            for (int i = 0; i < route.length; i++) {
                route[i][0] = points.getJSONArray(i).getDouble(0);
                route[i][1] = points.getJSONArray(i).getDouble(1);
            }
            if (new RouteEngine(route, 5, "once").current().totalMeters < 1) {
                throw new UserError("These points resolve to the same position. Choose another destination.");
            }
            return new JSONObject().put("points", points).put("distanceMeters", distance)
                    .put("durationSeconds", duration);
        } catch (JSONException | IllegalArgumentException invalid) {
            throw new UserError("Google returned an unreadable route or place. Try different points or search again.");
        }
    }

    private static JSONArray checkedAttributions(Object value) throws JSONException, UserError {
        JSONArray output = new JSONArray();
        if (value == null) return output;
        if (!(value instanceof JSONArray) || ((JSONArray) value).length() > 32) {
            throw new UserError("Google returned invalid place attribution. Search again.");
        }
        JSONArray input = (JSONArray) value;
        for (int i = 0; i < input.length(); i++) {
            JSONObject attribution = input.getJSONObject(i);
            String provider = checkedText(attribution.opt("provider"), 256, "Invalid place attribution.");
            String link = "";
            if (attribution.has("providerUri")) {
                Object raw = attribution.opt("providerUri");
                if (!(raw instanceof String)) throw new UserError("Invalid place attribution.");
                if (!((String) raw).isEmpty()) {
                    link = checkedText(raw, 2048, "Invalid place attribution.");
                    URI uri = URI.create(link);
                    if (!("https".equals(uri.getScheme()) || "http".equals(uri.getScheme()))
                            || uri.getHost() == null || uri.getUserInfo() != null) {
                        throw new UserError("Invalid place attribution.");
                    }
                }
            }
            output.put(new JSONObject().put("provider", provider).put("providerUri", link));
        }
        return output;
    }

    private static JSONArray checkedPoints(JSONArray input, int minimum, int maximum)
            throws JSONException, UserError {
        if (input.length() < minimum || input.length() > maximum) throw new UserError("This route has too many or too few points. Choose a shorter journey.");
        JSONArray output = new JSONArray();
        for (int i = 0; i < input.length(); i++) {
            JSONArray point = input.getJSONArray(i);
            if (point.length() != 2) throw new UserError("Invalid map coordinate.");
            double lat = number(point.opt(0)), lon = number(point.opt(1));
            checkCoordinate(lat, lon);
            output.put(new JSONArray().put(lat).put(lon));
        }
        return output;
    }

    private static double number(Object value) throws UserError {
        if (!(value instanceof Number)) throw new UserError("Google returned invalid coordinate or route data.");
        double result = ((Number) value).doubleValue();
        if (Double.isNaN(result) || Double.isInfinite(result)) throw new UserError("Google returned invalid coordinate or route data.");
        return result;
    }

    private static void checkCoordinate(double lat, double lon) throws UserError {
        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new UserError("Invalid map coordinate.");
    }

    private static String checkedText(Object value, int maximum, String error) throws UserError {
        if (!(value instanceof String)) throw new UserError(error);
        String text = ((String) value).trim();
        if (text.isEmpty() || text.length() > maximum || text.matches("(?s).*[\\x00-\\x1f\\x7f].*")) throw new UserError(error);
        return text;
    }

    private static String httpError(int status, String body) {
        String code = "";
        try { code = new JSONObject(body).optJSONObject("error").optString("code"); }
        catch (Exception ignored) { }
        if ("NO_ROUTE".equals(code)) return "Google found no route for these points and travel mode. Move a point or try another mode.";
        if (status == 401) return "App verification failed. Reopen the app and try again.";
        if (status == 403) return "This app isn't allowed to use the Google proxy. Check Google setup.";
        if (status == 429) return "Too many map requests. Wait a moment before trying again.";
        if (status == 504) return "Google took too long to respond. Try again when your connection is stable.";
        if (status == 503) return "The Google maps service is not ready. Check its configuration or try again later.";
        if (status == 404) return "That place or route is unavailable. Search again or choose different points.";
        if (status == 400 || status == 413) return "Google could not use these points or search terms. Choose a shorter route or search again.";
        return "Google maps is unavailable right now. Please try again later.";
    }

    private static JSONObject response(JSONObject request, Object data, String error) {
        JSONObject result = new JSONObject();
        try {
            result.put("id", request.optString("id"));
            result.put("type", request.optString("type"));
            result.put("ok", error == null);
            if (data != null) result.put("data", data);
            if (error != null) result.put("error", error);
        } catch (JSONException ignored) { }
        return result;
    }

    void close() {
        synchronized (this) {
            if (closed) return;
            closed = true;
            for (Lane lane : lanes.values()) {
                cancelLane(lane);
                lane.executor.shutdownNow();
            }
            deadlines.shutdownNow();
        }
    }

    private static Thread daemon(Runnable runnable, String name) {
        Thread thread = new Thread(runnable, name);
        thread.setDaemon(true);
        return thread;
    }

    private static final class Lane {
        final String type;
        final ThreadPoolExecutor executor;
        Job current;
        Lane(String type) {
            this.type = type;
            executor = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS,
                    new ArrayBlockingQueue<>(1), runnable -> daemon(runnable, "Google-" + type));
        }
    }

    private static final class Job {
        final JSONObject request;
        final Callback callback;
        final Lane lane;
        final Cancellation cancellation;
        volatile Future<?> future;
        volatile ScheduledFuture<?> deadline;
        Job(JSONObject request, Callback callback, Lane lane, long timeoutMillis) {
            this.request = request;
            this.callback = callback;
            this.lane = lane;
            cancellation = new Cancellation(timeoutMillis);
        }
        void cancel() {
            cancellation.cancel();
            if (future != null) future.cancel(true);
            if (deadline != null) deadline.cancel(false);
        }
    }

    static final class Cancellation {
        private final long deadlineNanos;
        private volatile boolean cancelled;
        private Runnable abort;
        Cancellation(long timeoutMillis) { deadlineNanos = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMillis); }
        boolean isCancelled() { return cancelled; }
        void check() throws SocketTimeoutException {
            if (cancelled || Thread.currentThread().isInterrupted()) throw new CancellationException();
            remainingMillis();
        }
        long remainingMillis() throws SocketTimeoutException {
            long remaining = TimeUnit.NANOSECONDS.toMillis(deadlineNanos - System.nanoTime());
            if (remaining <= 0) throw new SocketTimeoutException();
            return remaining;
        }
        void onCancel(Runnable action) {
            boolean runNow;
            synchronized (this) { runNow = cancelled; if (!runNow) abort = action; }
            if (runNow) action.run();
        }
        void clearAbort() { synchronized (this) { abort = null; } }
        void cancel() {
            Runnable action;
            synchronized (this) { cancelled = true; action = abort; abort = null; }
            if (action != null) try { action.run(); } catch (RuntimeException ignored) { }
        }
    }

    static final class HttpResult {
        final int status;
        final String body;
        HttpResult(int status, String body) { this.status = status; this.body = body; }
    }

    static final class HttpTransport implements Transport {
        @Override public HttpResult post(URL endpoint, String body, String appCheckToken,
                Cancellation cancellation) throws Exception {
            cancellation.check();
            HttpURLConnection connection = (HttpURLConnection) endpoint.openConnection();
            cancellation.onCancel(connection::disconnect);
            try {
                connection.setInstanceFollowRedirects(false);
                connection.setUseCaches(false);
                connection.setRequestMethod("POST");
                connection.setConnectTimeout((int) Math.min(8000, cancellation.remainingMillis()));
                connection.setReadTimeout((int) Math.min(12000, cancellation.remainingMillis()));
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Cache-Control", "no-store");
                connection.setRequestProperty("X-Firebase-AppCheck", appCheckToken);
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
                cancellation.check();
                connection.setReadTimeout((int) Math.min(12000, cancellation.remainingMillis()));
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) return new HttpResult(status, "{}");
                ByteArrayOutputStream response = new ByteArrayOutputStream();
                try (InputStream input = stream) {
                    byte[] buffer = new byte[8192];
                    while (true) {
                        cancellation.check();
                        connection.setReadTimeout((int) Math.min(12000, cancellation.remainingMillis()));
                        int count = input.read(buffer);
                        if (count == -1) break;
                        if (response.size() + count > MAX_RESPONSE_BYTES) throw new UserError("The Google response was too large. Choose a shorter route.");
                        response.write(buffer, 0, count);
                    }
                }
                return new HttpResult(status, response.toString(StandardCharsets.UTF_8.name()));
            } finally {
                cancellation.clearAbort();
                connection.disconnect();
            }
        }
    }

    static final class UserError extends Exception {
        UserError(String message) { super(message); }
    }
}
