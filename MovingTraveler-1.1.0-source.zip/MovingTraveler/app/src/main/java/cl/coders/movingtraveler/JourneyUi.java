// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/**
 * Native presentation layer. The activity owns Google Maps, permission flows, route planning,
 * haptics, and service commands; rendering this view never invokes a Listener method.
 */
public final class JourneyUi {
    public interface Listener {
        void onPoint(boolean destination);
        void onPrimary();
        void onStopPlayback();
        void onSettings();
        void onOptions();
        void onSpeed(double speedKmh);
        /** Mode is "walk", "cycle", or "drive". */
        void onPreset(String mode, double speedKmh);
    }

    private static final int PAPER = Color.rgb(249, 250, 246);
    private static final int WHITE = Color.WHITE;
    private static final int INK = Color.rgb(31, 54, 44);
    private static final int MUTED = Color.rgb(100, 117, 94);
    private static final int TEAL = Color.rgb(28, 91, 71);
    private static final int MINT = Color.rgb(231, 240, 222);
    private static final int LINE = Color.rgb(224, 232, 216);
    private static final int PALE = Color.rgb(239, 244, 232);
    private static final int WARNING = Color.rgb(121, 88, 36);
    private static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    private final Activity activity;
    private final Listener listener;
    private final AdaptiveRoot rootView;
    /** Add the activity-owned MapView here; hint overlays live outside this container. */
    public final FrameLayout mapContainer;
    private final TextView mapHint;
    private final LinearLayout header;
    private final FrameLayout mapRegion;
    private final LinearLayout panel;
    private final LinearLayout form;
    private final LinearLayout actions;
    private final LinearLayout primaryRow;
    private final ScrollView formScroll;
    private final TextView panelTitle;
    private final TextView statusPill;
    private final PointRow fromRow;
    private final PointRow toRow;
    private final View pointDivider;
    private final LinearLayout routeDetails;
    private final Button routeOptions;
    private final TextView routeSummary;
    private final LinearLayout speedControls;
    private final LinearLayout presets;
    private final Button walk;
    private final Button cycle;
    private final Button drive;
    private final EditText speedEditor;
    private final SeekBar speedSlider;
    private final TextView messageView;
    private final TextView attributionsView;
    private final Button primary;
    private final Button stop;
    private boolean rendering;
    private boolean sliderDragging;
    private boolean editorDirty;
    private double renderedSpeed = 5;
    private double visibleSpeed = 5;
    private String lastMessage = "";

    public JourneyUi(Activity activity, Listener listener) {
        if (activity == null || listener == null) throw new IllegalArgumentException("Activity and Listener are required");
        this.activity = activity;
        this.listener = listener;

        header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(8), dp(14), dp(8));
        header.setMinimumHeight(dp(64));
        TextView brand = text("", 18, INK, true);
        brand.setBackground(shape(TEAL, 12, 0));
        brand.setCompoundDrawablesWithIntrinsicBounds(new MarkDrawable(MarkDrawable.NAVIGATION, WHITE, dp(24)), null, null, null);
        brand.setPadding(dp(7), dp(7), dp(7), dp(7));
        brand.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        header.addView(brand, new LinearLayout.LayoutParams(dp(38), dp(38)));
        TextView appTitle = text(activity.getString(R.string.app_name), 18, INK, true);
        appTitle.setMaxLines(2);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        titleParams.leftMargin = dp(11);
        titleParams.rightMargin = dp(8);
        header.addView(appTitle, titleParams);
        Button settings = button("", PALE, INK, false);
        settings.setPadding(dp(12), dp(12), dp(12), dp(12));
        settings.setCompoundDrawablesWithIntrinsicBounds(new MarkDrawable(MarkDrawable.SETTINGS, INK, dp(24)), null, null, null);
        settings.setContentDescription("Settings, setup, and privacy");
        settings.setOnClickListener(v -> listener.onSettings());
        header.addView(settings, new LinearLayout.LayoutParams(dp(48), dp(48)));

        mapRegion = new FrameLayout(activity);
        mapRegion.setBackgroundColor(Color.rgb(233, 239, 228));
        mapContainer = new FrameLayout(activity);
        mapContainer.setId(View.generateViewId());
        mapRegion.addView(mapContainer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mapHint = text("Tap the map to choose a starting point", 12, TEAL, true);
        mapHint.setPadding(dp(13), dp(11), dp(13), dp(11));
        mapHint.setMaxLines(2);
        mapHint.setGravity(Gravity.CENTER_VERTICAL);
        mapHint.setBackground(shape(Color.argb(245, 255, 255, 251), 14, LINE));
        mapHint.setElevation(dp(2));
        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        hintParams.setMargins(dp(16), dp(14), dp(16), 0);
        mapRegion.addView(mapHint, hintParams);

        panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBackground = shape(PAPER, 0, 0);
        panelBackground.setCornerRadii(new float[]{dp(25), dp(25), dp(25), dp(25), 0, 0, 0, 0});
        panel.setBackground(panelBackground);
        panel.setElevation(dp(5));
        panel.setClipToOutline(true);

        form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18), dp(16), dp(18), 0);
        formScroll = new ScrollView(activity);
        formScroll.setFillViewport(false);
        formScroll.setVerticalScrollBarEnabled(false);
        formScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        formScroll.setClipToPadding(false);
        formScroll.addView(form, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(formScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        LinearLayout heading = horizontal();
        heading.setGravity(Gravity.CENTER_VERTICAL);
        panelTitle = text("Plan a journey", 20, INK, true);
        heading.addView(panelTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        statusPill = text("Planning", 11, MUTED, true);
        statusPill.setPadding(dp(10), dp(7), dp(10), dp(7));
        statusPill.setBackground(shape(PALE, 18, 0));
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pillParams.leftMargin = dp(10);
        heading.addView(statusPill, pillParams);
        form.addView(heading, marginBottom(dp(10)));

        LinearLayout points = new LinearLayout(activity);
        points.setOrientation(LinearLayout.VERTICAL);
        points.setBackground(shape(WHITE, 16, LINE));
        points.setClipToOutline(true);
        fromRow = new PointRow(false);
        toRow = new PointRow(true);
        points.addView(fromRow, matchWrap());
        pointDivider = new View(activity);
        pointDivider.setBackgroundColor(LINE);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dividerParams.leftMargin = dp(43);
        dividerParams.rightMargin = dp(14);
        points.addView(pointDivider, dividerParams);
        points.addView(toRow, matchWrap());
        form.addView(points, matchWrap());

        routeDetails = horizontal();
        routeDetails.setGravity(Gravity.CENTER_VERTICAL);
        routeOptions = button("Road · One way", Color.TRANSPARENT, MUTED, false);
        routeOptions.setTextSize(12);
        routeOptions.setPadding(0, dp(4), dp(8), dp(4));
        routeOptions.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        routeOptions.setCompoundDrawablePadding(dp(5));
        routeOptions.setCompoundDrawablesWithIntrinsicBounds(null, null, new MarkDrawable(MarkDrawable.DOWN, MUTED, dp(16)), null);
        routeOptions.setOnClickListener(v -> listener.onOptions());
        routeDetails.addView(routeOptions, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        routeSummary = text("Choose two points", 12, MUTED, false);
        routeSummary.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        routeSummary.setMaxLines(2);
        routeSummary.setPadding(dp(10), dp(8), 0, dp(8));
        routeSummary.setMinimumHeight(dp(48));
        routeDetails.addView(routeSummary, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        speedControls = new LinearLayout(activity);
        speedControls.setOrientation(LinearLayout.VERTICAL);
        LinearLayout paceHeading = horizontal();
        paceHeading.setGravity(Gravity.CENTER_VERTICAL);
        TextView pace = text("Travel pace", 13, INK, true);
        paceHeading.addView(pace, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        speedEditor = new EditText(activity);
        speedEditor.setId(View.generateViewId());
        speedEditor.setTextSize(21);
        speedEditor.setTypeface(MEDIUM);
        speedEditor.setTextColor(TEAL);
        speedEditor.setSingleLine(true);
        speedEditor.setSelectAllOnFocus(true);
        speedEditor.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        speedEditor.setHorizontallyScrolling(false);
        speedEditor.setImeOptions(EditorInfo.IME_ACTION_DONE);
        speedEditor.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        speedEditor.setPadding(dp(4), 0, dp(4), 0);
        speedEditor.setMinimumHeight(dp(48));
        speedEditor.setMinHeight(dp(48));
        speedEditor.setBackgroundTintList(ColorStateList.valueOf(LINE));
        speedEditor.setContentDescription("Speed in kilometers per hour, from 0.5 to 200");
        if (Build.VERSION.SDK_INT >= 26) speedEditor.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        int editorWidth = dp(72 * Math.max(1, activity.getResources().getConfiguration().fontScale * .8f));
        paceHeading.addView(speedEditor, new LinearLayout.LayoutParams(editorWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView speedUnit = text("km/h", 11, MUTED, false);
        speedUnit.setPadding(dp(5), 0, 0, 0);
        paceHeading.addView(speedUnit, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        speedControls.addView(paceHeading, matchWrap());

        presets = horizontal();
        walk = preset("Walk", "walk", 5);
        cycle = preset("Cycle", "cycle", 15);
        drive = preset("Drive", "drive", 50);
        presets.addView(walk, weighted(0));
        presets.addView(cycle, weighted(dp(7)));
        presets.addView(drive, weighted(dp(7)));

        speedSlider = new SeekBar(activity);
        speedSlider.setId(View.generateViewId());
        speedSlider.setMax(399);
        speedSlider.setProgressTintList(ColorStateList.valueOf(TEAL));
        speedSlider.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
        speedSlider.setThumbTintList(ColorStateList.valueOf(TEAL));
        speedSlider.setSplitTrack(false);
        speedSlider.setPadding(dp(8), 0, dp(8), 0);
        speedSlider.setMinimumHeight(dp(48));
        speedSlider.setContentDescription("Adjust travel speed, 0.5 to 200 kilometers per hour");
        speedControls.addView(speedSlider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        speedControls.addView(presets, matchWrap());
        form.addView(speedControls, matchWrap());
        form.addView(routeDetails, matchWrap());

        messageView = text("", 12, WARNING, false);
        messageView.setPadding(dp(12), dp(10), dp(12), dp(10));
        messageView.setBackground(shape(Color.rgb(251, 245, 232), 12, Color.rgb(234, 222, 194)));
        messageView.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        messageView.setVisibility(View.GONE);
        LinearLayout.LayoutParams messageParams = matchWrap();
        messageParams.topMargin = dp(8);
        form.addView(messageView, messageParams);
        attributionsView = text("", 12, MUTED, false);
        attributionsView.setPadding(dp(2), dp(8), dp(2), dp(6));
        attributionsView.setLinkTextColor(TEAL);
        attributionsView.setMovementMethod(LinkMovementMethod.getInstance());
        attributionsView.setLinksClickable(true);
        attributionsView.setVisibility(View.GONE);
        form.addView(attributionsView, matchWrap());

        actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setPadding(dp(18), dp(10), dp(18), dp(10));
        actions.setBackgroundColor(PAPER);
        primaryRow = horizontal();
        primaryRow.setGravity(Gravity.CENTER_VERTICAL);
        primary = button("Start journey", TEAL, WHITE, true);
        primary.setMinimumHeight(dp(54));
        primary.setOnClickListener(v -> {
            if (speedEditor.hasFocus() && !commitEditor()) return;
            clearSpeedFocus();
            listener.onPrimary();
        });
        primaryRow.addView(primary, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        stop = button("Stop", MINT, TEAL, true);
        stop.setMinimumHeight(dp(54));
        stop.setVisibility(View.GONE);
        stop.setOnClickListener(v -> {
            editorDirty = false;
            speedEditor.setError(null);
            clearSpeedFocus();
            listener.onStopPlayback();
        });
        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(dp(94), ViewGroup.LayoutParams.WRAP_CONTENT);
        stopParams.leftMargin = dp(9);
        primaryRow.addView(stop, stopParams);
        actions.addView(primaryRow, matchWrap());
        panel.addView(actions, matchWrap());

        rootView = new AdaptiveRoot(activity);
        rootView.setBackgroundColor(PAPER);
        rootView.setFocusableInTouchMode(true);
        rootView.addView(header);
        rootView.addView(mapRegion);
        rootView.addView(panel);
        installSpeedListeners();
        render("idle", "", "", "", 5, 0, 0, false, false, false, "walk", "once", "road", false);
        rootView.requestFocus();
    }

    public View root() { return rootView; }

    /** This view never consumes map gestures; an empty hint hides it. */
    public void setMapHint(String hint) {
        String value = safe(hint);
        setText(mapHint, value);
        mapHint.setVisibility(value.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /** Provider attribution is part of the scrollable form and preserves the supplied link spans. */
    public void setAttributions(CharSequence text) {
        boolean empty = text == null || text.toString().trim().isEmpty();
        attributionsView.setText(empty ? "" : text);
        attributionsView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    /** Called on the main thread by the activity whenever application state changes. */
    public void render(String status, String message, String startLabel, String endLabel,
                       double speedKmh, double distanceMeters, double remainingSeconds,
                       boolean active, boolean pending, boolean canStart,
                       String travelMode, String playbackMode, String routeKind, boolean routeLoading) {
        rendering = true;
        try {
            String state = safe(status);
            String mode = safe(playbackMode);
            boolean stationary = "static".equals(mode);
            boolean arrived = "arrived".equals(state);
            boolean paused = "paused".equals(state);
            boolean locked = active || pending;
            String profile = normalizeTravelMode(travelMode);
            setText(panelTitle, stationary ? "Hold a location" : active ? "Your journey" : "Plan a journey");
            setText(statusPill, pending ? "Preparing" : routeLoading ? "Routing" : "route_error".equals(state) ? "Retry needed" : arrived ? "Arrived"
                    : paused ? "Paused" : active ? stationary ? "Holding" : "Moving"
                    : canStart ? "Route ready" : "Planning");
            fromRow.render(startLabel, !locked);
            toRow.render(endLabel, !locked);
            toRow.setVisibility(stationary ? View.GONE : View.VISIBLE);
            pointDivider.setVisibility(stationary ? View.GONE : View.VISIBLE);
            String routeLabel = "direct".equals(routeKind) ? "Direct line"
                    : "walk".equals(profile) ? "Walking route"
                    : "cycle".equals(profile) ? "Cycle route" : "Driving route";
            String playbackLabel = "pingpong".equals(mode) ? "Return trip" : "One way";
            setText(routeOptions, stationary ? "Stationary" : routeLabel + " · " + playbackLabel);
            routeOptions.setContentDescription("Route options. " + (stationary ? "Hold one location" : routeLabel + ". " + playbackLabel));
            routeOptions.setEnabled(!locked);
            routeOptions.setVisibility(active ? View.GONE : View.VISIBLE);
            routeSummary.setGravity((active ? Gravity.START : Gravity.END) | Gravity.CENTER_VERTICAL);
            routeSummary.setPadding(active ? 0 : dp(10), dp(8), 0, dp(8));
            String summary;
            if (stationary) summary = active ? "Held until you tap Stop" : "Hold your chosen point";
            else if (routeLoading) summary = "Finding a route…";
            else if (arrived) summary = "Destination held until Stop";
            else if (distanceMeters > 0 && Double.isFinite(distanceMeters)) {
                summary = formatDistance(distanceMeters);
                if (remainingSeconds >= 0 && Double.isFinite(remainingSeconds)) summary += " · " + formatDuration(remainingSeconds) + (active ? " remaining" : "");
                if (active && "pingpong".equals(mode)) summary += " · Return trip";
            } else summary = "Choose two points";
            setText(routeSummary, summary);
            speedControls.setVisibility(stationary ? View.GONE : View.VISIBLE);
            presets.setVisibility(active ? View.GONE : View.VISIBLE);
            walk.setEnabled(!locked);
            cycle.setEnabled(!locked);
            drive.setEnabled(!locked);
            updatePreset(walk, "walk".equals(profile));
            updatePreset(cycle, "cycle".equals(profile));
            updatePreset(drive, "drive".equals(profile));
            renderedSpeed = normalizeSpeed(speedKmh);
            if ((!speedEditor.hasFocus() || !editorDirty) && !sliderDragging) setSpeedVisual(renderedSpeed);
            speedSlider.setEnabled(!pending && !stationary);
            speedEditor.setEnabled(!pending && !stationary);
            showMessage(message);

            boolean primaryVisible = !active || (!stationary && !arrived);
            primary.setVisibility(primaryVisible ? View.VISIBLE : View.GONE);
            stop.setVisibility(active ? View.VISIBLE : View.GONE);
            boolean primaryEnabled = !pending && (active || (canStart && !routeLoading));
            primary.setEnabled(primaryEnabled);
            primary.setAlpha(primaryEnabled ? 1 : .48f);
            stop.setEnabled(!pending);
            stop.setAlpha(pending ? .48f : 1);
            setText(primary, pending ? "Please wait…" : active ? paused ? "Resume" : "Pause"
                    : routeLoading ? "Finding route…" : "route_error".equals(state) ? "Retry route" : stationary ? "Start location" : "Start journey");
            primary.setContentDescription(primary.getText());
            LinearLayout.LayoutParams stopParams = (LinearLayout.LayoutParams) stop.getLayoutParams();
            int stopWidth = primaryVisible ? dp(94) : 0;
            float stopWeight = primaryVisible ? 0 : 1;
            int stopMargin = primaryVisible ? dp(9) : 0;
            if (stopParams.width != stopWidth || stopParams.weight != stopWeight || stopParams.leftMargin != stopMargin) {
                stopParams.width = stopWidth;
                stopParams.weight = stopWeight;
                stopParams.leftMargin = stopMargin;
                stop.setLayoutParams(stopParams);
            }
        } finally {
            rendering = false;
        }
    }

    /** For a transient validation or routing message without reconstructing the UI. */
    public void showMessage(String message) {
        String value = safe(message);
        if (lastMessage.equals(value)) return;
        lastMessage = value;
        setText(messageView, value);
        messageView.setVisibility(value.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void installSpeedListeners() {
        speedSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || rendering) return;
                visibleSpeed = .5 + progress * .5;
                if (!speedEditor.hasFocus()) setText(speedEditor, formatSpeed(visibleSpeed));
                seekBar.setContentDescription("Speed " + formatSpeed(visibleSpeed) + " kilometers per hour");
                // Discrete keyboard/TalkBack changes have no touch-release event.
                if (!sliderDragging) listener.onSpeed(visibleSpeed);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                sliderDragging = true;
                editorDirty = false;
                speedEditor.setError(null);
                clearSpeedFocus();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                sliderDragging = false;
                visibleSpeed = .5 + seekBar.getProgress() * .5;
                setSpeedVisual(visibleSpeed);
                listener.onSpeed(visibleSpeed);
            }
        });
        speedEditor.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!rendering && speedEditor.hasFocus()) editorDirty = true;
            }
            @Override public void afterTextChanged(android.text.Editable editable) { }
        });
        speedEditor.setOnFocusChangeListener((v, focused) -> {
            if (focused) editorDirty = false;
            else if (!rendering && !commitEditor()) {
                editorDirty = false;
                setSpeedVisual(renderedSpeed);
                speedEditor.setError(null);
                showMessage("Speed was reset. Enter a value from 0.5 to 200 km/h.");
            }
        });
        speedEditor.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP)) {
                if (commitEditor()) clearSpeedFocus();
                return true;
            }
            return false;
        });
    }

    private boolean commitEditor() {
        if (!editorDirty) return true;
        String value = speedEditor.getText().toString().trim().replace(',', '.');
        double speed;
        try { speed = Double.parseDouble(value); }
        catch (NumberFormatException ignored) { speed = Double.NaN; }
        if (!Double.isFinite(speed) || speed < .5 || speed > 200) {
            speedEditor.setError("Enter a speed from 0.5 to 200 km/h");
            return false;
        }
        speed = normalizeSpeed(speed);
        editorDirty = false;
        speedEditor.setError(null);
        setSpeedVisual(speed);
        if (Math.abs(speed - renderedSpeed) > .001) listener.onSpeed(speed);
        return true;
    }

    private void clearSpeedFocus() {
        if (!speedEditor.hasFocus()) return;
        speedEditor.clearFocus();
        rootView.requestFocus();
        InputMethodManager input = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (input != null) input.hideSoftInputFromWindow(speedEditor.getWindowToken(), 0);
    }

    private void setSpeedVisual(double value) {
        visibleSpeed = normalizeSpeed(value);
        boolean wasRendering = rendering;
        rendering = true;
        try {
            setText(speedEditor, formatSpeed(visibleSpeed));
            speedSlider.setProgress((int) Math.round((visibleSpeed - .5) * 2));
        } finally { rendering = wasRendering; }
    }

    private Button preset(String label, String mode, double speed) {
        Button result = button(label, WHITE, MUTED, true);
        result.setContentDescription(label + ", " + formatSpeed(speed) + " kilometers per hour");
        result.setTag(Boolean.FALSE);
        result.setOnClickListener(v -> {
            editorDirty = false;
            speedEditor.setError(null);
            clearSpeedFocus();
            setSpeedVisual(speed);
            listener.onPreset(mode, speed);
        });
        return result;
    }

    private void updatePreset(Button button, boolean selected) {
        if (Boolean.valueOf(selected).equals(button.getTag())) return;
        button.setTag(selected);
        button.setSelected(selected);
        button.setTextColor(selected ? TEAL : MUTED);
        button.setBackground(ripple(selected ? MINT : WHITE, 12, selected ? Color.rgb(136, 162, 120) : LINE));
    }

    private final class PointRow extends LinearLayout {
        final boolean destination;
        final TextView value;
        final TextView chevron;

        PointRow(boolean destination) {
            super(activity);
            this.destination = destination;
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(13), dp(9), dp(12), dp(9));
            setMinimumHeight(dp(56));
            setBackground(ripple(Color.TRANSPARENT, 0, 0));
            setFocusable(true);
            setClickable(true);
            setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
            setAccessibilityDelegate(new View.AccessibilityDelegate() {
                @Override public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                    super.onInitializeAccessibilityNodeInfo(host, info);
                    info.setClassName(Button.class.getName());
                }
            });
            TextView pointMark = text("", 12, TEAL, false);
            pointMark.setCompoundDrawablesWithIntrinsicBounds(new MarkDrawable(destination ? MarkDrawable.DESTINATION : MarkDrawable.START, TEAL, dp(19)), null, null, null);
            pointMark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            addView(pointMark, new LinearLayout.LayoutParams(dp(27), dp(24)));
            LinearLayout copy = new LinearLayout(activity);
            copy.setOrientation(VERTICAL);
            copy.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
            TextView label = text(destination ? "TO" : "FROM", 10, MUTED, true);
            label.setLetterSpacing(.08f);
            copy.addView(label, matchWrap());
            value = text(destination ? "Choose destination" : "Choose starting point", 14, INK, true);
            value.setMaxLines(2);
            value.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams valueParams = matchWrap();
            valueParams.topMargin = dp(4);
            copy.addView(value, valueParams);
            addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            chevron = text("", 12, MUTED, false);
            chevron.setCompoundDrawablesWithIntrinsicBounds(new MarkDrawable(MarkDrawable.RIGHT, MUTED, dp(17)), null, null, null);
            chevron.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(dp(18), dp(24));
            chevronParams.leftMargin = dp(8);
            addView(chevron, chevronParams);
            setOnClickListener(v -> listener.onPoint(destination));
        }

        void render(String text, boolean enabled) {
            String label = safe(text);
            if (label.isEmpty()) label = destination ? "Choose destination" : "Choose starting point";
            setText(value, label);
            setEnabled(enabled);
            chevron.setVisibility(enabled ? VISIBLE : INVISIBLE);
            setContentDescription((destination ? "Destination. " : "Starting point. ") + label
                    + (enabled ? ". Select a place, coordinates, or a point on the map." : ""));
        }
    }

    /** Gives the map real layout space. Only the form scrolls; primary actions always stay visible. */
    private final class AdaptiveRoot extends ViewGroup {
        private int contentLeft, contentTop, contentWidth, availableHeight, headerHeight, panelSize;
        private boolean landscape;

        AdaptiveRoot(Context context) { super(context); }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int height = MeasureSpec.getSize(heightMeasureSpec);
            contentLeft = getPaddingLeft();
            contentTop = getPaddingTop();
            contentWidth = Math.max(0, width - getPaddingLeft() - getPaddingRight());
            int innerHeight = Math.max(0, height - getPaddingTop() - getPaddingBottom());
            header.measure(MeasureSpec.makeMeasureSpec(contentWidth, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.min(dp(104), innerHeight), MeasureSpec.AT_MOST));
            headerHeight = header.getMeasuredHeight();
            availableHeight = Math.max(0, innerHeight - headerHeight);
            landscape = contentWidth >= dp(600) && contentWidth > innerHeight * 1.35f;
            if (landscape) {
                panelSize = Math.max(dp(300), Math.round(contentWidth * .44f));
                panelSize = Math.min(panelSize, contentWidth);
                panel.measure(MeasureSpec.makeMeasureSpec(panelSize, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(availableHeight, MeasureSpec.EXACTLY));
                mapRegion.measure(MeasureSpec.makeMeasureSpec(Math.max(0, contentWidth - panelSize), MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(availableHeight, MeasureSpec.EXACTLY));
            } else {
                form.measure(MeasureSpec.makeMeasureSpec(contentWidth, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
                actions.measure(MeasureSpec.makeMeasureSpec(contentWidth, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
                int desired = form.getMeasuredHeight() + actions.getMeasuredHeight();
                int cap = Math.round(availableHeight * .55f);
                // When the IME is open, keep the primary row usable; the map can temporarily shrink.
                cap = Math.min(availableHeight, Math.max(actions.getMeasuredHeight() + dp(48), cap));
                panelSize = Math.min(desired, cap);
                panel.measure(MeasureSpec.makeMeasureSpec(contentWidth, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(Math.max(0, panelSize), MeasureSpec.EXACTLY));
                mapRegion.measure(MeasureSpec.makeMeasureSpec(contentWidth, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(Math.max(0, availableHeight - panelSize), MeasureSpec.EXACTLY));
            }
            setMeasuredDimension(width, height);
        }

        @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
            header.layout(contentLeft, contentTop, contentLeft + contentWidth, contentTop + headerHeight);
            int bodyTop = contentTop + headerHeight;
            if (landscape) {
                int panelLeft = contentLeft + contentWidth - panelSize;
                mapRegion.layout(contentLeft, bodyTop, panelLeft, bodyTop + availableHeight);
                panel.layout(panelLeft, bodyTop, contentLeft + contentWidth, bodyTop + availableHeight);
            } else {
                int panelTop = bodyTop + availableHeight - panelSize;
                mapRegion.layout(contentLeft, bodyTop, contentLeft + contentWidth, panelTop);
                panel.layout(contentLeft, panelTop, contentLeft + contentWidth, bodyTop + availableHeight);
            }
        }

        @Override protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
            return new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private Button button(String label, int background, int foreground, boolean bold) {
        Button result = new Button(activity);
        result.setText(label);
        result.setAllCaps(false);
        result.setTextSize(14);
        result.setTextColor(foreground);
        result.setTypeface(bold ? MEDIUM : Typeface.DEFAULT);
        result.setGravity(Gravity.CENTER);
        result.setPadding(dp(12), dp(8), dp(12), dp(8));
        result.setMinimumHeight(dp(48));
        result.setMinHeight(dp(48));
        result.setMinimumWidth(0);
        result.setMinWidth(0);
        result.setMaxLines(2);
        result.setStateListAnimator(null);
        result.setBackground(ripple(background, 13, background == WHITE ? LINE : 0));
        result.setHapticFeedbackEnabled(true);
        return result;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView result = new TextView(activity);
        result.setText(value);
        result.setTextSize(sp);
        result.setTextColor(color);
        result.setTypeface(bold ? MEDIUM : Typeface.DEFAULT);
        result.setIncludeFontPadding(false);
        return result;
    }

    private LinearLayout horizontal() {
        LinearLayout result = new LinearLayout(activity);
        result.setOrientation(LinearLayout.HORIZONTAL);
        return result;
    }

    private GradientDrawable shape(int fill, float cornerDp, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(cornerDp));
        if (stroke != 0) drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private Drawable ripple(int fill, float cornerDp, int stroke) {
        return new RippleDrawable(ColorStateList.valueOf(Color.argb(25, 28, 91, 71)),
                shape(fill, cornerDp, stroke), shape(WHITE, cornerDp, 0));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams marginBottom(int bottom) {
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = bottom;
        return params;
    }

    private LinearLayout.LayoutParams weighted(int left) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        params.leftMargin = left;
        return params;
    }

    private int dp(float value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private static String safe(String value) { return value == null ? "" : value.trim(); }
    private static void setText(TextView view, String value) {
        if (!TextUtils.equals(view.getText(), value)) view.setText(value);
    }
    private static double normalizeSpeed(double speed) {
        if (!Double.isFinite(speed)) return 5;
        return Math.round(Math.max(.5, Math.min(200, speed)) * 2) / 2.0;
    }
    private static String normalizeTravelMode(String mode) {
        if ("cycle".equals(mode) || "bicycling".equals(mode) || "cycling".equals(mode)) return "cycle";
        if ("drive".equals(mode) || "driving".equals(mode)) return "drive";
        return "walk";
    }
    private static String formatSpeed(double speed) {
        return speed == Math.rint(speed) ? String.format(Locale.US, "%.0f", speed) : String.format(Locale.US, "%.1f", speed);
    }
    private static String formatDistance(double meters) {
        if (meters < 1000) return String.format(Locale.US, "%.0f m", meters);
        return String.format(Locale.US, meters < 10000 ? "%.1f km" : "%.0f km", meters / 1000);
    }
    private static String formatDuration(double seconds) {
        long minutes = Math.max(0, (long) Math.ceil(seconds / 60));
        if (minutes == 0) return "<1 min";
        if (minutes < 60) return minutes + " min";
        if (minutes % 60 == 0) return minutes / 60 + " hr";
        return minutes / 60 + " hr " + minutes % 60 + " min";
    }

    /** Small bundled native line icons; no remote assets or icon-font dependency. */
    private static final class MarkDrawable extends Drawable {
        static final int NAVIGATION = 0, SETTINGS = 1, START = 2, DESTINATION = 3, RIGHT = 4, DOWN = 5;
        private final int type, size;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        MarkDrawable(int type, int color, int size) {
            this.type = type;
            this.size = size;
            paint.setColor(color);
            paint.setStrokeWidth(1.65f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override public void draw(Canvas canvas) {
            int save = canvas.save();
            canvas.translate(getBounds().left, getBounds().top);
            canvas.scale(getBounds().width() / 24f, getBounds().height() / 24f);
            path.reset();
            paint.setStyle(Paint.Style.STROKE);
            switch (type) {
                case NAVIGATION:
                    paint.setStyle(Paint.Style.FILL);
                    path.moveTo(20, 4); path.lineTo(14.3f, 21); path.lineTo(10.7f, 13.3f); path.lineTo(3, 9.6f); path.close();
                    canvas.drawPath(path, paint);
                    break;
                case SETTINGS:
                    canvas.drawLine(4, 6, 20, 6, paint); canvas.drawLine(4, 12, 20, 12, paint); canvas.drawLine(4, 18, 20, 18, paint);
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(9, 6, 2.5f, paint); canvas.drawCircle(15, 12, 2.5f, paint); canvas.drawCircle(9, 18, 2.5f, paint);
                    break;
                case START:
                    canvas.drawCircle(12, 12, 7, paint); paint.setStyle(Paint.Style.FILL); canvas.drawCircle(12, 12, 2.5f, paint);
                    break;
                case DESTINATION:
                    canvas.drawRoundRect(new RectF(5, 5, 19, 19), 4, 4, paint); paint.setStyle(Paint.Style.FILL); canvas.drawCircle(12, 12, 3, paint);
                    break;
                case RIGHT:
                    path.moveTo(9, 5); path.lineTo(16, 12); path.lineTo(9, 19); canvas.drawPath(path, paint);
                    break;
                default:
                    path.moveTo(5, 9); path.lineTo(12, 16); path.lineTo(19, 9); canvas.drawPath(path, paint);
            }
            canvas.restoreToCount(save);
        }

        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
