// Additional Google Play Services linking permission: see docs/COPYING-EXCEPTION.md.
// SPDX-License-Identifier: GPL-3.0-or-later
package cl.coders.movingtraveler;

import android.Manifest;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Native map and controls. Network geometry is resolved once; playback never calls Google. */
public final class MainActivity extends Activity implements JourneyUi.Listener {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private JourneyUi ui;
    private NetworkGateway network;
    private MapView mapView;
    private GoogleMap map;
    private Marker startMarker, endMarker, traveler;
    private Polyline line;
    private ValueAnimator motion;
    private Draft draft;
    private boolean started, resumed, registered, wasActive, mapResumed, mapStarted;
    private boolean routeLoading, routeFailed, permissionsPending;
    private boolean mapLoaded, mapLoadTimedOut;
    private long routeId, sequence;
    private int selection = -1, commandGeneration;
    private String message = "", pendingAction = "", pendingPlan;
    private AlertDialog pointDialog, permissionDialog;
    private boolean permissionExplanation;
    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { readState(); }
    };

    /** Retained only in process. Google geometry and Places labels are never saved to disk. */
    static final class Draft {
        double[] start, end;
        boolean startFromGoogle, endFromGoogle;
        String startLabel = "", endLabel = "", travel = "walk", playback = "once", kind = "road";
        double speed = 5, distance;
        double[][] geometry;
        JSONArray startAttributions = new JSONArray(), endAttributions = new JSONArray();
    }

    static final class Retained {
        Draft draft;
        String plan;
        boolean permissionsPending, explanation;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (!SimulationService.active) MockPublisher.recoverStale(this);
        Object retained = getLastNonConfigurationInstance();
        Retained memory = retained instanceof Retained ? (Retained) retained : null;
        draft = memory == null ? restoreDraft() : memory.draft;
        if (memory != null && memory.plan != null) {
            pendingPlan = memory.plan; pendingAction = "start";
            permissionsPending = memory.permissionsPending; permissionExplanation = memory.explanation;
        }
        boolean needsConsent = settings().getInt("googleConsentVersion", 0) < 1;
        if (needsConsent) settings().edit().putBoolean("online", false).apply();
        network = new NetworkGateway(this);
        ui = new JourneyUi(this, this);
        setContentView(ui.root());
        ui.root().setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 35) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            }
            return insets;
        });
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        setupMap(state == null ? null : state.getBundle("map"));
        readState();
        if (!SimulationService.active && draft.geometry == null) refreshRoute();
        handleGeoIntent();
        if (needsConsent) handler.post(this::showOnlineChoice);
        if (permissionExplanation) handler.post(this::showPermissionRationale);
    }

    private SharedPreferences settings() { return getSharedPreferences("settings", MODE_PRIVATE); }
    private boolean online() { return settings().getBoolean("online", false); }
    private boolean proxyConfigured() {
        return BuildConfig.GOOGLE_PROXY_BASE_URL.startsWith("https://") && GoogleAuth.configured();
    }
    private boolean locked() { return SimulationService.active || !pendingAction.isEmpty(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private void haptic() {
        ui.root().performHapticFeedback(Build.VERSION.SDK_INT >= 30
                ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.VIRTUAL_KEY);
    }

    private void setupMap(Bundle saved) {
        destroyMap();
        ui.mapContainer.removeAllViews();
        if (!online() || !BuildConfig.MAPS_CONFIGURED) {
            TextView placeholder = text(!online() ? "Plan at your own pace\n\nEnable online maps in Settings, or enter coordinates."
                    : "Google Maps setup needed\n\nAdd your Android Maps key using the included setup guide.", 16);
            placeholder.setGravity(Gravity.CENTER);
            placeholder.setPadding(dp(32), dp(40), dp(32), dp(24));
            ui.mapContainer.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
            updateHint();
            return;
        }
        int availability = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this);
        if (availability != ConnectionResult.SUCCESS) {
            TextView unavailable = text("Google Play services are needed to display this map. Tap to check.", 16);
            unavailable.setGravity(Gravity.CENTER);
            unavailable.setPadding(dp(28), dp(30), dp(28), dp(24));
            unavailable.setOnClickListener(v -> {
                android.app.Dialog help = GoogleApiAvailability.getInstance().getErrorDialog(this, availability, 20);
                if (help != null) help.show(); else toast("Update Google Play services to display the map.");
            });
            ui.mapContainer.addView(unavailable, new FrameLayout.LayoutParams(-1, -1));
            return;
        }
        try {
            MapsInitializer.initialize(this, MapsInitializer.Renderer.LATEST, renderer -> { });
            // No map ID: standard native Maps SDK pricing, no cloud styling/map-load SKU.
            mapView = new MapView(this, new GoogleMapOptions().mapToolbarEnabled(false)
                    .zoomControlsEnabled(false).compassEnabled(true).rotateGesturesEnabled(false).tiltGesturesEnabled(false));
            ui.mapContainer.addView(mapView, new FrameLayout.LayoutParams(-1, -1));
            mapView.onCreate(saved);
            if (started) { mapView.onStart(); mapStarted = true; }
            if (resumed) { mapView.onResume(); mapResumed = true; }
            MapView requestedView = mapView;
            mapView.getMapAsync(ready -> {
                if (isDestroyed() || mapView != requestedView || !online()) return;
                map = ready;
                map.setOnMapLoadedCallback(() -> { mapLoaded = true; mapLoadTimedOut = false; updateHint(); });
                handler.postDelayed(() -> {
                    if (!isDestroyed() && mapView == requestedView && !mapLoaded) {
                        mapLoadTimedOut = true; updateHint();
                    }
                }, 20_000);
                map.setPadding(dp(8), dp(48), dp(8), dp(8));
                map.getUiSettings().setMapToolbarEnabled(false);
                // Never enable My Location: this app does not retrieve real device location.
                map.setOnMapClickListener(this::mapTapped);
                map.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
                    @Override public void onMarkerDragStart(Marker marker) { }
                    @Override public void onMarkerDrag(Marker marker) { }
                    @Override public void onMarkerDragEnd(Marker marker) {
                        if (locked()) { drawRoute(false); return; }
                        LatLng p = marker.getPosition();
                        setPoint(marker == endMarker, new double[]{p.latitude, p.longitude}, "", false);
                    }
                });
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(20, 0), 2));
                drawRoute(true);
                readState();
                updateHint();
            });
        } catch (RuntimeException error) {
            destroyMap();
            TextView unavailable = text("The map could not start. Check Google Play services and the Maps key setup.", 16);
            unavailable.setGravity(Gravity.CENTER);
            ui.mapContainer.addView(unavailable, new FrameLayout.LayoutParams(-1, -1));
        }
    }

    private void destroyMap() {
        if (motion != null) { motion.cancel(); motion = null; }
        if (mapView != null) {
            if (mapResumed) mapView.onPause();
            if (mapStarted) mapView.onStop();
            mapView.onDestroy();
            ui.mapContainer.removeView(mapView);
            mapView = null;
        }
        mapResumed = mapStarted = false;
        mapLoaded = mapLoadTimedOut = false;
        map = null; startMarker = endMarker = traveler = null; line = null;
    }

    private void mapTapped(LatLng p) {
        if (locked()) return;
        if (selection >= 0 || draft.start == null || draft.end == null) {
            boolean destination = selection == 1 || (selection < 0 && draft.start != null);
            setPoint(destination, new double[]{p.latitude, p.longitude}, "", false);
        } else {
            new AlertDialog.Builder(this).setTitle("Use this point")
                    .setItems(new String[]{"Set start", "Set destination"}, (dialog, index) ->
                            setPoint(index == 1, new double[]{p.latitude, p.longitude}, "", false)).show();
        }
    }

    private void setPoint(boolean destination, double[] point, String label, boolean fromGoogle) {
        if (locked() || !validPoint(point)) return;
        haptic();
        String shown = label == null || label.isEmpty() ? coordinates(point) : label;
        if (destination) { draft.end = point; draft.endLabel = shown; draft.endFromGoogle = fromGoogle; }
        else { draft.start = point; draft.startLabel = shown; draft.startFromGoogle = fromGoogle; }
        if (destination) draft.endAttributions = new JSONArray(); else draft.startAttributions = new JSONArray();
        selection = -1;
        saveDraft();
        refreshRoute();
    }

    private static boolean validPoint(double[] p) {
        return p != null && p.length == 2 && Double.isFinite(p[0]) && Double.isFinite(p[1])
                && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180;
    }
    private static String coordinates(double[] p) {
        return String.format(Locale.US, "%.5f, %.5f", p[0], p[1]);
    }
    static double[] parseCoordinates(String raw) {
        try {
            String[] parts = raw.trim().split(",", -1);
            if (parts.length != 2) return null;
            double[] point = {Double.parseDouble(parts[0].trim()), Double.parseDouble(parts[1].trim())};
            return validPoint(point) ? point : null;
        } catch (NumberFormatException ignored) { return null; }
    }

    private void refreshRoute() {
        if (locked()) return;
        network.cancel("route");
        routeId = ++sequence;
        routeLoading = routeFailed = false;
        draft.geometry = null; draft.distance = 0; message = "";
        if (draft.start == null || (!"static".equals(draft.playback) && draft.end == null)) {
            drawRoute(false); render(); return;
        }
        if ("static".equals(draft.playback) || "direct".equals(draft.kind)) {
            try {
                setGeometry("static".equals(draft.playback) ? new double[][]{draft.start}
                        : new double[][]{draft.start, draft.end});
            } catch (IllegalArgumentException error) { message = error.getMessage(); }
            drawRoute(true); render(); return;
        }
        if (!online() || !proxyConfigured()) {
            message = !online() ? "Enable online maps for road routes, or choose Direct line in Route options."
                    : "Google routing setup is needed. You can use Direct line while configuring Google.";
            drawRoute(true); render(); return;
        }
        routeLoading = true;
        message = "Finding your route…";
        drawRoute(true); render();
        final long expected = routeId;
        try {
            JSONObject request = new JSONObject().put("id", String.valueOf(expected)).put("type", "route")
                    .put("points", new JSONArray(new double[][]{draft.start, draft.end}))
                    .put("travelMode", "cycle".equals(draft.travel) ? "BICYCLE" : draft.travel.toUpperCase(Locale.ROOT));
            GoogleAuth.enable(this);
            network.request(request.toString(), result -> runOnUiThread(() -> {
                if (isDestroyed() || expected != routeId || locked()) return;
                routeLoading = false;
                if (result.optBoolean("ok")) {
                    try {
                        JSONArray a = result.getJSONObject("data").getJSONArray("points");
                        double[][] points = new double[a.length()][2];
                        for (int i = 0; i < a.length(); i++) {
                            points[i][0] = a.getJSONArray(i).getDouble(0);
                            points[i][1] = a.getJSONArray(i).getDouble(1);
                        }
                        setGeometry(points);
                        message = ""; routeFailed = false;
                        drawRoute(true);
                    } catch (Exception invalid) { routeFailed = true; message = "This route could not be read. Try again."; }
                } else { routeFailed = true; message = result.optString("error", "Could not find a route. Try again."); }
                render();
            }));
        } catch (Exception error) { routeLoading = false; routeFailed = true; message = "Could not request the route."; render(); }
    }

    private void setGeometry(double[][] points) {
        RouteEngine engine = new RouteEngine(points, draft.speed, draft.playback);
        if (!"static".equals(draft.playback) && engine.current().totalMeters < 1)
            throw new IllegalArgumentException("Choose points at least one metre apart.");
        draft.geometry = points;
        draft.distance = engine.current().totalMeters;
    }

    private void drawRoute(boolean fit) {
        if (map == null) return;
        if (line != null) { line.remove(); line = null; }
        if (startMarker != null) { startMarker.remove(); startMarker = null; }
        if (endMarker != null) { endMarker.remove(); endMarker = null; }
        if (draft.start != null) startMarker = map.addMarker(new MarkerOptions().position(latLng(draft.start))
                .title("Start").snippet(draft.startLabel).draggable(!locked())
                .icon(BitmapDescriptorFactory.defaultMarker(164)));
        if (draft.end != null && !"static".equals(draft.playback)) endMarker = map.addMarker(new MarkerOptions()
                .position(latLng(draft.end)).title("Destination").snippet(draft.endLabel).draggable(!locked())
                .icon(BitmapDescriptorFactory.defaultMarker(25)));
        if (draft.geometry != null && draft.geometry.length > 1) {
            PolylineOptions options = new PolylineOptions().width(dp(5)).color(Color.rgb(17, 121, 106))
                    .geodesic("direct".equals(draft.kind)).zIndex(2);
            for (double[] p : draft.geometry) options.add(latLng(p));
            line = map.addPolyline(options);
        }
        if (fit && draft.start != null) ui.mapContainer.post(() -> {
            if (map == null || ui.mapContainer.getWidth() < dp(120) || ui.mapContainer.getHeight() < dp(160)) return;
            try {
                if (draft.end == null || "static".equals(draft.playback))
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng(draft.start), 14));
                else {
                    LatLngBounds.Builder bounds = new LatLngBounds.Builder().include(latLng(draft.start)).include(latLng(draft.end));
                    if (draft.geometry != null) for (double[] p : draft.geometry) bounds.include(latLng(p));
                    map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds.build(), dp(42)));
                }
            } catch (RuntimeException ignored) { /* Map layout may change while an IME is closing. */ }
        });
    }
    private LatLng latLng(double[] p) { return new LatLng(p[0], p[1]); }

    private void moveTraveler(JSONObject state) {
        if (map == null || !state.has("lat")) return;
        LatLng next = new LatLng(state.optDouble("lat"), state.optDouble("lon"));
        if (traveler == null) {
            traveler = map.addMarker(new MarkerOptions().position(next).title("Simulated location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)).zIndex(5));
            return;
        }
        if (motion != null) motion.cancel();
        LatLng before = traveler.getPosition();
        if (!resumed || before.equals(next)) { traveler.setPosition(next); return; }
        double deltaLon = ((next.longitude - before.longitude + 540) % 360) - 180;
        motion = ValueAnimator.ofFloat(0, 1);
        motion.setDuration(950);
        motion.setInterpolator(new android.view.animation.LinearInterpolator());
        motion.addUpdateListener(animation -> {
            if (traveler == null) return;
            float t = (float) animation.getAnimatedValue();
            traveler.setPosition(new LatLng(before.latitude + (next.latitude - before.latitude) * t,
                    before.longitude + deltaLon * t));
        });
        motion.start();
    }

    @Override public void onPrimary() {
        if (!pendingAction.isEmpty()) return;
        if (SimulationService.active) {
            try {
                String status = new JSONObject(SimulationService.state).optString("status");
                if ("arrived".equals(status) || "static".equals(draft.playback)) return;
                sendPlayback("paused".equals(status) ? "resume" : "pause");
            } catch (Exception ignored) { }
        } else if (routeFailed) { haptic(); refreshRoute(); }
        else beginStart();
    }
    @Override public void onStopPlayback() { if (SimulationService.active && pendingAction.isEmpty()) sendPlayback("stop"); }

    private void beginStart() {
        if (!resumed || draft.geometry == null || routeLoading || locked()) return;
        if (!mockReady()) { showSetup(); return; }
        try {
            pendingPlan = new JSONObject().put("points", new JSONArray(draft.geometry))
                    .put("speedKmh", draft.speed).put("mode", draft.playback).toString();
            new RoutePlan(pendingPlan);
            SimulationService.state = "{\"status\":\"idle\"}";
            pendingAction = "start"; message = "Starting journey…"; haptic(); render();
            if (!settings().getBoolean("playbackPermissionsAsked", false)) showPermissionRationale();
            else dispatchStart();
        } catch (Exception error) { clearPending(); message = "Could not start this route."; render(); }
    }

    private void showPermissionRationale() {
        if (isDestroyed() || isFinishing() || pendingPlan == null) return;
        permissionsPending = true; permissionExplanation = true;
        permissionDialog = new AlertDialog.Builder(this).setTitle("Playback permissions")
                .setMessage("Approximate location enables Google Play Services mock-location compatibility. Moving Traveler does not read your actual location. Notifications give you playback controls while another app is open.\n\nBoth permissions are optional.")
                .setPositiveButton("Continue", (dialog, which) -> {
                    permissionExplanation = false;
                    settings().edit().putBoolean("playbackPermissionsAsked", true).apply();
                    ArrayList<String> permissions = new ArrayList<>();
                    if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this) == ConnectionResult.SUCCESS
                            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                        permissions.add(Manifest.permission.POST_NOTIFICATIONS);
                    if (permissions.isEmpty()) { permissionsPending = false; dispatchStart(); }
                    else requestPermissions(permissions.toArray(new String[0]), 10);
                }).setNegativeButton("Skip", (dialog, which) -> {
                    permissionsPending = permissionExplanation = false;
                    settings().edit().putBoolean("playbackPermissionsAsked", true).apply(); dispatchStart();
                }).setOnCancelListener(dialog -> { clearPending(); message = ""; render(); }).create();
        permissionDialog.show();
    }

    private void dispatchStart() {
        if (!resumed || permissionsPending || pendingPlan == null) return;
        if (SimulationService.active) { clearPending(); readState(); return; }
        SimulationService.stagedPlan = pendingPlan;
        pendingPlan = null;
        try {
            Intent intent = new Intent(this, SimulationService.class).setAction("start");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
            armCommandTimeout();
        } catch (RuntimeException error) {
            SimulationService.stagedPlan = null;
            clearPending(); message = "Couldn't start playback. Return to the app and try again."; render();
        }
    }
    private void sendPlayback(String action) {
        if (!SimulationService.active || !pendingAction.isEmpty()) return;
        haptic(); pendingAction = action; render();
        try { startService(new Intent(this, SimulationService.class).setAction(action)); armCommandTimeout(); }
        catch (RuntimeException error) { clearPending(); message = "Playback control failed. Try again."; render(); }
    }
    private void armCommandTimeout() {
        int expected = ++commandGeneration;
        handler.postDelayed(() -> {
            if (isDestroyed() || expected != commandGeneration || pendingAction.isEmpty()) return;
            if ("start".equals(pendingAction) && !SimulationService.active) SimulationService.stagedPlan = null;
            clearPending(); message = "Playback did not respond. Check the notification and try again."; readState();
        }, 10_000);
    }
    private void clearPending() { commandGeneration++; pendingAction = ""; pendingPlan = null; permissionsPending = permissionExplanation = false; }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == 10) { permissionsPending = false; handler.post(this::dispatchStart); }
        readState();
    }

    private void readState() {
        if (ui == null || isDestroyed()) return;
        try {
            JSONObject state = new JSONObject(SimulationService.state);
            boolean active = SimulationService.active;
            String status = state.optString("status", "idle");
            boolean acknowledged = ("start".equals(pendingAction) && active)
                    || ("pause".equals(pendingAction) && ("paused".equals(status) || "arrived".equals(status)))
                    || ("resume".equals(pendingAction) && ("running".equals(status) || "arrived".equals(status)))
                    || ("stop".equals(pendingAction) && !active) || "error".equals(status);
            if (acknowledged) { clearPending(); message = ""; }
            if (active) {
                draft.speed = state.optDouble("speedKmh", draft.speed);
                draft.playback = state.optString("mode", draft.playback);
                if (!wasActive && SimulationService.routePoints != null) {
                    draft.geometry = SimulationService.routePoints;
                    // Preserve user-selected endpoints. A cold service restore has unknown provenance;
                    // conservatively keep those derived coordinates in memory only.
                    if (draft.start == null) { draft.start = draft.geometry[0]; draft.startFromGoogle = true; }
                    if (draft.end == null) { draft.end = draft.geometry[draft.geometry.length - 1]; draft.endFromGoogle = true; }
                    if (draft.startLabel.isEmpty()) draft.startLabel = coordinates(draft.start);
                    if (draft.endLabel.isEmpty()) draft.endLabel = coordinates(draft.end);
                    draft.distance = state.optDouble("totalMeters");
                    drawRoute(false);
                }
                moveTraveler(state);
            } else if (wasActive) {
                if (motion != null) motion.cancel();
                if (traveler != null) { traveler.remove(); traveler = null; }
                drawRoute(false);
            }
            if (startMarker != null) startMarker.setDraggable(!active && pendingAction.isEmpty());
            if (endMarker != null) endMarker.setDraggable(!active && pendingAction.isEmpty());
            wasActive = active;
            if ("error".equals(status)) message = state.optString("message", "Playback stopped.");
            render();
        } catch (Exception ignored) { render(); }
    }

    private void render() {
        if (ui == null) return;
        boolean active = SimulationService.active;
        String status = routeFailed ? "route_error" : "idle", shown = message;
        double remaining = draft.distance / (draft.speed / 3.6);
        if (active) try {
            JSONObject state = new JSONObject(SimulationService.state);
            status = state.optString("status", "running");
            shown = state.optString("message", "");
            remaining = Math.max(0, state.optDouble("totalMeters") - state.optDouble("distanceMeters")) / (draft.speed / 3.6);
        } catch (Exception ignored) { }
        boolean canStart = !routeLoading && (draft.geometry != null || (routeFailed && online() && proxyConfigured()));
        if (draft.geometry != null && "road".equals(draft.kind) && !"static".equals(draft.playback)
                && ("walk".equals(draft.travel) || "cycle".equals(draft.travel))) {
            shown += (shown.isEmpty() ? "" : "\n")
                    + "Walking and cycling routes are in beta and may omit sidewalks, pedestrian paths or cycle paths.";
        }
        ui.render(status, shown, draft.startLabel, draft.endLabel, draft.speed, draft.distance, remaining,
                active, !pendingAction.isEmpty(), canStart, draft.travel, draft.playback, draft.kind, routeLoading);
        renderAttributions();
        updateHint();
    }
    private void renderAttributions() {
        android.text.SpannableStringBuilder credits = new android.text.SpannableStringBuilder();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        JSONArray[] sources = "static".equals(draft.playback) ? new JSONArray[]{draft.startAttributions}
                : new JSONArray[]{draft.startAttributions, draft.endAttributions};
        for (JSONArray list : sources) for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i); if (item == null) continue;
            String provider = item.optString("provider"); String url = item.optString("providerUri");
            if (provider.isEmpty() || !seen.add(provider + url)) continue;
            credits.append(credits.length() == 0 ? "Place data: " : " · ");
            int begin = credits.length(); credits.append(provider);
            if (url.startsWith("https://") || url.startsWith("http://")) {
                credits.setSpan(new android.text.style.ClickableSpan() {
                    @Override public void onClick(View view) { openExternal(Uri.parse(url)); }
                }, begin, credits.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        ui.setAttributions(credits);
    }

    private void updateHint() {
        if (!online()) ui.setMapHint("Coordinate-only planning");
        else if (!BuildConfig.MAPS_CONFIGURED) ui.setMapHint("Google setup required");
        else if (mapLoadTimedOut) ui.setMapHint("Map still loading · check connection and Maps key setup");
        else if (SimulationService.active) ui.setMapHint("Simulated location · " + ("static".equals(draft.playback) ? "Holding" : "Journey"));
        else if (selection >= 0) ui.setMapHint(selection == 1 ? "Tap the map to set your destination" : "Tap the map to set your start");
        else if (draft.start == null) ui.setMapHint("Tap the map to choose your start");
        else if (draft.end == null && !"static".equals(draft.playback)) ui.setMapHint("Tap the map to choose your destination");
        else ui.setMapHint("Drag either pin to adjust your route");
    }

    @Override public void onSpeed(double speed) {
        if (!Double.isFinite(speed) || speed < .5 || speed > 200 || !pendingAction.isEmpty()) return;
        draft.speed = speed; saveDraft();
        if (SimulationService.active) {
            try { startService(new Intent(this, SimulationService.class).setAction("speed").putExtra("speedKmh", speed)); }
            catch (RuntimeException error) { message = "Couldn't change the pace. Try again."; }
        }
        render();
    }
    @Override public void onPreset(String mode, double speed) {
        if (locked()) return;
        if (!"walk".equals(mode) && !"cycle".equals(mode) && !"drive".equals(mode)) return;
        boolean changed = !draft.travel.equals(mode);
        draft.travel = mode; draft.speed = speed; haptic(); saveDraft();
        if (changed && "road".equals(draft.kind) && !"static".equals(draft.playback)) refreshRoute(); else render();
    }

    @Override public void onOptions() {
        if (locked()) return;
        String[] choices = {"Road route", "Direct line", "One way · hold destination", "Back and forth", "Stay at start", "Swap start and destination", "Clear route"};
        new AlertDialog.Builder(this).setTitle("Route options").setItems(choices, (dialog, index) -> {
            if (locked()) return;
            haptic();
            String previousKind = draft.kind, previousPlayback = draft.playback;
            switch (index) {
                case 0: draft.kind = "road"; if ("static".equals(draft.playback)) draft.playback = "once"; break;
                case 1: draft.kind = "direct"; if ("static".equals(draft.playback)) draft.playback = "once"; break;
                case 2: draft.playback = "once"; break;
                case 3: draft.playback = "pingpong"; break;
                case 4: draft.playback = "static"; break;
                case 5:
                    double[] p = draft.start; draft.start = draft.end; draft.end = p;
                    String label = draft.startLabel; draft.startLabel = draft.endLabel; draft.endLabel = label;
                    boolean from = draft.startFromGoogle; draft.startFromGoogle = draft.endFromGoogle; draft.endFromGoogle = from;
                    JSONArray attribution = draft.startAttributions; draft.startAttributions = draft.endAttributions; draft.endAttributions = attribution;
                    break;
                case 6: draft.start = draft.end = null; draft.startLabel = draft.endLabel = ""; draft.startAttributions = new JSONArray(); draft.endAttributions = new JSONArray(); break;
                default: return;
            }
            selection = -1; saveDraft();
            boolean samePath = ((index == 2 || index == 3) && !"static".equals(previousPlayback))
                    || ((index == 0 || index == 1) && previousKind.equals(draft.kind)
                        && previousPlayback.equals(draft.playback));
            // A return-trip choice changes local playback, not the Google road geometry.
            if (samePath) { if (draft.geometry != null) setGeometry(draft.geometry); render(); }
            else refreshRoute();
        }).show();
    }

    @Override public void onPoint(boolean destination) {
        if (locked()) return;
        new PointPicker(destination).show();
    }

    private final class PointPicker {
        final boolean destination;
        final LinearLayout content = new LinearLayout(MainActivity.this), results = new LinearLayout(MainActivity.this);
        final EditText input = new EditText(MainActivity.this);
        final TextView status = text("Search for a place, or enter latitude, longitude.", 14);
        String session = UUID.randomUUID().toString();
        long generation;
        boolean closed, resolving;
        Runnable debounce;
        AlertDialog dialog;
        PointPicker(boolean destination) { this.destination = destination; }
        void show() {
            if (pointDialog != null) pointDialog.dismiss();
            content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(22), dp(8), dp(22), 0);
            results.setOrientation(LinearLayout.VERTICAL);
            input.setSingleLine(true); input.setHint("Place or coordinates"); input.setTextSize(16);
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            content.addView(input, new LinearLayout.LayoutParams(-1, dp(56)));
            content.addView(status);
            ScrollView scroll = new ScrollView(MainActivity.this); scroll.addView(results);
            content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(180)));
            TextView attribution = text("Google Maps", 12); attribution.setTextColor(Color.rgb(94,94,94));
            attribution.setPadding(0, dp(8), 0, dp(6)); content.addView(attribution);
            attribution.setVisibility(online() && proxyConfigured() ? View.VISIBLE : View.GONE);
            dialog = new AlertDialog.Builder(MainActivity.this).setTitle(destination ? "Destination" : "Starting point")
                    .setView(content).setPositiveButton("Use coordinates", null)
                    .setNeutralButton("Choose on map", (d, w) -> {
                        selection = destination ? 1 : 0; updateHint();
                        if (!online() || !BuildConfig.MAPS_CONFIGURED) toast("Enable and configure Google Maps, or enter coordinates.");
                    }).setNegativeButton("Cancel", null).create();
            pointDialog = dialog;
            dialog.setOnDismissListener(d -> {
                closed = true; generation++; if (debounce != null) handler.removeCallbacks(debounce);
                network.cancel("search"); network.cancel("place");
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
                if (pointDialog == dialog) pointDialog = null;
            });
            dialog.show();
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setVisibility(map == null ? View.GONE : View.VISIBLE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                double[] point = parseCoordinates(input.getText().toString());
                if (point == null || resolving) { input.setError("Use latitude, longitude within valid ranges."); return; }
                setPoint(destination, point, "", false); dialog.dismiss();
            });
            input.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) { scheduleSearch(s.toString()); }
                @Override public void afterTextChanged(Editable s) { }
            });
        }
        void scheduleSearch(String query) {
            generation++; resolving = false; network.cancel("search"); network.cancel("place");
            if (debounce != null) handler.removeCallbacks(debounce);
            results.removeAllViews();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(parseCoordinates(query) != null);
            if (parseCoordinates(query) != null) { status.setText(R.string.search_coordinates_ready); return; }
            if (query.trim().length() < 3) { status.setText(R.string.search_minimum); return; }
            if (query.matches("[+\\-0-9.,\\s]+")) { status.setText(R.string.search_coordinate_hint); return; }
            if (!online() || !proxyConfigured()) { status.setText(R.string.search_setup_needed); return; }
            status.setText(R.string.search_loading);
            long expected = generation;
            debounce = () -> {
                try {
                    GoogleAuth.enable(MainActivity.this);
                    JSONObject request = new JSONObject().put("type", "search").put("id", String.valueOf(++sequence))
                            .put("query", query.trim()).put("sessionToken", session);
                    network.request(request.toString(), response -> runOnUiThread(() -> {
                        if (closed || expected != generation || isDestroyed()) return;
                        if (!response.optBoolean("ok")) { status.setText(response.optString("error", "Search failed. Edit your search to retry.")); return; }
                        JSONArray list = response.optJSONArray("data");
                        status.setText(list == null || list.length() == 0 ? "No places found. Try a different name or coordinates." : "Choose a place");
                        if (list != null) for (int i = 0; i < list.length(); i++) {
                            JSONObject place = list.optJSONObject(i); if (place == null) continue;
                            Button item = new Button(MainActivity.this); item.setAllCaps(false); item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                            item.setText(place.optString("label")); item.setMinHeight(dp(52)); item.setTextSize(14);
                            item.setOnClickListener(v -> resolve(place)); results.addView(item, new LinearLayout.LayoutParams(-1, -2));
                        }
                    }));
                } catch (Exception error) { status.setText(R.string.search_failure); }
            };
            handler.postDelayed(debounce, 600);
        }
        void resolve(JSONObject place) {
            if (closed || resolving) return;
            resolving = true; long expected = ++generation;
            status.setText(R.string.place_loading); results.removeAllViews(); input.setEnabled(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            try {
                JSONObject request = new JSONObject().put("type", "place").put("id", String.valueOf(++sequence))
                        .put("placeId", place.getString("placeId")).put("sessionToken", session);
                network.request(request.toString(), response -> runOnUiThread(() -> {
                    if (closed || expected != generation || isDestroyed()) return;
                    resolving = false; input.setEnabled(true); session = UUID.randomUUID().toString();
                    if (!response.optBoolean("ok")) { status.setText(response.optString("error", "Couldn't load this place. Edit the search to retry.")); return; }
                    try {
                        JSONObject p = response.getJSONObject("data");
                        setPoint(destination, new double[]{p.getDouble("lat"), p.getDouble("lon")}, p.optString("label"), true);
                        JSONArray attribution = p.optJSONArray("attributions");
                        if (attribution != null) {
                            if (destination) draft.endAttributions = attribution; else draft.startAttributions = attribution;
                            renderAttributions();
                        }
                        dialog.dismiss();
                    } catch (Exception error) { status.setText(R.string.place_no_coordinates); }
                }));
            } catch (Exception error) { resolving = false; input.setEnabled(true); status.setText(R.string.place_failure); }
        }
    }

    @Override public void onSettings() {
        String[] choices = {online() ? "Turn off online maps" : "Enable online maps", "Mock location setup", "Notifications and compatibility", "Privacy and licenses", "Google setup"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(choices, (dialog, which) -> {
            switch (which) {
                case 0: if (online()) setOnline(false); else showOnlineChoice(); break;
                case 1: showSetup(); break;
                case 2: openExternal(Uri.parse("package:" + getPackageName()), Settings.ACTION_APPLICATION_DETAILS_SETTINGS); break;
                case 3: showPrivacy(); break;
                case 4: showGoogleSetup(); break;
                default: break;
            }
        }).show();
    }
    private void showOnlineChoice() {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this).setTitle("Use online maps?")
                .setMessage("Google receives the map area you view. Searches and selected route points pass through the app's routing service to Google. Firebase App Check verifies the app. These services receive network and device metadata.\n\nMovement runs on your phone. You can also plan direct routes using coordinates without online maps.")
                .setPositiveButton("Enable", (dialog, which) -> setOnline(true))
                .setNegativeButton("Coordinates only", (dialog, which) -> {
                    if (!locked()) { draft.kind = "direct"; saveDraft(); }
                    setOnline(false);
                }).show();
    }
    private void setOnline(boolean enabled) {
        settings().edit().putBoolean("online", enabled).putInt("googleConsentVersion", 1).apply();
        network.cancel("route"); network.cancel("search"); network.cancel("place"); routeId = ++sequence; routeLoading = false;
        if (pointDialog != null) pointDialog.dismiss();
        if (enabled) { try { GoogleAuth.enable(this); } catch (RuntimeException ignored) { } }
        else GoogleAuth.disable();
        setupMap(null);
        if (!locked()) refreshRoute(); else render();
    }
    private void showGoogleSetup() {
        new AlertDialog.Builder(this).setTitle("Google setup")
                .setMessage("This build needs the publisher's Google Cloud configuration.\n\n1. Enable billing, Maps SDK for Android, Routes API and Places API (New).\n2. Add a Maps key restricted to this package and signing certificate.\n3. Deploy the included routing service and configure Firebase App Check.\n4. Add the public app configuration to secrets.properties, then rebuild.\n\nThe source includes docs/GOOGLE-SETUP.md with all steps. Never put the server API key in the Android app.\n\nPackage: " + getPackageName())
                .setPositiveButton("Close", null).setNeutralButton("Google Cloud", (d, w) -> openExternal(Uri.parse("https://console.cloud.google.com/"))).show();
    }
    @SuppressWarnings("deprecation") private boolean mockReady() {
        try { return ((AppOpsManager) getSystemService(APP_OPS_SERVICE)).checkOpNoThrow("android:mock_location", Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED; }
        catch (RuntimeException error) { return false; }
    }
    private void showSetup() {
        new AlertDialog.Builder(this).setTitle("Allow location simulation")
                .setMessage("1. Open Settings → About phone and tap Build number seven times to enable Developer options.\n\n2. Open Developer options → Select mock location app → Moving Traveler.\n\n3. Return here and start your journey. Other apps decide whether to accept mock locations.")
                .setPositiveButton("Developer options", (dialog, which) -> {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
                    catch (RuntimeException error) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                }).setNegativeButton("Close", null).show();
    }
    private void showPrivacy() {
        new AlertDialog.Builder(this).setTitle("Privacy and licenses")
                .setMessage("Moving Traveler does not retrieve your real GPS location. Optional approximate-location permission enables Google mock-location compatibility. There are no ads, accounts or analytics SDKs added by this app.\n\nOnline maps use Google Maps. Place searches and route points go through the publisher's proxy to Google. Firebase App Check and Play Integrity verify the app. Providers receive request and device/network metadata. Turning online maps off stops new app planning requests; it does not control system services.\n\nManual coordinate drafts stay on this device. Google search results and route geometry are held in memory for the current session and are not saved by this app. Stop removes mock providers and ends playback.\n\nIndependently developed from the FakeTraveler concept. Application: GPL-3.0-or-later with Google linking permission. Google Maps and Firebase retain their own terms. See the source for complete notices.")
                .setPositiveButton("Close", null)
                .setNegativeButton("Privacy policy", (d, w) -> {
                    if (BuildConfig.PUBLIC_PRIVACY_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_PRIVACY_URL));
                    else toast("The publisher's public privacy policy must be configured before release.");
                }).setNeutralButton("More", (d, w) -> new AlertDialog.Builder(this).setTitle("Terms and source")
                        .setItems(new String[]{"Google privacy", "Google Maps terms", "Open source licenses", "Application source", "App terms"}, (dialog, index) -> {
                            if (index == 0) openExternal(Uri.parse("https://policies.google.com/privacy"));
                            if (index == 1) openExternal(Uri.parse("https://maps.google.com/help/terms_maps/"));
                            if (index == 2) showLicenses();
                            if (index == 3) {
                                if (BuildConfig.PUBLIC_SOURCE_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_SOURCE_URL));
                                else toast("See the included source archive. The publisher must add a public source URL before release.");
                            }
                            if (index == 4) {
                                if (BuildConfig.PUBLIC_TERMS_URL.startsWith("https://")) openExternal(Uri.parse(BuildConfig.PUBLIC_TERMS_URL));
                                else toast("The publisher's public terms must be configured before release.");
                            }
                        }).show()).show();
    }
    private void showLicenses() {
        String licenses;
        try (java.io.InputStream in = getAssets().open("THIRD-PARTY-NOTICES.txt")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int n; while ((n = in.read(buffer)) != -1) bytes.write(buffer, 0, n);
            licenses = bytes.toString("UTF-8");
        } catch (Exception ignored) { licenses = "See the corresponding source archive for complete licenses."; }
        TextView body = text(licenses, 13); body.setPadding(dp(20), dp(12), dp(20), dp(12));
        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        new AlertDialog.Builder(this).setTitle("Open source licenses").setView(scroll).setPositiveButton("Close", null)
                .setNeutralButton("Library licenses", (dialog, which) -> LicenseViewer.show(this)).show();
    }
    private TextView text(String value, int size) {
        TextView text = new TextView(this); text.setText(value); text.setTextSize(size); text.setTextColor(Color.rgb(49,65,61)); return text;
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
    private void openExternal(Uri uri) { openExternal(uri, Intent.ACTION_VIEW); }
    private void openExternal(Uri uri, String action) {
        try { startActivity(new Intent(action, uri)); } catch (RuntimeException error) { toast("No app is available to open this."); }
    }

    private Draft restoreDraft() {
        Draft value = new Draft();
        try {
            JSONObject json = new JSONObject(getSharedPreferences("nativeDraft", 0).getString("value", "{}"));
            value.start = savedPoint(json.optJSONArray("start")); value.end = savedPoint(json.optJSONArray("end"));
            value.startLabel = value.start == null ? "" : coordinates(value.start);
            value.endLabel = value.end == null ? "" : coordinates(value.end);
            value.speed = Math.max(.5, Math.min(200, json.optDouble("speed", 5)));
            if (!Double.isFinite(value.speed)) value.speed = 5;
            String travel = json.optString("travel", "walk");
            if ("walk".equals(travel) || "cycle".equals(travel) || "drive".equals(travel)) value.travel = travel;
            String playback = json.optString("playback", "once");
            if ("once".equals(playback) || "pingpong".equals(playback) || "static".equals(playback)) value.playback = playback;
            value.kind = "direct".equals(json.optString("kind")) ? "direct" : "road";
        } catch (Exception ignored) { }
        return value;
    }
    private double[] savedPoint(JSONArray array) {
        if (array == null || array.length() != 2) return null;
        double[] p = {array.optDouble(0), array.optDouble(1)}; return validPoint(p) ? p : null;
    }
    private void saveDraft() {
        try {
            JSONObject json = new JSONObject().put("speed", draft.speed).put("travel", draft.travel)
                    .put("playback", draft.playback).put("kind", draft.kind);
            if (draft.start != null && !draft.startFromGoogle) json.put("start", new JSONArray(draft.start));
            if (draft.end != null && !draft.endFromGoogle) json.put("end", new JSONArray(draft.end));
            getSharedPreferences("nativeDraft", 0).edit().putString("value", json.toString()).apply();
        } catch (Exception ignored) { }
    }
    private void handleGeoIntent() {
        Uri uri = getIntent().getData();
        if (uri == null || !"geo".equals(uri.getScheme()) || locked()) return;
        double[] point = parseCoordinates(uri.getSchemeSpecificPart().split("[?;]")[0]);
        if (point != null) { setPoint(false, point, "", false); getIntent().setData(null); }
    }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleGeoIntent(); }
    private void handleBack() {
        if (selection >= 0) { selection = -1; updateHint(); } else moveTaskToBack(true);
    }
    @SuppressWarnings("deprecation") @SuppressLint("GestureBackNavigation")
    @Override public void onBackPressed() { handleBack(); }
    @Override public Object onRetainNonConfigurationInstance() {
        Retained value = new Retained(); value.draft = draft; value.plan = pendingPlan;
        value.permissionsPending = permissionsPending; value.explanation = permissionExplanation;
        return value;
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        if (mapView != null) { Bundle mapState = new Bundle(); mapView.onSaveInstanceState(mapState); state.putBundle("map", mapState); }
    }
    @Override protected void onStart() {
        super.onStart(); started = true;
        if (mapView != null && !mapStarted) { mapView.onStart(); mapStarted = true; }
    }
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override protected void onResume() {
        super.onResume(); resumed = true;
        if (!registered) {
            IntentFilter filter = new IntentFilter(SimulationService.CHANGE);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, RECEIVER_NOT_EXPORTED); else registerReceiver(updates, filter);
            registered = true;
        }
        if (mapView != null && !mapResumed) { mapView.onResume(); mapResumed = true; }
        readState();
        if (pendingPlan != null) handler.post(this::dispatchStart);
    }
    @Override protected void onPause() {
        resumed = false;
        if (registered) { unregisterReceiver(updates); registered = false; }
        if (motion != null) motion.cancel();
        if (mapView != null && mapResumed) { mapView.onPause(); mapResumed = false; }
        super.onPause();
    }
    @Override protected void onStop() {
        started = false;
        if (mapView != null && mapStarted) { mapView.onStop(); mapStarted = false; }
        super.onStop();
    }
    @Override public void onLowMemory() { super.onLowMemory(); if (mapView != null) mapView.onLowMemory(); }
    @Override protected void onDestroy() {
        if (pointDialog != null) pointDialog.dismiss();
        if (permissionDialog != null) permissionDialog.dismiss();
        handler.removeCallbacksAndMessages(null);
        if (network != null) network.close();
        if (ui != null) destroyMap();
        super.onDestroy();
    }
}
