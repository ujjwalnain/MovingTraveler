# Moving Traveler 1.1

An Android mock-location simulator with a native Google map, start/destination selection and adjustable pace. Independently authored from the [FakeTraveler](https://github.com/mcastillof/faketraveler) concept; upstream attribution is preserved in `UPSTREAM.md`.

## Features

- Select or drag map pins, search for places, or enter coordinates.
- Google walking, cycling and driving routes; failed road routing never silently becomes a direct line.
- Explicit direct paths, fixed location, one-way arrival hold, and back-and-forth playback.
- Pace from 0.5–200 km/h, adjustable during playback; trip duration follows the selected pace.
- Native controls with pressed states, accessible touch targets and system-respecting haptics for important actions.
- Background foreground-service playback, Pause/Resume and Stop notification controls.
- Android GPS/network/framework fused mock providers plus optional Google Play Services fused mocking.
- Latest-request-wins routing/search, cancellation and bounded deadlines. Playback stays local after route calculation.
- No app accounts, ads or added analytics. No real location retrieval by application code. Optional approximate-location permission enables Google mock compatibility; it is not required for framework mock providers.

## Start here

**Google features need your Cloud/Firebase configuration.** No paid account or deployment is included. Read [GOOGLE-SETUP.md](docs/GOOGLE-SETUP.md) for keys, restrictions, billing, App Check, the proxy and rebuilding. The supplied debug APK is unconfigured and supports coordinate-based testing; it cannot display live Google maps or routes yet.

1. Install the debug APK on an Android 6.0+ test phone.
2. In Developer options → Select mock location app, choose Moving Traveler.
3. Configure Google or choose Coordinates only. Tap From and To to enter coordinates; choose Direct line under Route options for offline movement.
4. Select pace and Start journey. Grant optional compatibility/notification permissions if desired.
5. Stop ends the simulation. Pause and arrival hold the current position until Stop.

Other apps decide whether to accept mock locations. WhatsApp **live location** has not been verified on a physical phone; sending a static location message will not animate. The app does not access WhatsApp data or start sharing on your behalf.

## Build and test

Use JDK 17/21, Android SDK Platform 36 and Build Tools 36.0.0:

```sh
./gradlew testDebugUnitTest lintDebug lintRelease assembleDebug bundleRelease
cd backend
npm ci --omit=optional --ignore-scripts
npm test
npm audit --omit=dev --omit=optional
```

Gradle 8.13 is pinned with a distribution checksum; AGP 8.13.2, Java 17, min API 23 and target API 36. Android dependencies include Maps SDK 20.0.0, location 21.3.0 and Firebase BoM 34.19.0. SDK API contracts and dependency versions were checked against official documentation on 14 September 2026.

Copy `secrets.properties.example` to ignored `secrets.properties` for public Android app configuration. The Routes/Places **server key belongs only in Secret Manager/backend environment**, never in the Android build. `local.properties` may set `sdk.dir`; neither local file nor signing keys belongs in source archives. `-PdebugKeystore=/path/to/debug.keystore` optionally redirects debug signing in restricted environments.

Outputs are `app/build/outputs/apk/debug/app-debug.apk` and `app/build/outputs/bundle/release/app-release.aab`. The release bundle is unsigned; use your own upload key for Play. Working branding can change later; select the final package before first publication.

## Architecture and data

`MainActivity` coordinates a native `MapView` and `JourneyUi`. `NetworkGateway` has independent cancelable route/search/place lanes. The [Node gateway](backend/README.md) authenticates App Check, restricts Google request fields, validates geometry and applies bounded rate limits. `RouteEngine` advances against monotonic elapsed time; `SimulationService` publishes mock samples and does not call routing APIs.

Google geometry and Places content stay in process memory. Manual coordinate drafts and preferences are local. Internet planning is opt-in; disabling it prevents new app planning requests. Google/Firebase/hosting services process request/device/network metadata under their own policies. See the publisher [privacy draft](docs/PRIVACY-POLICY-DRAFT.md).

## Release and licenses

[Verification](docs/VERIFICATION.md) records actual checks and limitations. [Play release preparation](docs/PLAY-RELEASE.md) and the [device plan](docs/DEVICE-TEST-PLAN.md) remain necessary; passing a build does not prove device performance, WhatsApp compatibility or Play approval.

Application code is GPL-3.0-or-later with the scoped [Google linking permission](docs/COPYING-EXCEPTION.md). Google/Firebase and other dependencies keep their terms. Android library notices are generated at build time by Google's OSS licenses plugin and available in Settings → Privacy and licenses. The old Leaflet/OSM web UI is no longer packaged. Publish complete corresponding source for each distributed version.
