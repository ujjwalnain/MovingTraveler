// SPDX-License-Identifier: GPL-3.0-or-later
import { createHash } from 'node:crypto';

export const LIMITS = Object.freeze({ requestBytes: 8192, upstreamBytes: 2_000_000,
  responseBytes: 1_500_000, points: 20_000, tokenBytes: 4096, upstreamMs: 12_000, authMs: 5000 });
const ROUTES_URL = 'https://routes.googleapis.com/directions/v2:computeRoutes';
const PLACES_URL = 'https://places.googleapis.com/v1/';
const ROUTE_MASK = 'routes.polyline.encodedPolyline,routes.distanceMeters,routes.duration';
const SEARCH_MASK = 'suggestions.placePrediction.placeId,suggestions.placePrediction.text.text';
const PLACE_MASK = 'location,formattedAddress,attributions';
const PATHS = new Set(['/route', '/search', '/place']);
const LOOPBACK = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{16,36}$/;
const PLACE_PATTERN = /^[A-Za-z0-9_-]{1,512}$/;

export class HttpError extends Error {
  constructor(status, code, message, retryAfter) {
    super(message); this.status = status; this.code = code; this.retryAfter = retryAfter;
  }
}
function invalid(message = 'Check the request fields and try again.') {
  return new HttpError(400, 'INVALID_REQUEST', message);
}
function invalidResponse() {
  return new HttpError(502, 'INVALID_RESPONSE', 'The map provider returned an invalid response.');
}
function positiveInt(value, fallback, max) {
  if (value === undefined || value === '') return fallback;
  if (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > max) throw new Error('Invalid numeric server configuration.');
  return Number(value);
}
export function loadConfig(env = process.env) {
  const localBypass = env.DEV_LOCAL_BYPASS === 'true';
  if (env.DEV_LOCAL_BYPASS && !['true', 'false'].includes(env.DEV_LOCAL_BYPASS)) throw new Error('Invalid bypass configuration.');
  const host = env.HOST || (localBypass ? '127.0.0.1' : '0.0.0.0');
  if (localBypass && (env.NODE_ENV !== 'development' || host !== '127.0.0.1' || env.K_SERVICE)) {
    throw new Error('Development bypass requires NODE_ENV=development, HOST=127.0.0.1, and no Cloud Run environment.');
  }
  const googleApiKey = (env.GOOGLE_MAPS_SERVER_KEY || '').trim();
  const firebaseProjectId = (env.FIREBASE_PROJECT_ID || '').trim();
  const firebaseAppId = (env.FIREBASE_APP_ID || '').trim();
  if (!googleApiKey || /^(replace|your|placeholder)/i.test(googleApiKey)) throw new Error('GOOGLE_MAPS_SERVER_KEY is required.');
  if (!localBypass && (!/^[a-z][a-z0-9-]{4,61}[a-z0-9]$/.test(firebaseProjectId)
    || !/^1:\d+:android:[a-fA-F0-9]+$/.test(firebaseAppId))) {
    throw new Error('A valid FIREBASE_PROJECT_ID and Android FIREBASE_APP_ID are required.');
  }
  const allowedOrigins = new Set((env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean));
  for (const origin of allowedOrigins) {
    let url;
    try { url = new URL(origin); } catch { throw new Error('Invalid allowed origin.'); }
    if (url.protocol !== 'https:' || url.origin !== origin || url.username || url.password) throw new Error('Allowed origins must be exact HTTPS origins.');
  }
  return Object.freeze({ localBypass, host, googleApiKey, firebaseProjectId, firebaseAppId, allowedOrigins,
    port: positiveInt(env.PORT, 8080, 65535),
    perTokenPerMinute: positiveInt(env.PER_TOKEN_PER_MINUTE, 60, 600),
    globalPerMinute: positiveInt(env.GLOBAL_PER_MINUTE, 300, 10_000),
    globalPerDay: positiveInt(env.GLOBAL_PER_DAY, 5000, 1_000_000),
    maxRateEntries: positiveInt(env.MAX_RATE_ENTRIES, 10_000, 100_000),
    maxInflight: positiveInt(env.MAX_INFLIGHT, 32, 256) });
}

// A hard memory bound; full buckets reject new keys rather than evicting active limits.
// These limits are per process. A distributed limiter/edge control is needed when scaling.
export class RateLimiter {
  constructor({ maxEntries = 10_000, now = Date.now } = {}) { this.maxEntries = maxEntries; this.now = now; this.entries = new Map(); }
  take(key, limit, windowMs) {
    const now = this.now();
    let entry = this.entries.get(key);
    if (!entry || now >= entry.reset) {
      if (this.entries.size >= this.maxEntries) {
        for (const [id, item] of this.entries) if (now >= item.reset) this.entries.delete(id);
      }
      if (!entry && this.entries.size >= this.maxEntries) throw new HttpError(429, 'RATE_LIMITED', 'The service is busy. Try again shortly.', 60);
      entry = { count: 0, reset: now + windowMs }; this.entries.set(key, entry);
    }
    if (entry.count >= limit) throw new HttpError(429, 'RATE_LIMITED', 'Too many requests. Try again later.', Math.max(1, Math.ceil((entry.reset - now) / 1000)));
    entry.count++;
  }
}

function objectWithKeys(value, keys) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== keys.length
    || keys.some(key => !Object.hasOwn(value, key))) throw invalid();
}
function coordinate(point) {
  return Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)
    && Math.abs(point[0]) <= 90 && Math.abs(point[1]) <= 180;
}
function sessionToken(token) {
  if (typeof token !== 'string' || !TOKEN_PATTERN.test(token)) throw invalid('Use a fresh session token for each selected place.');
}
export function validateRequest(path, body) {
  if (path === '/route') {
    objectWithKeys(body, ['points', 'travelMode']);
    if (!Array.isArray(body.points) || body.points.length !== 2 || !body.points.every(coordinate)
      || !['DRIVE', 'WALK', 'BICYCLE'].includes(body.travelMode)) throw invalid('Choose two valid points and a supported travel mode.');
    return body;
  }
  if (path === '/search') {
    objectWithKeys(body, ['query', 'sessionToken']); sessionToken(body.sessionToken);
    if (typeof body.query !== 'string' || body.query.trim().length < 2 || body.query.length > 200
      || /[\u0000-\u001f\u007f]/.test(body.query)) throw invalid('Search text must contain 2 to 200 characters.');
    return { ...body, query: body.query.trim() };
  }
  if (path === '/place') {
    objectWithKeys(body, ['placeId', 'sessionToken']); sessionToken(body.sessionToken);
    if (typeof body.placeId !== 'string' || !PLACE_PATTERN.test(body.placeId)) throw invalid('Choose a valid place from the search results.');
    return body;
  }
  throw new HttpError(404, 'NOT_FOUND', 'Endpoint not found.');
}

export function decodePolyline(encoded, maxPoints = LIMITS.points) {
  if (typeof encoded !== 'string' || encoded.length === 0 || encoded.length > 300_000) throw invalidResponse();
  let index = 0, lat = 0, lon = 0;
  const points = [];
  const component = () => {
    let value = 0, shift = 0;
    for (let count = 0; count < 6; count++) {
      if (index >= encoded.length) throw invalidResponse();
      const byte = encoded.charCodeAt(index++) - 63;
      if (byte < 0 || byte > 63) throw invalidResponse();
      value += (byte & 31) * 2 ** shift;
      if (byte < 32) return value % 2 ? -(Math.floor(value / 2) + 1) : value / 2;
      shift += 5;
    }
    throw invalidResponse();
  };
  while (index < encoded.length) {
    lat += component(); lon += component();
    const point = [lat / 1e5, lon / 1e5];
    if (!coordinate(point) || points.length >= maxPoints) throw invalidResponse();
    points.push(point);
  }
  if (points.length < 2) throw invalidResponse();
  return points;
}
function safeLabel(value) {
  if (typeof value !== 'string' || value.length > 1024 || /[\u0000-\u001f\u007f]/.test(value)) throw invalidResponse();
  return value;
}
function placeAttributions(value) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 32) throw invalidResponse();
  return value.map(item => {
    if (!item || typeof item !== 'object' || Array.isArray(item)
      || typeof item.provider !== 'string' || !item.provider.trim() || item.provider.length > 256
      || /[\u0000-\u001f\u007f]/.test(item.provider)) throw invalidResponse();
    const providerUri = item.providerUri === undefined ? '' : item.providerUri;
    if (typeof providerUri !== 'string' || providerUri.length > 2048 || /[\u0000-\u0020\u007f]/.test(providerUri)) throw invalidResponse();
    if (providerUri) {
      let url;
      try { url = new URL(providerUri); } catch { throw invalidResponse(); }
      if (!['http:', 'https:'].includes(url.protocol) || !url.hostname || url.username || url.password) throw invalidResponse();
    }
    return { provider: item.provider, providerUri };
  });
}
async function readStream(stream, limit, errorFactory, signal, oversized = errorFactory) {
  const chunks = []; let size = 0;
  for await (const chunk of stream) {
    if (signal?.aborted) throw signal.reason;
    const bytes = Buffer.from(chunk); size += bytes.length;
    if (size > limit) throw oversized();
    chunks.push(bytes);
  }
  try { return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks))); }
  catch { throw errorFactory(); }
}
async function boundedPromise(promise, milliseconds, onTimeout) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(onTimeout()), milliseconds); timer.unref?.();
    })]);
  } finally { clearTimeout(timer); }
}
function upstreamFailure(status) {
  if (status === 429 || status === 503) return new HttpError(503, 'SERVICE_UNAVAILABLE', 'The map service is temporarily unavailable. Try again later.', 60);
  if (status === 404) return new HttpError(404, 'NOT_FOUND', 'The selected place is no longer available.');
  return new HttpError(502, 'UPSTREAM_ERROR', 'The map provider could not complete this request.');
}
export function createGoogleClient({ apiKey, fetchImpl = globalThis.fetch, upstreamMs = LIMITS.upstreamMs }) {
  async function request(url, method, fieldMask, body, clientSignal) {
    const timeout = AbortSignal.timeout(upstreamMs);
    const signal = clientSignal ? AbortSignal.any([timeout, clientSignal]) : timeout;
    try {
      const response = await fetchImpl(url, { method, redirect: 'error', signal,
        headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': apiKey, 'X-Goog-FieldMask': fieldMask },
        ...(body ? { body: JSON.stringify(body) } : {}) });
      if (!response.ok) { await response.body?.cancel(); throw upstreamFailure(response.status); }
      const contentLength = response.headers.get('content-length');
      if (contentLength && Number(contentLength) > LIMITS.upstreamBytes) { await response.body?.cancel(); throw invalidResponse(); }
      if (!response.body) throw invalidResponse();
      return await readStream(response.body, LIMITS.upstreamBytes, invalidResponse, signal);
    } catch (error) {
      if (timeout.aborted) throw new HttpError(504, 'UPSTREAM_TIMEOUT', 'The map request timed out. Try again.');
      if (error instanceof HttpError) throw error;
      throw new HttpError(502, 'UPSTREAM_ERROR', 'The map provider could not complete this request.');
    }
  }
  return async (path, body, signal) => {
    if (path === '/route') {
      const waypoint = ([latitude, longitude]) => ({ location: { latLng: { latitude, longitude } } });
      const payload = { origin: waypoint(body.points[0]), destination: waypoint(body.points[1]),
        travelMode: body.travelMode, computeAlternativeRoutes: false,
        polylineQuality: 'HIGH_QUALITY', polylineEncoding: 'ENCODED_POLYLINE' };
      if (body.travelMode === 'DRIVE') payload.routingPreference = 'TRAFFIC_UNAWARE';
      const data = await request(ROUTES_URL, 'POST', ROUTE_MASK, payload, signal);
      if (!data.routes || (Array.isArray(data.routes) && data.routes.length === 0)) throw new HttpError(404, 'NO_ROUTE', 'No route was found for these points and travel mode.');
      if (!Array.isArray(data.routes) || data.routes.length !== 1) throw invalidResponse();
      const route = data.routes[0];
      if (!route || !Number.isSafeInteger(route.distanceMeters) || route.distanceMeters < 0
        || route.distanceMeters > 100_000_000 || typeof route.duration !== 'string'
        || !/^\d+(\.\d{1,9})?s$/.test(route.duration)) throw invalidResponse();
      const durationSeconds = Number(route.duration.slice(0, -1));
      if (!Number.isFinite(durationSeconds) || durationSeconds > 31_536_000) throw invalidResponse();
      return { points: decodePolyline(route.polyline?.encodedPolyline), distanceMeters: route.distanceMeters, durationSeconds };
    }
    if (path === '/search') {
      const data = await request(`${PLACES_URL}places:autocomplete`, 'POST', SEARCH_MASK,
        { input: body.query, sessionToken: body.sessionToken, includeQueryPredictions: false }, signal);
      if (data.suggestions === undefined) return [];
      if (!Array.isArray(data.suggestions) || data.suggestions.length > 5) throw invalidResponse();
      return data.suggestions.map(item => {
        const prediction = item.placePrediction;
        if (!prediction || typeof prediction.placeId !== 'string' || !PLACE_PATTERN.test(prediction.placeId)) throw invalidResponse();
        return { placeId: prediction.placeId, label: safeLabel(prediction.text?.text) };
      });
    }
    const url = new URL(`${PLACES_URL}places/${encodeURIComponent(body.placeId)}`);
    url.searchParams.set('sessionToken', body.sessionToken);
    const data = await request(url.toString(), 'GET', PLACE_MASK, null, signal);
    const point = [data.location?.latitude, data.location?.longitude];
    if (!coordinate(point)) throw invalidResponse();
    return { lat: point[0], lon: point[1], label: safeLabel(data.formattedAddress || `${point[0]}, ${point[1]}`),
      attributions: placeAttributions(data.attributions) };
  };
}

function send(res, status, body, extra = {}) {
  if (res.destroyed || res.writableEnded) return;
  const encoded = JSON.stringify(body);
  if (Buffer.byteLength(encoded) > LIMITS.responseBytes) throw invalidResponse();
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', ...extra });
  res.end(encoded);
}

export function createHandler({ config, verifyAppCheck, googleClient = createGoogleClient({ apiKey: config.googleApiKey }),
  limiter = new RateLimiter({ maxEntries: config.maxRateEntries }) }) {
  if (!config.localBypass && typeof verifyAppCheck !== 'function') throw new Error('App Check verifier is required.');
  let inflight = 0;
  return async (req, res) => {
    let occupied = false;
    const abort = new AbortController();
    const disconnected = () => { if (!res.writableEnded) abort.abort(); };
    res.on('close', disconnected);
    try {
      const origin = req.headers.origin;
      if (origin && !config.allowedOrigins.has(origin)) throw new HttpError(403, 'FORBIDDEN', 'This origin is not allowed.');
      if (origin) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
      if (req.url === '/healthz' && req.method === 'GET') { send(res, 200, { status: 'ok' }); return; }
      if (!PATHS.has(req.url)) throw new HttpError(404, 'NOT_FOUND', 'Endpoint not found.');
      if (req.method === 'OPTIONS' && origin) {
        res.writeHead(204, { 'Access-Control-Allow-Methods': 'POST', 'Access-Control-Allow-Headers': 'Content-Type,X-Firebase-AppCheck', 'Cache-Control': 'no-store' }); res.end(); return;
      }
      if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); throw new HttpError(405, 'METHOD_NOT_ALLOWED', 'Use POST for this endpoint.'); }
      if (!/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(req.headers['content-type'] || '') || req.headers['content-encoding']) {
        throw new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Use an uncompressed JSON request.');
      }
      if (Number(req.headers['content-length']) > LIMITS.requestBytes) throw new HttpError(413, 'REQUEST_TOO_LARGE', 'The request is too large.');
      if (inflight >= config.maxInflight) throw new HttpError(503, 'SERVICE_UNAVAILABLE', 'The service is busy. Try again shortly.', 5);
      inflight++; occupied = true;
      // An instance-wide cap also bounds invalid-token verification work.
      limiter.take('incoming', config.globalPerMinute * 4, 60_000);
      let caller;
      if (config.localBypass) {
        if (!LOOPBACK.has(req.socket.remoteAddress) || req.headers.forwarded || req.headers['x-forwarded-for']
          || !/^127\.0\.0\.1(?::\d+)?$/.test(req.headers.host || '')) throw new HttpError(403, 'FORBIDDEN', 'Development requests must originate on loopback.');
        caller = 'local-development';
      } else {
        const token = req.headers['x-firebase-appcheck'];
        if (typeof token !== 'string' || token.length === 0 || Buffer.byteLength(token) > LIMITS.tokenBytes) throw new HttpError(401, 'UNAUTHENTICATED', 'App verification is required.');
        let claims;
        try {
          claims = await boundedPromise(Promise.resolve().then(() => verifyAppCheck(token)), LIMITS.authMs,
            () => new HttpError(503, 'SERVICE_UNAVAILABLE', 'App verification is temporarily unavailable.'));
        } catch (error) {
          if (error instanceof HttpError) throw error;
          throw new HttpError(401, 'UNAUTHENTICATED', 'App verification failed.');
        }
        if (claims?.appId !== config.firebaseAppId) throw new HttpError(403, 'FORBIDDEN', 'This app is not allowed.');
        caller = createHash('sha256').update(token).digest('hex');
      }
      limiter.take(`token:${caller}`, config.perTokenPerMinute, 60_000);
      const body = await readStream(req, LIMITS.requestBytes, () => invalid(), abort.signal,
        () => new HttpError(413, 'REQUEST_TOO_LARGE', 'The request is too large.'));
      const input = validateRequest(req.url, body);
      // Count attempts before Google is contacted; errors do not trigger automatic retries.
      limiter.take('paid:minute', config.globalPerMinute, 60_000);
      limiter.take('paid:day', config.globalPerDay, 86_400_000);
      if (abort.signal.aborted) return;
      const output = await googleClient(req.url, input, abort.signal);
      send(res, 200, output);
    } catch (error) {
      const failure = error instanceof HttpError ? error : new HttpError(500, 'INTERNAL_ERROR', 'The service could not complete this request.');
      send(res, failure.status, { error: { code: failure.code, message: failure.message } },
        failure.retryAfter ? { 'Retry-After': String(failure.retryAfter) } : {});
    } finally {
      if (occupied) inflight--;
      res.off('close', disconnected);
    }
  };
}
