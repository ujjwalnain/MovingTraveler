// SPDX-License-Identifier: GPL-3.0-or-later
import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { Readable } from 'node:stream';
import { createGoogleClient, createHandler, decodePolyline, HttpError, LIMITS, loadConfig, RateLimiter, validateRequest } from '../gateway.js';

const sessionToken = 'b0a7c340-cf22-46bc-a37c-016b7dd3475e';
const appId = '1:123456789:android:abcdef0123456789';
const config = () => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-server-key', FIREBASE_PROJECT_ID: 'test-project', FIREBASE_APP_ID: appId });
const routeInput = { points: [[38.5, -120.2], [43.252, -126.453]], travelMode: 'DRIVE' };
const routeFixture = { routes: [{ polyline: { encodedPolyline: '_p~iF~ps|U_ulLnnqC_mqNvxq`@' }, distanceMeters: 1000, duration: '90.125s' }] };
const jsonResponse = value => new Response(JSON.stringify(value), { status: 200, headers: { 'Content-Type': 'application/json' } });
const statusIs = (status, code) => error => error instanceof HttpError && error.status === status && (!code || error.code === code);

test('configuration fails closed and local bypass cannot run in production/Cloud Run', () => {
  assert.throws(() => loadConfig({}));
  assert.throws(() => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key' }));
  assert.throws(() => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key', NODE_ENV: 'production', DEV_LOCAL_BYPASS: 'true' }));
  assert.throws(() => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key', NODE_ENV: 'development', DEV_LOCAL_BYPASS: 'true', K_SERVICE: 'gateway' }));
  assert.throws(() => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key', NODE_ENV: 'development', DEV_LOCAL_BYPASS: 'true', HOST: '0.0.0.0' }));
  assert.throws(() => loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key', NODE_ENV: 'development', DEV_LOCAL_BYPASS: 'true', ALLOWED_ORIGINS: '*' }));
  const local = loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'fixture-key', NODE_ENV: 'development', DEV_LOCAL_BYPASS: 'true' });
  assert.equal(local.host, '127.0.0.1');
  assert.throws(() => createHandler({ config: config() }));
});

test('strict request validation prevents passthrough fields and malformed inputs', () => {
  assert.deepEqual(validateRequest('/route', routeInput), routeInput);
  for (const input of [null, [], { ...routeInput, trafficModel: 'BEST_GUESS' },
    { ...routeInput, points: [[91, 0], [0, 0]] }, { ...routeInput, points: [[0, '1'], [0, 0]] },
    { ...routeInput, points: [[0, 1, 2], [0, 0]] }, { ...routeInput, travelMode: 'TRANSIT' }]) {
    assert.throws(() => validateRequest('/route', input), statusIs(400));
  }
  assert.equal(validateRequest('/search', { query: '  New Delhi  ', sessionToken }).query, 'New Delhi');
  for (const query of [' ', 'x', 'x'.repeat(201), 'a\nb']) assert.throws(() => validateRequest('/search', { query, sessionToken }), statusIs(400));
  assert.throws(() => validateRequest('/search', { query: 'Paris', sessionToken: 'bad' }), statusIs(400));
  for (const placeId of ['../place', 'places/id', 'a?secret=x', 'a\nb', 'x'.repeat(513)]) {
    assert.throws(() => validateRequest('/place', { placeId, sessionToken }), statusIs(400));
  }
});

test('polyline decoding is bounded and rejects truncation, invalid bytes, and impossible coordinates', () => {
  assert.deepEqual(decodePolyline(routeFixture.routes[0].polyline.encodedPolyline), [[38.5, -120.2], [40.7, -120.95], [43.252, -126.453]]);
  for (const value of ['', '?', '\n?', '~~~~~~~?', '___________', '_p~iF~ps|U_ulLnnqC_mqNvxq`']) {
    assert.throws(() => decodePolyline(value), statusIs(502));
  }
  assert.throws(() => decodePolyline('??????', 2), statusIs(502));
  assert.throws(() => decodePolyline('????'.repeat(10_001)), statusIs(502));
});

test('route uses only Essentials fields, normalizes geometry, and omits drive preference for walk/cycle', async () => {
  const calls = [];
  const client = createGoogleClient({ apiKey: 'server-only-secret', fetchImpl: async (url, init) => {
    calls.push({ url, init }); return jsonResponse(routeFixture);
  } });
  for (const travelMode of ['DRIVE', 'WALK', 'BICYCLE']) {
    const result = await client('/route', { ...routeInput, travelMode });
    assert.equal(result.points.length, 3); assert.equal(result.durationSeconds, 90.125); assert.equal(result.distanceMeters, 1000);
    const { url, init } = calls.at(-1), payload = JSON.parse(init.body);
    assert.equal(url, 'https://routes.googleapis.com/directions/v2:computeRoutes');
    assert.equal(init.headers['X-Goog-Api-Key'], 'server-only-secret');
    assert.equal(init.headers['X-Goog-FieldMask'], 'routes.polyline.encodedPolyline,routes.distanceMeters,routes.duration');
    assert.equal(payload.routingPreference, travelMode === 'DRIVE' ? 'TRAFFIC_UNAWARE' : undefined);
    assert.equal(payload.polylineQuality, 'HIGH_QUALITY');
    assert.equal(payload.computeAlternativeRoutes, false);
    assert.equal(payload.extraComputations, undefined); assert.equal(init.redirect, 'error');
    assert.deepEqual(payload.origin.location.latLng, { latitude: 38.5, longitude: -120.2 });
  }
});

test('search and Details preserve session tokens and avoid the higher-priced displayName field', async () => {
  const calls = [];
  const client = createGoogleClient({ apiKey: 'test', fetchImpl: async (url, init) => {
    calls.push({ url, init });
    return jsonResponse(url.includes(':autocomplete') ? { suggestions: [{ placePrediction: { placeId: 'ChIJ_test', text: { text: 'Test address' } } }] }
      : { location: { latitude: 28.6, longitude: 77.2 }, formattedAddress: 'Test address' });
  } });
  assert.deepEqual(await client('/search', { query: 'Test', sessionToken }), [{ placeId: 'ChIJ_test', label: 'Test address' }]);
  assert.equal(JSON.parse(calls[0].init.body).sessionToken, sessionToken);
  assert.equal(JSON.parse(calls[0].init.body).includeQueryPredictions, false);
  assert.equal(calls[0].init.headers['X-Goog-FieldMask'], 'suggestions.placePrediction.placeId,suggestions.placePrediction.text.text');
  assert.deepEqual(await client('/place', { placeId: 'ChIJ_test', sessionToken }), { lat: 28.6, lon: 77.2, label: 'Test address', attributions: [] });
  assert.equal(new URL(calls[1].url).searchParams.get('sessionToken'), sessionToken);
  assert.equal(calls[1].init.headers['X-Goog-FieldMask'], 'location,formattedAddress,attributions');
  assert.equal(calls[1].init.method, 'GET');
});

test('place attributions preserve provider credits and normalize missing optional URI', async () => {
  let attributions;
  const client = createGoogleClient({ apiKey: 'test', fetchImpl: async () => jsonResponse({
    location: { latitude: 28.6, longitude: 77.2 }, formattedAddress: 'Address',
    ...(attributions === undefined ? {} : { attributions }) }) });
  const request = () => client('/place', { placeId: 'test', sessionToken });
  assert.deepEqual((await request()).attributions, []);
  attributions = []; assert.deepEqual((await request()).attributions, []);
  attributions = [{ provider: 'Provider A', providerUri: 'https://provider.example/credit' },
    { provider: 'Provider B' }, { provider: 'Provider C', providerUri: '' },
    { provider: 'Provider D', providerUri: 'http://provider.example/credit' }];
  assert.deepEqual((await request()).attributions, [attributions[0], { provider: 'Provider B', providerUri: '' }, attributions[2], attributions[3]]);
});

test('malformed or dangerous provider attributions reject the response instead of dropping credits', async () => {
  let attributions;
  const client = createGoogleClient({ apiKey: 'test', fetchImpl: async () => jsonResponse({
    location: { latitude: 28.6, longitude: 77.2 }, attributions }) });
  const invalid = [null, {}, [null], [{}], [{ provider: '' }], [{ provider: '   ' }],
    [{ provider: 'Bad\nprovider' }], [{ provider: 'x'.repeat(257) }],
    ...['javascript:alert(1)', 'file:///private/file', '//provider.example',
      'https://user:secret@provider.example/', 'https:///', 'https://provider.example/\nsecret',
      'https://provider.example/' + 'x'.repeat(2048), null, 3].map(providerUri => [{ provider: 'Provider', providerUri }]),
    Array.from({ length: 33 }, () => ({ provider: 'Provider' }))];
  for (const value of invalid) {
    attributions = value;
    await assert.rejects(() => client('/place', { placeId: 'test', sessionToken }), statusIs(502, 'INVALID_RESPONSE'));
  }
});

test('empty results and malformed provider results have stable errors', async () => {
  let fixture = {};
  const client = createGoogleClient({ apiKey: 'test', fetchImpl: async () => jsonResponse(fixture) });
  assert.deepEqual(await client('/search', { query: 'Test', sessionToken }), []);
  await assert.rejects(() => client('/route', routeInput), statusIs(404, 'NO_ROUTE'));
  for (const bad of [{ routes: 'bad' }, { routes: [{ ...routeFixture.routes[0], duration: '-10s' }] },
    { routes: [{ ...routeFixture.routes[0], distanceMeters: null }] }, { routes: [{ ...routeFixture.routes[0], polyline: { encodedPolyline: 'bad' } }] }]) {
    fixture = bad; await assert.rejects(() => client('/route', routeInput), statusIs(502));
  }
  fixture = { suggestions: [{ placePrediction: { placeId: 'id', text: { text: '\u0000private' } } }] };
  await assert.rejects(() => client('/search', { query: 'Test', sessionToken }), statusIs(502));
  fixture = { location: { latitude: 91, longitude: 0 } };
  await assert.rejects(() => client('/place', { placeId: 'test', sessionToken }), statusIs(502));
});

test('upstream failures are sanitized, bounded, and never automatically retried', async () => {
  let calls = 0;
  const client = createGoogleClient({ apiKey: 'test', fetchImpl: async () => {
    calls++; return new Response('secret billing provider body', { status: 403 });
  } });
  await assert.rejects(() => client('/route', routeInput), error => statusIs(502, 'UPSTREAM_ERROR')(error) && !error.message.includes('secret'));
  assert.equal(calls, 1);
  const largeClient = createGoogleClient({ apiKey: 'test', fetchImpl: async () => new Response(' ', { headers: { 'content-length': String(LIMITS.upstreamBytes + 1) } }) });
  await assert.rejects(() => largeClient('/route', routeInput), statusIs(502));
  const chunkedClient = createGoogleClient({ apiKey: 'test', fetchImpl: async () => new Response(' '.repeat(LIMITS.upstreamBytes + 1)) });
  await assert.rejects(() => chunkedClient('/route', routeInput), statusIs(502));
  const quotaClient = createGoogleClient({ apiKey: 'test', fetchImpl: async () => new Response('{}', { status: 429 }) });
  await assert.rejects(() => quotaClient('/route', routeInput), statusIs(503));
});

test('upstream deadline aborts requests', async () => {
  const client = createGoogleClient({ apiKey: 'test', upstreamMs: 5, fetchImpl: (_url, { signal }) => new Promise((_, reject) => {
    const keepalive = setTimeout(() => {}, 100);
    signal.addEventListener('abort', () => { clearTimeout(keepalive); reject(signal.reason); }, { once: true });
  }) });
  await assert.rejects(() => client('/route', routeInput), statusIs(504, 'UPSTREAM_TIMEOUT'));
});

test('rate limits reject full windows and bound memory without evicting active clients', () => {
  let now = 0;
  const limiter = new RateLimiter({ maxEntries: 2, now: () => now });
  limiter.take('a', 1, 60_000);
  assert.throws(() => limiter.take('a', 1, 60_000), statusIs(429));
  limiter.take('b', 1, 60_000);
  assert.throws(() => limiter.take('c', 1, 60_000), statusIs(429));
  assert.equal(limiter.entries.size, 2);
  now = 60_000; limiter.take('c', 1, 60_000);
  assert.equal(limiter.entries.size, 1);
});

async function serve(t, options = {}) {
  let paidCalls = 0;
  const handler = createHandler({ config: config(), verifyAppCheck: async token => {
    if (token === 'invalid') throw new Error('token details must never leak');
    return { appId: token === 'wrong-app' ? 'different-app' : appId };
  }, googleClient: async () => { paidCalls++; return { ok: true }; }, ...options });
  // Exercise the production HTTP handler with real Node streams, without a listening
  // socket, external connectivity, Firebase credentials, or billable Google requests.
  const request = async (path, { method = 'GET', headers = {}, body = '', chunked = false, remoteAddress = '127.0.0.1' } = {}) => {
    const req = Readable.from([Buffer.from(body)]);
    req.url = path; req.method = method; req.socket = { remoteAddress };
    req.headers = { host: '127.0.0.1:8080', ...Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), value])) };
    if (!chunked) req.headers['content-length'] = String(Buffer.byteLength(body));
    const res = new EventEmitter(); let status = 200, output = '';
    const responseHeaders = new Headers();
    res.setHeader = (key, value) => responseHeaders.set(key, value);
    res.writeHead = (value, extra) => { status = value; for (const [key, item] of Object.entries(extra)) responseHeaders.set(key, item); };
    res.end = (value = '') => { output = value; res.writableEnded = true; res.emit('close'); };
    await handler(req, res);
    assert.equal(res.writableEnded, true);
    return new Response(status === 204 ? null : output, { status, headers: responseHeaders });
  };
  return { request, paidCalls: () => paidCalls,
    post: (path = '/route', body = routeInput, extraHeaders = {}) => request(path, { method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Firebase-AppCheck': 'valid-token', ...extraHeaders }, body: JSON.stringify(body) }) };
}

test('HTTP authentication fails closed before any provider requests', async t => {
  const server = await serve(t);
  for (const [token, expected] of [['', 401], ['invalid', 401], ['wrong-app', 403], ['x'.repeat(4097), 401]]) {
    const response = await server.post('/route', routeInput, { 'X-Firebase-AppCheck': token });
    assert.equal(response.status, expected); assert.equal(response.headers.get('cache-control'), 'no-store');
    assert.ok(!(await response.text()).includes('token details'));
  }
  assert.equal(server.paidCalls(), 0);
  assert.equal((await server.post()).status, 200); assert.equal(server.paidCalls(), 1);
});

test('HTTP endpoint, content type, origins, and JSON are constrained', async t => {
  const server = await serve(t);
  assert.equal((await server.post('/route?points=private')).status, 404);
  assert.equal((await server.post('/unknown')).status, 404);
  assert.equal((await server.request('/route')).status, 405);
  assert.equal((await server.post('/route', routeInput, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await server.post('/route', routeInput, { 'Origin': 'https://attacker.example' })).status, 403);
  assert.equal((await server.post('/route', { ...routeInput, secret: true })).status, 400);
  assert.equal((await server.post('/search', { query: 'x'.repeat(9000), sessionToken })).status, 413);
  const badJson = await server.request('/route', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Firebase-AppCheck': 'valid' }, body: '{' });
  assert.equal(badJson.status, 400); assert.equal(server.paidCalls(), 0);
  assert.deepEqual(await (await server.request('/healthz')).json(), { status: 'ok' });
  const oversizedChunked = await server.request('/route', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Firebase-AppCheck': 'valid' }, body: ' '.repeat(8193), chunked: true });
  assert.equal(oversizedChunked.status, 413);
});

test('CORS enables only configured exact HTTPS origins', async t => {
  const customConfig = { ...config(), allowedOrigins: new Set(['https://app.example']) };
  const server = await serve(t, { config: customConfig });
  const preflight = await server.request('/route', { method: 'OPTIONS', headers: { Origin: 'https://app.example' } });
  assert.equal(preflight.status, 204); assert.equal(preflight.headers.get('access-control-allow-origin'), 'https://app.example');
  const response = await server.post('/route', routeInput, { Origin: 'https://app.example' });
  assert.equal(response.status, 200); assert.equal(response.headers.get('access-control-allow-origin'), 'https://app.example');
});

test('HTTP quota returns Retry-After and prevents the next billable attempt', async t => {
  const server = await serve(t, { config: { ...config(), perTokenPerMinute: 1 } });
  assert.equal((await server.post()).status, 200);
  const response = await server.post(); assert.equal(response.status, 429);
  assert.equal(response.headers.get('retry-after'), '60'); assert.equal(server.paidCalls(), 1);
});

test('development bypass rejects forwarded traffic and non-loopback Host values', async t => {
  const local = loadConfig({ GOOGLE_MAPS_SERVER_KEY: 'test-key', NODE_ENV: 'development', DEV_LOCAL_BYPASS: 'true' });
  const server = await serve(t, { config: local, verifyAppCheck: undefined });
  assert.equal((await server.post('/route', routeInput, { 'X-Firebase-AppCheck': '' })).status, 200);
  assert.equal((await server.post('/route', routeInput, { 'X-Forwarded-For': '127.0.0.1' })).status, 403);
  const foreignHost = await server.post('/route', routeInput, { Host: 'public.example' });
  assert.equal(foreignHost.status, 403);
  const remoteCaller = await server.request('/route', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(routeInput), remoteAddress: '192.0.2.1' });
  assert.equal(remoteCaller.status, 403); assert.equal(server.paidCalls(), 1);
});

test('unexpected server failures do not expose request bodies or secrets', async t => {
  const server = await serve(t, { googleClient: async () => { throw new Error('private coordinates api-key token'); } });
  const response = await server.post(); assert.equal(response.status, 500);
  assert.deepEqual(await response.json(), { error: { code: 'INTERNAL_ERROR', message: 'The service could not complete this request.' } });
});
