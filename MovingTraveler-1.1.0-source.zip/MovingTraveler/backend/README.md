# Moving Traveler Google gateway

This small Node 24 service sends the app's route and place requests to Google Maps Platform. It owns the server API key, verifies Firebase App Check, limits requests, and returns a narrow JSON contract. It does not publish mock locations; the Android app performs playback locally.

No Google Cloud/Firebase project, billing account, API key, service account, or deployment is created by these files. Online Google features require the publisher's setup below. The fixture tests make **zero paid API calls**.

## Wire contract

Use HTTPS, `POST`, `Content-Type: application/json`, and `X-Firebase-AppCheck: <current Firebase App Check token>`. Send data in the body, never in URL parameters. Endpoints reject unknown fields. Coordinates are `[latitude, longitude]` throughout this contract.

| Path | Request body | HTTP 200 response |
|---|---|---|
| `/route` | `{"points":[[28.61,77.20],[28.63,77.22]],"travelMode":"DRIVE"}` | `{"points":[[28.61,77.20],[28.62,77.21],[28.63,77.22]],"distanceMeters":3100,"durationSeconds":540}` |
| `/search` | `{"query":"New Delhi","sessionToken":"b0a7c340-cf22-46bc-a37c-016b7dd3475e"}` | `[{"placeId":"ChIJ_example","label":"New Delhi, Delhi, India"}]` |
| `/place` | `{"placeId":"ChIJ_example","sessionToken":"b0a7c340-cf22-46bc-a37c-016b7dd3475e"}` | `{"lat":28.61,"lon":77.20,"label":"New Delhi, Delhi, India"}` |

Examples illustrate the schema; they are not recorded Google responses. `/route` accepts exactly two points and `DRIVE`, `WALK`, or `BICYCLE`. Its geometry follows the provider's snapped endpoints; do not silently connect them to arbitrary off-road coordinates. `durationSeconds` is Google's travel estimate, not the simulation duration at the user's chosen pace. `/search` returns at most five place predictions. Render all labels as text, never HTML. `/place` also returns `attributions: [{"provider":"Provider name","providerUri":"https://provider.example/"}]`, or an empty array. Display returned credits with the selected place. Missing provider URIs normalize to an empty string; supplied URIs must be credential-free HTTP/HTTPS URLs. At most 32 credits are accepted, with 256-character provider names and 2048-character URIs; malformed credits reject the whole response.

Use a new UUIDv4 session token when the user begins selecting each endpoint. Keep it through the predictions and the single `/place` call for that selection, then retire it. Never reuse the start token for the destination. Tokens must be 16–36 URL-safe ASCII characters; UUIDv4 satisfies this. Trimmed queries must contain 2–200 characters without control characters. Place IDs must be 1–512 URL-safe characters, with no slash or query syntax.

Errors use `{"error":{"code":"CODE","message":"Safe user-facing explanation."}}`. Do not rely on message wording for logic.

| HTTP status | Codes |
|---|---|
| 400 | `INVALID_REQUEST` |
| 401 | `UNAUTHENTICATED` — missing, invalid, or expired App Check token |
| 403 | `FORBIDDEN` — wrong Firebase app, origin, or invalid local bypass access |
| 404 | `NOT_FOUND`, `NO_ROUTE` |
| 405 / 413 / 415 | `METHOD_NOT_ALLOWED` / `REQUEST_TOO_LARGE` / `UNSUPPORTED_MEDIA_TYPE` |
| 429 | `RATE_LIMITED`; respect `Retry-After` |
| 500 | `INTERNAL_ERROR` |
| 502 | `UPSTREAM_ERROR`, `INVALID_RESPONSE` |
| 503 | `SERVICE_UNAVAILABLE`; may include `Retry-After` |
| 504 | `UPSTREAM_TIMEOUT` |

The proxy performs no automatic retry. Client retrying can incur another paid request, especially when a response was lost. A new user action can retry after the displayed failure. A missing route must not silently fall back to a different travel mode. `GET /healthz` returns `{"status":"ok"}` without an API call; it tests process health, not Google/Firebase connectivity.

## Publisher setup

1. Create or choose a Google Cloud project and attach the publisher's billing account. Enable **Routes API** and **Places API (New)**. Set API quotas and billing alerts before testing. Search, route, and place details have separate SKUs; do not assume a route price covers search. Create a dedicated server API key restricted to these two APIs. Keep the separate Android Maps SDK key restricted to the final package name and signing certificate.
2. Add Firebase to the chosen project and register the app's final Android application ID. Record its Firebase project ID and Firebase Android **App ID**; the latter has the form `1:…:android:…` and is different from the Android package name. Configure Play Integrity App Check using the release/Play signing SHA-256 certificate and the linked Play Console app. Supply the Firebase configuration to the Android build. Select attestation settings that match the intended Play-distributed app. Use the Firebase debug provider only for registered development builds; never ship debug attestation or a bypass in the release app. [Android App Check setup](https://firebase.google.com/docs/app-check/android/play-integrity-provider)
3. Create a dedicated Cloud Run service identity with only the access it needs. Store the server key in Secret Manager, grant that identity access to the individual secret, and **bind its version to the container environment variable `GOOGLE_MAPS_SERVER_KEY`**. Creating a secret or granting access alone does not populate that variable; the server will refuse to start without it. Select the dedicated identity as the service's runtime service account. Use Cloud Run's Application Default Credentials; do not copy a service-account JSON key into the image. Set `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID`, `NODE_ENV=production`, and the limits from `.env.example`. Leave `DEV_LOCAL_BYPASS=false` and `ALLOWED_ORIGINS` empty for native Android requests. The console walkthrough below covers these steps.
4. Build the Linux/amd64 image, push it to Artifact Registry, and deploy that registry image with a selected region, at least 512 MiB memory, HTTP port 8080, request timeout 30 seconds, concurrency no higher than 32, and initially at most one instance. A local Docker tag alone cannot be deployed by Cloud Run. The public Android client does not carry a Cloud Run IAM service-account credential: enable external HTTP invocation and enforce App Check in this application, or configure an equivalent edge that preserves the App Check header. Add an HTTPS load balancer/Cloud Armor policy when needed for abuse protection. Restrict direct ingress appropriately if placing a protected load balancer in front. [Cloud Run runtime contract](https://cloud.google.com/run/docs/container-contract)
5. The service key should also have a server IP application restriction. Configure a static Cloud Run outbound IP through VPC/NAT, route **all egress traffic** through that VPC (`all-traffic`), and allow only the resulting public egress address on the key. Creating a NAT gateway without connecting the service and selecting all-traffic egress is insufficient. Verify the deployed egress before applying the IP restriction. Without static egress, an IP restriction will break calls; do not replace it with an Android restriction on the server key. Keep API restrictions in all cases. [Static outbound IP walkthrough](https://docs.cloud.google.com/run/docs/configuring/static-outbound-ip), [Google API security guidance](https://developers.google.com/maps/api-security-best-practices)
6. Set the app's backend base URL to the deployed HTTPS origin. Validate a Play internal-test installation: a current App Check token from the registered app succeeds, a missing/modified token gets 401, and a token for another app gets 403. Make a small, explicitly budgeted route/search/details test. The no-credential fixture tests cannot verify project billing, attestation, signing, quotas, or live regional route coverage.
7. Finalize the app's public privacy policy and terms, Google attribution, Google map display, provider disclosures, and storage behavior. Publish the URLs in the app and store listing. These project and policy choices remain release prerequisites.

### First deployment through Google Cloud Console

These steps are instructions for the publisher; they have not been performed by the supplied project. Deployment, image storage and networking can incur charges. Complete the Cloud/Firebase and key setup above first.

1. In **APIs & Services → Library**, enable **Cloud Run Admin API**, **Artifact Registry API**, **Secret Manager API**, and **Identity and Access Management (IAM) API** in the selected project. Routes API and Places API (New) must also be enabled. This local Docker workflow does not require Cloud Build. The static-egress walkthrough lists the additional networking prerequisites.
2. In **Artifact Registry → Repositories → Create repository**, choose **Docker**, **Standard** mode and a region; name the repository, for example `moving-traveler`. Use the same project and preferably the same region for the Cloud Run service. Install Docker and the Google Cloud CLI on the build machine, sign in with the publisher's authorized account, and select the project. The operator needs permission to push images, deploy Cloud Run services and use the selected runtime identity.
3. From this `backend` directory, replace the example project/region values and build/push the image. These commands contain no server key:

   ```sh
   TRAVELER_PROJECT=YOUR_PROJECT_ID
   TRAVELER_REGION=YOUR_REGION
   TRAVELER_REPOSITORY=moving-traveler
   TRAVELER_IMAGE="${TRAVELER_REGION}-docker.pkg.dev/${TRAVELER_PROJECT}/${TRAVELER_REPOSITORY}/gateway:1.1.0"
   gcloud auth configure-docker "${TRAVELER_REGION}-docker.pkg.dev"
   docker build --platform linux/amd64 -t "$TRAVELER_IMAGE" .
   docker push "$TRAVELER_IMAGE"
   ```

   Confirm the pushed image appears in the repository. Record its digest for release provenance; deploy the tested image/digest rather than rebuilding silently. [Artifact Registry push instructions](https://docs.cloud.google.com/artifact-registry/docs/docker/pushing-and-pulling)
4. In **IAM & Admin → Service Accounts**, create a dedicated runtime identity, for example `moving-traveler-gateway`. In **Secret Manager → Create secret**, create `moving-traveler-google-key` and enter the restricted server API key as the secret value. On that secret's **Permissions** page, grant the runtime identity **Secret Manager Secret Accessor** for this secret. Do not download a service-account private key or grant broad project-editor access to the runtime identity.
5. In **Cloud Run → Services → Deploy container / Create service**, select the Artifact Registry image pushed above. Select the region, choose the service name, and allow public/unauthenticated HTTP invocation for the Android client. App Check remains mandatory inside the gateway. Under **Security**, select the dedicated runtime service account. Under container settings, use port **8080**, at least **512 MiB** memory, request timeout **30 seconds**, concurrency **32** or lower, and maximum instances **1** initially.
6. Under **Variables & Secrets**, add the non-secret environment values `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID`, `NODE_ENV=production`, `DEV_LOCAL_BYPASS=false` and the desired limits from `.env.example`. Omit `ALLOWED_ORIGINS` for native-only access; keep `HOST=0.0.0.0` or use its default. Choose **Reference a secret**: environment variable name **`GOOGLE_MAPS_SERVER_KEY`**, secret **`moving-traveler-google-key`**, and a specific secret version, such as **`1`**. This must be an environment-variable binding, since this server does not read a mounted secret file. Do not paste the secret into an ordinary environment-variable value. [Cloud Run secret configuration](https://docs.cloud.google.com/run/docs/configuring/services/secrets)
7. Deploy, then copy the actual HTTPS URL displayed by Cloud Run into the Android `GOOGLE_PROXY_BASE_URL`. Open `/healthz` to check startup; this does not call Google or validate App Check. Complete the static-IP/all-traffic step above before relying on an IP-restricted server key, then run the small registered-app test in publisher setup step 6. Keep the test and release Firebase app-ID deployments separate. [Cloud Run image deployment](https://docs.cloud.google.com/run/docs/deploying)

## Build and verification

```sh
node --test
npm install --package-lock-only --ignore-scripts
npm ci --omit=optional --ignore-scripts
npm audit --omit=dev --omit=optional
docker build --platform linux/amd64 -t moving-traveler-gateway .
```

The reviewed `package-lock.json` is included. Keep it committed when dependencies change. The Dockerfile requires a matching lockfile and uses `npm ci --omit=optional`. This excludes unused Storage/Firestore dependencies, including an optional vulnerable uuid dependency; they are not needed for App Check. Pin the approved Node image by digest in the publisher's release pipeline and regularly rebuild for security updates.

Tests use injected App Check verification, fake Google responses, and Node request streams. They cover strict inputs, auth rejection, origin checks, loopback bypass restrictions, geometry decoding, malformed/oversized responses, timeout behavior, quotas, and error sanitization. They do not attest a real device, open network sockets, install the Firebase SDK, or call Google. Root verification completed lockfile resolution, production installation with optional packages omitted, a zero-vulnerability production audit, a real loopback HTTP health check, and a real Firebase Admin malformed-token rejection. Container execution and live integration still require verification before deployment. Firebase Admin is pinned to 14.4.0, documented by Google's September 10, 2026 release notes; Node 24 satisfies its runtime requirement. [Firebase Admin release notes](https://firebase.google.com/support/release-notes/admin/node)

For an explicitly local manual test only, copy `.env.example` to a private `.env`, set `NODE_ENV=development`, `DEV_LOCAL_BYPASS=true`, and `HOST=127.0.0.1`, then run `node --env-file=.env server.js`. **This mode still calls paid Google APIs** if you send a route/search/place request with a real key. The automated test suite needs no `.env` or key. The bypass refuses Cloud Run's `K_SERVICE`, non-loopback bind/peer/Host, and forwarded requests. Do not expose it through a tunnel, proxy, container port mapping, or public interface.

## Limits, costs, and data handling

The server fixes the Google request masks: route polyline/distance/duration; autocomplete prediction ID/text; Details `location,formattedAddress,attributions`. Driving is traffic-unaware. Walking and cycling omit driving-only preferences. No traffic, alternative routes, waypoint optimization, photos, ratings, wildcard masks, or `displayName` are requested. A high-quality polyline is decoded into at most 20,000 points. Google's returned route may still be unavailable or unsuitable in a region. [Compute Routes](https://developers.google.com/maps/documentation/routes/reference/rest/v2/TopLevel/computeRoutes), [Autocomplete](https://developers.google.com/maps/documentation/places/web-service/place-autocomplete), [Details fields](https://developers.google.com/maps/documentation/places/web-service/place-details)

Valid autocomplete sessions ending in Details Essentials bill the first 12 prediction requests plus the Details request; later predictions in that session have no charge. Abandoned sessions are billed per prediction. Requesting non-Essentials Details changes the session's pricing; do not expand field masks without a pricing review. [Session billing](https://developers.google.com/maps/documentation/places/web-service/session-pricing)

Limits default to 8 KiB request bodies, 2 MB upstream bodies, 1.5 MB responses, 12 seconds per Google call, 5 seconds for App Check, and 32 simultaneous operations. An incoming request cap protects verifier work. Authenticated calls are limited to 60 per token per fixed one-minute window, 300 Google attempts per fixed one-minute window, and 5,000 per fixed 24-hour window **per process**. Each window starts with its first accepted attempt and resets when a later attempt arrives after expiry; this is not a sliding or trailing-window limit, and bursts can occur on both sides of a boundary. Limits count attempts, including failed Google calls. The map holds at most 10,000 counter entries and rejects new keys when full. Only SHA-256 token digests and counters are retained; raw tokens are not kept in the limiter.

These in-memory counters reset on restart, multiply across instances/revisions, and do not identify individual users or installations. App Check is app attestation, not user authentication, and this implementation does not consume tokens for replay protection. A valid token can be reused until expiry. The counters are defense in depth, not an enforceable monthly spending ceiling. Configure provider quotas and edge controls; add a shared atomic limiter before scaling. Budget alerts alone do not stop billing. [Backend App Check verification and replay protection](https://firebase.google.com/docs/app-check/custom-resource-backend)

There is no route/search/geometry cache, database, analytics, or application request logging. Responses use `Cache-Control: no-store`. The server sends the chosen coordinates, query text, place IDs, and autocomplete session tokens to Google, and uses Firebase to verify attestation. Cloud Run, a load balancer, Firebase, Google APIs, and the publisher's infrastructure can separately process network metadata or retain logs. Set their access, retention, exclusions, and privacy disclosures deliberately; do not claim that the whole system collects no data. Keep gateway paths fixed so app coordinates and searches stay out of platform URL logs. Do not turn on fetch/HTTP body/header tracing.

Display Google route/place content with the required Google Maps attribution and appropriate Google map. Do not overlay it on the old OpenStreetMap/Leaflet map or persist downloaded Google route geometry for later replay without an applicable permission. Review the terms for the publisher's billing jurisdiction, including EEA-specific terms where relevant. [Routes policies](https://developers.google.com/maps/documentation/routes/policies), [Places policies](https://developers.google.com/maps/documentation/places/web-service/policies)

The gateway source is independently authored under GPL-3.0-or-later; Firebase Admin and its dependencies retain their own licenses. Distribute required dependency notices and corresponding GPL source with a release. Cloud deployment does not change the Android app's package/signing identity or create a Play approval guarantee.
