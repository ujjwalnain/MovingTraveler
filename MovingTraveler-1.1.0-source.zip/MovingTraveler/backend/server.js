// SPDX-License-Identifier: GPL-3.0-or-later
import { createServer } from 'node:http';
import { createHandler, loadConfig } from './gateway.js';

try {
  const config = loadConfig();
  let verifyAppCheck;
  if (!config.localBypass) {
    const { initializeApp, applicationDefault } = await import('firebase-admin/app');
    const { getAppCheck } = await import('firebase-admin/app-check');
    const app = initializeApp({ credential: applicationDefault(), projectId: config.firebaseProjectId });
    verifyAppCheck = token => getAppCheck(app).verifyToken(token);
  }
  const server = createServer({ maxHeaderSize: 16_384, requestTimeout: 20_000, headersTimeout: 10_000,
    keepAliveTimeout: 5000 }, createHandler({ config, verifyAppCheck }));
  server.timeout = 25_000;
  server.maxRequestsPerSocket = 100;
  server.on('timeout', socket => socket.destroy());
  server.on('clientError', (_error, socket) => socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'));
  server.on('error', () => { console.error('Gateway could not listen.'); process.exitCode = 1; });
  server.listen(config.port, config.host, () => console.info(config.localBypass ? 'Gateway listening in loopback development mode.' : 'Gateway listening with App Check required.'));
  for (const signal of ['SIGTERM', 'SIGINT']) process.once(signal, () => {
    server.close(() => process.exit(0));
    setTimeout(() => { server.closeAllConnections(); process.exit(0); }, 9000).unref();
  });
} catch {
  // Never log exception messages that might contain credentials, request data, or SDK tokens.
  console.error('Gateway startup failed. Check required server configuration and credentials.');
  process.exitCode = 1;
}
